(* ===== r(1,0) : corrected class list : residual + pairwise non-conjugacy ===== *)
ClearAll["Global`*"];
br[x_, y_] := {0, x[[1]] y[[2]] - y[[1]] x[[2]], 0};
e = IdentityMatrix[3];
resid[T_] := Max[Abs[Flatten[Table[
  br[T.e[[i]], T.e[[j]]] - T.br[T.e[[i]], e[[j]]], {i, 3}, {j, 3}]]]];
lab = {"1 0", "2 e21", "3 e31", "4 e21+e31", "5 e32+e31",
   "6 aId", "7 aId+e31", "8 diag(a,0,a)", "9 diag(a,0,a)+e31",
   "10 mu*e33", "11 e21+mu*e33", "12 e32+mu*e33", "13 e32",
   "14 e23+mu*e33", "15 e23+e31+mu*e33", "16 diag(a,0,mu)",
   "17 diag(a,a,mu)", "18 e13+g*e31+mu*e33"};
forms = {
  {{0,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{0,0,0}},
  {{0,0,0},{0,0,0},{1,0,0}},
  {{0,0,0},{1,0,0},{1,0,0}},
  {{0,0,0},{0,0,0},{1,1,0}},
  {{2,0,0},{0,2,0},{0,0,2}},
  {{2,0,0},{0,2,0},{1,0,2}},
  {{2,0,0},{0,0,0},{0,0,2}},
  {{2,0,0},{0,0,0},{1,0,2}},
  {{0,0,0},{0,0,0},{0,0,3}},
  {{0,0,0},{1,0,0},{0,0,3}},
  {{0,0,0},{0,0,0},{0,1,3}},
  {{0,0,0},{0,0,0},{0,1,0}},
  {{0,0,0},{0,0,1},{0,0,3}},
  {{0,0,0},{0,0,1},{1,0,3}},
  {{2,0,0},{0,0,0},{0,0,5}},
  {{2,0,0},{0,2,0},{0,0,5}},
  {{0,0,1},{0,0,0},{2,0,3}}};
Print["== residuals =="];
Do[Print["  ", lab[[k]], "   resid = ", resid[forms[[k]]]], {k, Length[forms]}];

phi = {{1,0,0},{w1,p,0},{w2,0,s}};
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi.T1.Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p s}], {p, s, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
Print[""];
Print["== pairwise: True = conjugate =="];
Do[If[i < j, Print["  ", lab[[i]], "  ~  ", lab[[j]], " : ", conjQ[forms[[i]], forms[[j]]]]], {i, Length[forms]}, {j, Length[forms]}];
Print[""];
Print["== controls (must be False) =="];
Print["  0 ~ aId : ", conjQ[forms[[1]], forms[[6]]]];
Print["  e21 ~ e31 : ", conjQ[forms[[2]], forms[[3]]]];
Print["  e21+mu e33 ~ mu e33 : ", conjQ[forms[[11]], forms[[10]]]];
Print["  diag(a,0,a) ~ diag(a,0,mu) : ", conjQ[forms[[8]], forms[[16]]]];
Print["  diag(a,0,a) ~ diag(a,0,a)+e31 : ", conjQ[forms[[8]], forms[[9]]]];
Print["  aId ~ aId+e31 : ", conjQ[forms[[6]], forms[[7]]]];
Print["  e32 ~ e32+e31 : ", conjQ[forms[[13]], forms[[5]]]];
Print["  e23+mu e33 ~ e23+e31+mu e33 : ", conjQ[forms[[14]], forms[[15]]]];
Print["  e13+g e31+mu e33 ~ e23+mu e33 : ", conjQ[forms[[18]], forms[[14]]]];
Print["== controls (must be True): nu is redundant =="];
Print["  e23+2e31+3e33 ~ e23+5e31+3e33 : ",
  conjQ[{{0,0,0},{0,0,1},{2,0,3}}, {{0,0,0},{0,0,1},{5,0,3}}]];
Print["  e23+e31+3e33 ~ e23+e31+3e33 : ", conjQ[forms[[15]], forms[[15]]]];
Print["  e13+2e31+3e33 ~ e13+7e31+3e33 : ",
  conjQ[{{0,0,1},{0,0,0},{2,0,3}}, {{0,0,1},{0,0,0},{7,0,3}}]];
Print["  diag(2,0,5) ~ diag(2,0,5)+e21 (gamma killed) : ",
  conjQ[{{2,0,0},{0,0,0},{0,0,5}}, {{2,0,0},{1,0,0},{0,0,5}}]];

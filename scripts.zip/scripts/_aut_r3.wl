(* ============================================================
   Explicit automorphism groups of r3 and r3,lambda.
     r3      : [e1,e2] = e2,  [e1,e3] = e3
     r3,lam  : [e1,e2] = e2,  [e1,e3] = lam e3
   Claim to test (from the other agent):
     Aut(r3) = { phi(e1) = e1 + v (v in span(e2,e3)), phi|_n in GL(2) },
       semidirect GL(2) x| R^2,  dim 6, no det-coupling;
     Aut(r3,lam) for lam != 1 is the "diagonal subgroup", dim 4.
   ============================================================ *)
ClearAll["Global`*"];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];

autoSolve[B_, opts___] := Module[{cf, A, cols, vars, sys, detA, sol},
  cf = B - Transpose[B, {1,3,2}];            (* full antisymmetrised *)
  A = Array[ap, {3,3}]; cols = Table[A[[All,i]], {i,3}]; vars = Flatten[A];
  sys = Select[Flatten[Table[
     lie[cf, cols[[i]], cols[[j]]] - Sum[cf[[k,i,j]] cols[[k]], {k,3}],
     {i,3}, {j,3}]], # =!= 0 &];
  detA = Det[A];
  sol = Solve[Join[sys == 0, {detA tt - 1}], Join[vars, {tt}], Reals];
  {Length[sys], sys, sol}];

Print["================ r3 ================"];
B3 = SparseArray[{{2,1,2} -> 1, {3,1,3} -> 1}, {3,3,3}];
res3 = autoSolve[B3];
Print["#eq = ", res3[[1]]];
Print["equations = ", res3[[2]]];
Print["#branches = ", Length[res3[[3]]]];
Do[Print["  branch ", i, ": ", Simplify[res3[[3, i]]]], {i, Length[res3[[3]]]}];

Print[""];
Print["================ r3,lam (symbolic lam) ================"];
Bl = SparseArray[{{2,1,2} -> 1, {3,1,3} -> la}, {3,3,3}];
resl = autoSolve[Bl];
Print["#eq = ", resl[[1]]];
Print["equations = ", resl[[2]]];
Print["#branches = ", Length[resl[[3]]]];
Do[Print["  branch ", i, ": ", Simplify[resl[[3, i]]]], {i, Length[resl[[3]]]}];

Print[""];
Print["================ special values ================"];
Do[
  Bs = SparseArray[{{2,1,2} -> 1, {3,1,3} -> lv}, {3,3,3}];
  rs = autoSolve[Bs];
  Print["lam = ", lv, " : #eq = ", rs[[1]], ", #branches = ", Length[rs[[3]]]];
  Do[Print["    branch ", i, ": ", Simplify[rs[[3, i]]]], {i, Min[Length[rs[[3]]], 6]}],
  {lv, {1, -1, 2, 3}}];

Print[""];
Print["================ derivation algebras (control) ================"];
ClearAll[ddm];
Do[
  Bs = SparseArray[{{2,1,2} -> 1, {3,1,3} -> lv}, {3,3,3}];
  cf = Bs - Transpose[Bs, {1,3,2}];
  dd = Array[ddm, {3,3}];
  derEqs = Flatten[Table[
     Sum[dd[[p,i]] cf[[k,p,j]] + dd[[p,j]] cf[[k,i,p]] - cf[[p,i,j]] dd[[k,p]], {p,3}],
     {k,3}, {i,3}, {j,3}]];
  Print["  lam = ", lv, " : dim Der = ",
    9 - MatrixRank[Table[Coefficient[derEqs[[r]], ddm[a,b]], {r, Length[derEqs]}, {a,3}, {b,3}]]],
  {lv, {1, -1, 2, 3}}];

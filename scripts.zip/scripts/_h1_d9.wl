(* Independent check: h1 is 9 classes (user's claim).
   Key: corrected z-action formula z'^T = (w^T (X - lam I) + Delta z^T) M^-1
   (my earlier informal derivation dropped the -lam w^T term). *)
ClearAll["Global`*"];
sc = SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== 1. corrected conjugation formula (symbolic) =="];
M = {{m11,m12},{m21,m22}}; d = Det[M]; w = {w1,w2};
X = {{x11,x12},{x21,x22}}; z = {z1,z2}; lam = Symbol["lam"];
phi = {{M[[1,1]],M[[1,2]],0},{M[[2,1]],M[[2,2]],0},{w[[1]],w[[2]],d}};
T  = {{X[[1,1]],X[[1,2]],0},{X[[2,1]],X[[2,2]],0},{z[[1]],z[[2]],lam}};
Tp = phi . T . Inverse[phi] // Simplify;
Xp = Tp[[1;;2,1;;2]]; zp = {Tp[[3,1]],Tp[[3,2]]}; lamp = Tp[[3,3]];
fZ = Simplify[(w . (X - lam IdentityMatrix[2]) + d z) . Inverse[M]];
Print["  X' == M X M^-1            : ", Simplify[Xp - M.X.Inverse[M]] == 0*Xp];
Print["  z'^T == (w^T(X-lam I)+D z^T) M^-1 : ", Simplify[zp - fZ] == {0,0}];
Print["  lam' == lam               : ", Simplify[lamp - lam] == 0];

Print["== 2. nine canonical forms are averaging =="];
forms = <|
  "1  T=0"                 -> {{0,0,0},{0,0,0},{0,0,0}},
  "2  e3e1^T"              -> {{0,0,0},{0,0,0},{1,0,0}},
  "3  N+Z(1,0)"            -> {{0,1,0},{0,0,0},{1,0,0}},
  "4  N+Z(0,0)"            -> {{0,1,0},{0,0,0},{0,0,0}},
  "5  s e1e1^T"            -> {{2,0,0},{0,0,0},{0,0,0}},
  "6  s e1e1^T+e3e2^T"     -> {{2,0,0},{0,0,0},{0,1,0}},
  "7  r e3e3^T"            -> {{0,0,0},{0,0,0},{0,0,3}},
  "8  a Id3"               -> {{3,0,0},{0,3,0},{0,0,3}},
  "9  a Id3+e3e1^T"        -> {{3,0,0},{0,3,0},{1,0,3}}|>;
Do[r = resid[forms[k]]; Print["  ", k, ": resid = ", r, "  averaging? ", r == 0], {k, Keys[forms]}];

Print["== 3. D-family (X = a I, lam = a): z' = Delta z M^-1, z-nullity invariant =="];
(* z=0 stays 0; z != 0 normalizes to (1,0) via M = diag(z1/|...|, ...). Random checks. *)
Do[
  a0 = RandomReal[{-3,3}, 1][[1]]; If[a0 == 0, a0 = 1];
  z0 = RandomReal[{-3,3}, 2]; If[Norm[z0] < 0.1, z0 = {1,0}];
  M0 = RandomReal[{-1,1}, {2,2}] + 2 IdentityMatrix[2];
  d0 = Det[M0]; w0 = RandomReal[{-1,1}, 2];
  phi0 = {{M0[[1,1]],M0[[1,2]],0},{M0[[2,1]],M0[[2,2]],0},{w0[[1]],w0[[2]],d0}};
  T0 = {{a0,0,0},{0,a0,0},{z0[[1]],z0[[2]],a0}};
  Tp0 = phi0 . T0 . Inverse[phi0];
  (* predicted: z' = Delta z M^-1 *)
  zpred = d0 z0 . Inverse[M0];
  Print["  a=", a0, " z=", z0, " -> z' block = ", {Tp0[[3,1]],Tp0[[3,2]]}, "  predicted = ", zpred, "  match: ", Max[Abs[{Tp0[[3,1]],Tp0[[3,2]]} - zpred]] < 10^-12],
  {3}];

Print["== 4. class 8 vs 9 inequivalent: phi(Id3) = (Id3+e3e1^T) phi forces det M = 0 =="];
(* phi . A = B . phi  <=>  (B - a I) phi = 0  <=>  e3 e1^T phi = 0  <=>  first row of phi = 0  <=>  det M = 0. *)
M9 = {{m11,m12},{m21,m22}}; d9 = Det[M9]; w9 = {w1,w2};
phi9 = {{M9[[1,1]],M9[[1,2]],0},{M9[[2,1]],M9[[2,2]],0},{w9[[1]],w9[[2]],d9}};
A8 = IdentityMatrix[3]; B9 = {{1,0,0},{0,1,0},{1,0,1}}; (* a=1 *)
eqs9 = Flatten[phi9 . A8 - B9 . phi9];
Print["  equations phi A = B phi  (a=1): ", eqs9];
Print["  first row of phi = ", {phi9[[1,1]],phi9[[1,2]],phi9[[1,3]]}, " -> det M = ", Simplify[d9, And @@ Thread[eqs9[[1;;2]] == 0]]];

Print["== 5. user's example: (N,0) ~ (N,(0,1)) via w=(1,0), M=Id =="];
phiE = {{1,0,0},{0,1,0},{1,0,1}};
T_N0 = {{0,1,0},{0,0,0},{0,0,0}};
T_N01 = phiE . T_N0 . Inverse[phiE];
Print["  phi (N,0) phi^-1 = ", T_N01, "  (expect z'=(0,1))  resid = ", resid[T_N01]];

Print["== 6. Groebner unit-ideal check for (8,9) with a=1 =="];
vars = {m11,m12,m21,m22,w1,w2,s};
gb = GroebnerBasis[Join[eqs9, {d9 s - 1}], vars];
Print["  GroebnerBasis = ", gb, "  -> unit ideal? ", gb == {1}];

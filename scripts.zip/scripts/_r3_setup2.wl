(* ============================================================
   r3, step 1b: the beta = 0 branch in detail.
   GB of the beta = 0 system contains the factor
        (t11 - t22 - t33)(t22 - t33) = 0,
   so split into
        case I :  t22 = t33 =: mu
        case II:  t22 != t33,  hence t11 = t22 + t33 =: a
   and compute the GB of each.
   ============================================================ *)
ClearAll["Global`*"];
sc = SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}]; vars = Flatten[T];
avg[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
eqs0 = Select[DeleteDuplicates[Simplify[
     Flatten[Table[avg[i,j], {i,3},{j,3}]] /. {t[1,2] -> 0, t[1,3] -> 0}]], # =!= 0 &];
Print["beta = 0 system, #eq = ", Length[eqs0]];
Do[Print["   ", Simplify[eqs0[[i]]]], {i, Length[eqs0]}];

Print[""];
Print["== case I : t22 = t33 = mu =="];
sub1 = {t[2,2] -> mu, t[3,3] -> mu};
e1s = Select[DeleteDuplicates[Simplify[eqs0 /. sub1]], # =!= 0 &];
v1s = {t[1,1], t[2,1], t[3,1], t[2,3], t[3,2], mu};
Print["  #eq = ", Length[e1s]];
Do[Print["   ", Simplify[e1s[[i]]]], {i, Length[e1s]}];
gb1s = GroebnerBasis[e1s, v1s, MonomialOrder -> DegreeReverseLexicographic];
Print["  GB size = ", Length[gb1s]];
Do[Print["   g", i, " = ", Simplify[gb1s[[i]]]], {i, Length[gb1s]}];
sol1 = Solve[e1s == 0, v1s];
Print["  #Solve branches = ", Length[sol1]];
Do[Print["   branch ", i, " : ", Simplify[sol1[[i]]]], {i, Min[Length[sol1], 8]}];

Print[""];
Print["== case II : t22 != t33, a = t11 = t22 + t33 =="];
sub2 = {t[1,1] -> t[2,2] + t[3,3]};
e2s = Select[DeleteDuplicates[Simplify[eqs0 /. sub2]], # =!= 0 &];
v2s = {t[2,1], t[3,1], t[2,2], t[2,3], t[3,2], t[3,3]};
Print["  #eq = ", Length[e2s]];
Do[Print["   ", Simplify[e2s[[i]]]], {i, Length[e2s]}];
gb2s = GroebnerBasis[e2s, v2s, MonomialOrder -> DegreeReverseLexicographic];
Print["  GB size = ", Length[gb2s]];
Do[Print["   g", i, " = ", Simplify[gb2s[[i]]]], {i, Length[gb2s]}];
sol2 = Solve[e2s == 0, v2s];
Print["  #Solve branches = ", Length[sol2]];
Do[Print["   branch ", i, " : ", Simplify[sol2[[i]]]], {i, Min[Length[sol2], 8]}];

Print[""];
Print["== sanity: every solution of both cases solves the full system =="];
Print["  case I  : substituting a generic member of each Solve branch ->"];
Do[
  rep = sol1[[i]];
  chk = Simplify[Flatten[Table[avg[ii,jj], {ii,3},{jj,3}]] /. rep];
  Print["    branch ", i, " residual = ", chk], {i, Min[Length[sol1], 8]}];
Print["  case II : same check"];
Do[
  rep = sol2[[i]];
  chk = Simplify[Flatten[Table[avg[ii,jj], {ii,3},{jj,3}]] /. rep];
  Print["    branch ", i, " residual = ", chk], {i, Min[Length[sol2], 8]}];

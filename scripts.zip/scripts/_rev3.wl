(* is the missing-looking class  T = diag(a,0,a) + gamma2 e3 e1'  a solution, and is it new? *)
basis = {{1,0,0},{0,1,0},{0,0,1}};
A = {{1,0},{0,0}};
br[x_, y_] := Join[{0}, x[[1]] A.y[[2 ;; 3]] - y[[1]] A.x[[2 ;; 3]]];
resid[T_] := Simplify[Union[Flatten[Table[
     br[T.basis[[i]], T.basis[[j]]] - T.br[T.basis[[i]], basis[[j]]], {i,3},{j,3}]]]];

newForm = {{1, 0, 0}, {0, 0, 0}, {1, 0, 1}};   (* a=1, M=diag(0,1), gamma=(0,1) *)
Print["residual of diag(1,0,1)+e3e1' = ", resid[newForm]];

(* compare with the 15-list from _ext8.wl *)
forms = {
  {{0,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{0,0,0},{1,0,0}},
  {{0,0,0},{1,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{1,0,0}},
  {{0,0,0},{0,0,0},{0,0,2}},
  {{0,0,0},{0,0,1},{0,0,2}},
  {{0,0,0},{0,0,0},{0,1,2}},
  {{0,0,0},{0,0,1},{1,0,2}},
  {{0,0,0},{1,0,0},{0,0,2}},
  {{1,0,0},{0,1,0},{0,0,1}},
  {{1,0,0},{0,1,0},{1,0,1}},
  {{1,0,0},{0,0,0},{0,0,0}},
  {{1,0,0},{0,0,0},{0,0,2}},
  {{1,0,0},{0,1,0},{0,0,2}},
  {{1,0,1},{0,0,0},{0,0,1}},
  newForm
  };

B = {{p, 0}, {0, s}};
phi = {{1,0,0},{w1,B[[1,1]],B[[1,2]]},{w2,B[[2,1]],B[[2,2]]}};
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi.T1.Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z*p*s}], {p, s, w1, w2, z},
        MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];

Print["newForm conjugates to which of 1..15 ?  ",
  Select[Range[15], conjQ[newForm, forms[[#]]] &]];

(* Verify: (1) 5 normal forms averaging; (2) rank A NOT Aut-invariant, tr A IS *)
ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
blk[A_, B_, Cc_, Dm_] := ArrayFlatten[{{A, B}, {Cc, Dm}}];
avgRes[R_] := Max[Abs[Flatten[Table[
     br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]]]];
ok[R_] := avgRes[R] < 10.^-10;
E1 = {1, 0, 0};

Print["=== 1.  the five normal forms are averaging ==="];
norm = {
   {0 e3, Z3},
   {0 e3, e3},
   {0 e3, Outer[Times, E1, E1]},
   {lam e3, e3},
   {lam DiagonalMatrix[E1], Outer[Times, E1, E1]}};
Do[Print["  form ", k, ": ok = ", ok[blk[norm[[k, 1]], norm[[k, 2]], Z3, Z3]],
   "   (rankA, rankB) = (", MatrixRank[norm[[k, 1]]], ",", MatrixRank[norm[[k, 2]]], ")"],
  {k, Length[norm]}];

Print["=== 2.  rank A is NOT Aut-invariant (translation A -> A - BX) ==="];
(* form 2: A=0, B=Id; translation x=(1,2,3): A' = -X, rank 2 *)
xt = {1, 2, 3};
Xm = {{0, -xt[[3]], xt[[2]]}, {xt[[3]], 0, -xt[[1]]}, {-xt[[2]], xt[[1]], 0}};
A1 = -Xm;
Print["  form 2 under translation x=(1,2,3): A' = -X,  rank A' = ",
  MatrixRank[A1], "  (was 0).  tr A' = ", Tr[A1], "  (was 0)."];
Print["  => rank A is not an Aut-invariant; the draft's (rank A, rank B) ",
  "argument needs fixing."];

Print["=== 3.  tr A IS Aut-invariant on Case-2 solutions (B symmetric) ==="];
Print["  check tr(B X) = 0 for all symmetric B, skew X: ",
  Max[Abs[Flatten[Table[
      With[{Bs = RandomReal[{-1, 1}, {3, 3}] + Transpose[RandomReal[{-1, 1}, {3, 3}]],
        Xs = {{0, -x3, x2}, {x3, 0, -x1}, {-x2, x1, 0}},
        {x1, x2, x3} = RandomReal[{-1, 1}, 3]},
       Tr[Bs . Xs]], {100}]]]]];
Print["  invariant values on the five forms (rank B, tr A):"];
Do[Print["    form ", k, " : (", MatrixRank[norm[[k, 2]]], ", ",
   Simplify[Tr[norm[[k, 1]]]], ")  -> pairwise distinct"], {k, Length[norm]}];

Print["=== 4.  Case 3 intermediate B=C=0: equation check ==="];
(* T = [[A,0],[0,D]]: verify that (h,h) is A-averaging and the two coupled
   conditions; a random non-solution must fail *)
T3 = blk[AA0, Z3, Z3, DD0] /. {AA0 -> DiagonalMatrix[{2, 0, 0}], DD0 -> 2 e3};
Print["  A=diag(2,0,0), D=2I (A averaging, D scalar): averaging? ",
  ok[T3]];
T4 = blk[AA0, Z3, Z3, DD0] /. {AA0 -> DiagonalMatrix[{2, 0, 0}], DD0 -> DiagonalMatrix[{2, 3, 0}]};
Print["  A=diag(2,0,0), D=diag(2,3,0): averaging? ", ok[T4]];
Print["Done."];

(* is  T = e2 e3' + nu e3 e1' + mu e3 e3'  a solution, and is it new? *)
basis = {{1,0,0},{0,1,0},{0,0,1}};
A = {{1,0},{0,0}};
br[x_, y_] := Join[{0}, x[[1]] A.y[[2 ;; 3]] - y[[1]] A.x[[2 ;; 3]]];
residV[T_] := Flatten[Table[br[T.basis[[i]], T.basis[[j]]] - T.br[T.basis[[i]], basis[[j]]], {i,3},{j,3}]];

newT = {{0, 0, 1}, {0, 0, 0}, {2, 0, 3}};   (* nu = 2, mu = 3 *)
Print["residual of the 2-parameter candidate = ", Simplify[Union[residV[newT]]]];

B = {{p, 0}, {0, s}};
phi = {{1,0,0},{w1,B[[1,1]],B[[1,2]]},{w2,B[[2,1]],B[[2,2]]}};
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi.T1.Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z*p*s}], {p, s, w1, w2, z},
        MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];

class6  = {{0,0,1},{0,0,0},{0,0,3}};    (* e2e3' + 3 e3e3'   *)
class15 = {{1,0,1},{0,0,0},{0,0,3}};    (* a e1e1' + e2e3' + 3 e3e3' *)
Print["candidate ~ class6 ?  ", conjQ[newT, class6]];
Print["candidate ~ class15 ? ", conjQ[newT, class15]];

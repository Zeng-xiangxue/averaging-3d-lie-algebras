ClearAll["Global`*"];
W[v_] := {{0, -v[[3]], v[[2]]}, {v[[3]], 0, -v[[1]]}, {-v[[2]], v[[1]], 0}};

(* counterexample: C and C^T have the same characteristic polynomial *)
S3 = DiagonalMatrix[{1, 2, 3}];
C1 = S3 + W[{1, 1, 1}];
C2 = Transpose[C1];
Print["char poly C1 = ", Factor[CharacteristicPolynomial[C1, x]]];
Print["char poly C2 = ", Factor[CharacteristicPolynomial[C2, x]]];
Print["same char poly? ", CharacteristicPolynomial[C1, x] === CharacteristicPolynomial[C2, x]];
Print["C1 symmetric? ", C1 === Transpose[C1], "   eigenvalues ", Eigenvalues[N[C1]]];

(* is there R in O(3) with R C1 = C2 R ? *)
R = Array[r, {3, 3}];
sys = Join[Flatten[R . C1 - C2 . R], Flatten[Transpose[R] . R - IdentityMatrix[3]]];
t = AbsoluteTiming[
   sol = TimeConstrained[Reduce[sys == 0, Flatten[R], Reals], 240, "TIMEOUT"];][[1]];
Print[""];
Print["Reduce over Reals, t = ", Round[t, 0.01], " s"];
Print["result: ", If[sol === "TIMEOUT", "TIMEOUT", sol]];

(* how big is the solution space of R C1 = C2 R (no orthogonality) ? *)
lin = Flatten[R . C1 - C2 . R];
Print[""];
Print["dim of {R : R C1 = C2 R} = ",
  9 - MatrixRank[Table[Coefficient[lin[[k]], #] & /@ Flatten[R], {k, 9}][[All]]] //
   Identity];
Print["  (so C1 and C2 ARE similar: they have the same char poly and distinct eigenvalues)"];

(* parameter count of the SO(3)-canonical form of a general C = S + W_k *)
Print[""];
Print["SO(3)-canonical form of a general C = S + W_k:"];
Print["  k != 0 : use 2 rotation parameters to put k = kappa*e3, then the residual"];
Print["           SO(2) to kill the (1,2) entry of S.  Left over:"];
Print["           kappa, s11, s22, s33, s13, s23   ->  6 parameters"];
Print["  k = 0  : C symmetric, class = eigenvalue triple  ->  3 parameters"];
Print["  (space is 9-dimensional, SO(3) is 3-dimensional, so 9-3 = 6: consistent)"];
Print[""];
Print["verified on a random C :"];
SeedRandom[4];
Cc = RandomReal[{-2, 2}, {3, 3}];
Sm = (Cc + Transpose[Cc])/2; Km = (Cc - Transpose[Cc])/2;
kv = {Km[[3, 2]], Km[[1, 3]], Km[[2, 1]]};
Print["  random C, its k vector = ", N[kv, 4], "  |k| = ", N[Norm[kv], 4]];
(* rotate so k -> |k| e3 *)
Rk = If[Norm[kv] < 10.^-12, IdentityMatrix[3], RotationMatrix[{kv, {0, 0, 1}}]];
S1 = Rk . Sm . Transpose[Rk];
Print["    after Rk:  Rk.k = ", N[Chop[Rk . kv], 4], "   (along e3)"];
Print["    S in the new frame = ", N[Chop[S1], 4]];
(* residual SO(2) about e3 : choose theta to kill the (1,2) entry *)
entry12[t_] := (RotationMatrix[t, {0, 0, 1}] . S1 .
     Transpose[RotationMatrix[t, {0, 0, 1}]])[[1, 2]];
th0 = t /. FindRoot[entry12[t] == 0, {t, 0.3}];
Rz = RotationMatrix[th0, {0, 0, 1}];
Rfull = Rz . Rk;
Print["    full rotation: S = ", N[Chop[Rfull . Sm . Transpose[Rfull]], 4]];
Print["    full rotation: k = ", N[Chop[Rfull . kv], 4]];
Print["    (1,2) entry now = ",
  N[Chop[(Rfull . Sm . Transpose[Rfull])[[1, 2]]], 3], "   kappa = ",
  N[Chop[Norm[Rfull . kv]], 4]];

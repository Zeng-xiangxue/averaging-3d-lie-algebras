(* verify the conjugation law of the second component for r(c), c = 0 *)
ClearAll["Global`*"];
A0 = {{0, -1}, {1, 0}};
br[x_, y_] := Join[{0}, x[[1]] A0 . y[[2 ;; 3]] - y[[1]] A0 . x[[2 ;; 3]]];
e = IdentityMatrix[3];
phi = {{-1, 0, 0}, {w1, p, q}, {w2, q, -p}};
Print["phi automorphism residual = ", Simplify[Max[Abs[Flatten[Table[
   br[phi . e[[i]], phi . e[[j]]] - phi . br[e[[i]], e[[j]]], {i,3},{j,3}]]]]]];
T = {{a1, b1, b2}, {g1, m11, m12}, {g2, m21, m22}};
Tc = Simplify[phi . T . Inverse[phi]];
Print["a'  = ", Simplify[Tc[[1,1]] - (a1 - (b1*w1 + b2*w2)/p ... )]];

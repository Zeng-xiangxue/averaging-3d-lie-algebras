(* Verify the corrected B=C=0 classification for A = lam u u^T:
   (c) D = mu u u^T  OR  D = lam (I - u u^T);  check for a third family *)
ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
blk[A_, B_, Cc_, Dm_] := ArrayFlatten[{{A, B}, {Cc, Dm}}];
avgRes[R_] := Max[Abs[Flatten[Table[
     br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]]]];
ok[R_] := avgRes[R] < 10.^-10;
E1 = {1, 0, 0};

Print["=== 1.  A = 3 e1 e1^T : the two families ==="];
A3 = 3 DiagonalMatrix[E1];
Print["  D = 5 e1 e1^T             : ", ok[blk[A3, Z3, Z3, 5 Outer[Times, E1, E1]]]];
Print["  D = 3 (I - e1 e1^T)        : ",
  ok[blk[A3, Z3, Z3, 3 (e3 - Outer[Times, E1, E1])]]];
Print["  D = 5 (I - e1 e1^T) (wrong lam): ",
  ok[blk[A3, Z3, Z3, 5 (e3 - Outer[Times, E1, E1])]]];
Print["  D = mu e1 e1^T, mu = -2     : ",
  ok[blk[A3, Z3, Z3, -2 Outer[Times, E1, E1]]]];
Print["  D = 0                       : ", ok[blk[A3, Z3, Z3, Z3]]];

Print["=== 2.  general axis u ==="];
u = {1, 1, 1}/Sqrt[3];
uu = Outer[Times, u, u];
Print["  A = 3 u u^T, D = 5 u u^T   : ", ok[blk[3 uu, Z3, Z3, 5 uu]]];
Print["  A = 3 u u^T, D = 3(I-uu^T) : ",
  ok[blk[3 uu, Z3, Z3, 3 (e3 - uu)]]];
Print["  A = 3 u u^T, D = 5(I-uu^T) : ",
  ok[blk[3 uu, Z3, Z3, 5 (e3 - uu)]]];

Print["=== 3.  symbolic Solve for A = lam diag(1,0,0) ==="];
AA = Array[aa, {3, 3}]; DD = Array[dd, {3, 3}];
T3 = blk[AA, Z3, Z3, DD];
eqs = Select[DeleteDuplicates[Expand[Flatten[Table[
     br[T3 . e6[[i]], T3 . e6[[j]]] - T3 . br[T3 . e6[[i]], e6[[j]]],
     {i, 6}, {j, 6}]]]], # =!= 0 &];
gD = Select[DeleteDuplicates[Expand[eqs /.
     Thread[Flatten[AA] -> Flatten[lam DiagonalMatrix[E1]]]]], # =!= 0 &];
Print["  distinct conditions: ", Length[gD]];
sol = TimeConstrained[Solve[gD == 0, Flatten[DD]], 120, "TO"];
Print["  Solve head: ", Head[sol], "  #branches: ",
  If[ListQ[sol], Length[sol], "-"]];
If[ListQ[sol], Do[Print["  branch ", k, ": ", Simplify[sol[[k]]]], {k, Length[sol]}]];

Print["=== 4.  random search for a THIRD family (A = 3 e1 e1^T) ==="];
SeedRandom[11];
cnt = 0; third = 0;
Do[
  Dm = Partition[RandomReal[{-5, 5}, 9], 3];
  If[ok[blk[A3, Z3, Z3, Dm]],
    cnt++;
    (* is it of the two known types? type1: D = mu e1 e1^T  <=> only (1,1) nonzero;
       type2: D = lam(I - e1e1^T) <=> (1,1)=0, (2,2)=(3,3), off-diag in e1^perp zero *)
    m11 = Dm[[1, 1]]; rest = Dm - m11 Outer[Times, E1, E1];
    t1 = Max[Abs[Flatten[rest]]];
    t2 = Max[Abs[{Dm[[1, 1]], Dm[[2, 3]], Dm[[3, 2]], Dm[[2, 2]] - Dm[[3, 3]]}]];
    If[Min[t1, t2] > 10.^-8, third++]], {3000}];
Print["  hits: ", cnt, "  ;  not of either known type: ", third];
Print["Done."];

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
ok[R_] := AllTrue[Flatten[avgDef[R]], (Simplify[#] === 0) &];
TAB[A_, Bb_, Cc_, Dm_] := ArrayFlatten[{{A, Bb}, {Cc, Dm}}];
E1 = {1, 0, 0}; E2 = {0, 1, 0}; E3 = {0, 0, 1};
Av = 3 Outer[Times, E1, E1];
P[i_, j_] := Outer[Times, {E1, E2, E3}[[i]], {E1, E2, E3}[[j]]];
chk[n_, Bb_, Cc_, Dd_] := Print["  ", n, " : ", ok[TAB[Av, Bb, Cc, Dd]]];

Print["=== probe: rank C = 1, B of various rank-1 shapes (A = 3 e1e1^T) ==="];
Do[chk["B = e" <> ToString[a] <> "e" <> ToString[b] <> "^T, C = e1e1^T, D = 5e1e1^T  ",
   P[a, b], P[1, 1], 5 P[1, 1]], {a, 3}, {b, 3}];
Print[""];
Print["=== probe: rank C = 1 with l = e1, phi arbitrary, B = e1e1^T ==="];
Do[chk["phi = " <> ToString[ph], P[1, 1], Outer[Times, E1, ph], 5 P[1, 1]],
  {ph, {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {1, 1, 0}, {0, 1, 1}}}];
Print[""];
Print["=== probe: D other than beta e1e1^T with B = e1e1^T, C = e1e1^T ==="];
Do[chk["D = " <> ToString[d], P[1, 1], P[1, 1], d],
  {d, {P[2, 2], P[3, 3], DiagonalMatrix[{2, -3, -3}], 4 e3, Z3,
    DiagonalMatrix[{2, 0, 0}]}}];

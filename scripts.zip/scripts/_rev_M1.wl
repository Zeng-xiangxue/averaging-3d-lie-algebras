(* M1: r_D (D=J) 的 27 个分量方程 <==> eq:sol（双向，Groebner + PolynomialReduce） *)
ClearAll["Global`*"];
e = IdentityMatrix[3]; T = Array[t, {3, 3}]; vars = Flatten[T];
lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k, i, j]], {i, 3}, {j, 3}], {k, 3}];
resid[cf_] := Select[DeleteDuplicates[Flatten[Table[
     lie[cf, T[[All, i]], T[[All, j]]] - T . lie[cf, T[[All, i]], e[[j]]], {i, 3}, {j, 3}]]], # =!= 0 &];
scJ = SparseArray[{{2, 1, 2} -> 1, {2, 2, 1} -> -1, {2, 1, 3} -> 1, {2, 3, 1} -> -1,
    {3, 1, 3} -> 1, {3, 3, 1} -> -1}, {3, 3, 3}];
rawJ = resid[scJ];
a = t[1, 1]; bb = {t[1, 2], t[1, 3]}; gam = {t[2, 1], t[3, 1]};
M = {{t[2, 2], t[2, 3]}, {t[3, 2], t[3, 3]}}; AJ = {{1, 1}, {0, 1}};
redJ = Flatten[{bb, Flatten[M . AJ . M - a AJ . M], M . AJ . gam, a (M . AJ - AJ . M)}];
Print["rawJ 非零分量个数 = ", Length[rawJ], "，redJ 个数 = ", Length[redJ]];
gRaw = GroebnerBasis[rawJ, vars, MonomialOrder -> DegreeReverseLexicographic];
gRed = GroebnerBasis[redJ, vars, MonomialOrder -> DegreeReverseLexicographic];
Print["gb(rawJ) 元素个数 = ", Length[gRaw], "，gb(redJ) 元素个数 = ", Length[gRed]];
Print["raw ==> reduced : ",
  And @@ (Simplify[PolynomialReduce[#, gRaw, vars][[2]]] === 0 & /@ redJ)];
Print["reduced ==> raw : ",
  And @@ (Simplify[PolynomialReduce[#, gRed, vars][[2]]] === 0 & /@ rawJ)];
fail = Select[redJ, Simplify[PolynomialReduce[#, gRaw, vars][[2]]] =!= 0 &];
Print["仅在理想层面失败、待做 Rabinowitsch 的元素个数 = ", Length[fail]];
If[Length[fail] > 0,
  zz = z;
  radOK = {};
  Do[
    u = GroebnerBasis[Join[rawJ, {1 - zz f}], Append[vars, zz],
       MonomialOrder -> DegreeReverseLexicographic];
    AppendTo[radOK, {f, u === {1}}];
    , {f, fail}];
  Print["Rabinowitsch（rawJ 的解集上该式恒为零）逐条结果："];
  Do[Print["   ", radOK[[i, 1]], "  ->  ", radOK[[i, 2]]], {i, Length[radOK]}];
  ];

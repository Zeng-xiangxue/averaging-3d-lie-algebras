(* Check user's corrections on sl2:
   1) shift formula: defect(T+cI) = defect(T) + c([x,Ty]-T[x,y])  (symbolic)
   2) explicit counterexamples resid = 0
   3) rank-1 family T = v w^T, condition w in ker(ad_v^T)
   4) End_g(g) = R Id (numerical)
   5) invertible (rank-3) non-scalar T are NOT solutions
   6) rank-2 candidates NOT solutions
   7) elliptic/parabolic/hyperbolic discriminant *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== 1. shift formula (symbolic) =="];
TT = Table[t[i,j], {i,3}, {j,3}];
def[T_,x_,y_] := lie[sc, T.x, T.y] - T . lie[sc, T.x, y];
cc = c;
expr = def[TT + cc IdentityMatrix[3], unit[[1]], unit[[3]]];
lhs = def[TT, unit[[1]], unit[[3]]] + cc (lie[sc, unit[[1]], TT[[All,3]]] - TT . lie[sc, unit[[1]], unit[[3]]]);
Print["  defect(T+cI)(e1,e3) = ", expr];
Print["  defect(T)+c([e1,Te3]-T[e1,e3]) = ", lhs];
Print["  equal? diff = ", Simplify[expr - lhs], "   (want {0,0,0})"];
Print["  defect(c I)(e1,e3) = ", def[cc IdentityMatrix[3], unit[[1]], unit[[3]]], "  (want 0)"];

Print["== 2. explicit counterexamples =="];
T1 = {{5/2, 1, -1}, {-5, -2, 2}, {-25/4, -5/2, 5/2}};
Print["  T1 resid = ", resid[T1], "  tr = ", Tr[T1]];
T2 = {{0, 1, -2}, {0, -1, 2}, {0, 0, 0}};
Print["  T2 resid = ", resid[T2], "  tr = ", Tr[T2]];
v = {1, -2, -5/2}; w = {5/2, 1, -1};
Print["  v.w = ", v . w];
Print["  w^T ad_v = ", Table[w . lie[sc, v, unit[[j]]], {j, 3}], "  (user claims (0,0,0))"];
Print["  v^T ad_w = ", Table[v . lie[sc, w, unit[[j]]], {j, 3}]];

Print["== 3. rank-1 family condition (symbolic) =="];
vv = {a, b, d2}; ww = {p, q, r2};
T3 = KroneckerProduct[vv, ww];
conds = Table[ww . lie[sc, vv, unit[[j]]], {j, 3}];
resid3 = Flatten[Table[
  lie[sc, T3.unit[[i]], T3.unit[[j]]] - T3 . lie[sc, T3.unit[[i]], unit[[j]]], {i,3},{j,3}]];
Print["  resid(T=vw^T) under w.[v,e_j]=0: ", Simplify[resid3 /. Thread[conds -> 0]]];
Print["  resid(T=vw^T) raw factors: ", DeleteDuplicates[Simplify[resid3]]];
Print["  rank(ad_v) for generic v = ", MatrixRank[Table[lie[sc, {1.1, -2.3, 0.7}, unit[[j]]], {j, 3}]]];

Print["== 4. End_g(g) = R Id (numerical) =="];
admat[a_] := Table[lie[sc, a, unit[[j]]], {j, 3}];
vars4 = Flatten[Table[mm[i,j], {i,3}, {j,3}]];
MM4 = Table[mm[i,j], {i,3}, {j,3}];
sol4 = FindInstance[Flatten[Table[MM4 . admat[unit[[j]]] == admat[unit[[j]]] . MM4, {j,3}]] && Det[MM4] == 1, vars4, Reals][[1]];
MM0 = MM4 /. sol4;
Print["  MM commuting with all ad: scalar? ", Max[Abs[MM0 - (Tr[MM0]/3) IdentityMatrix[3]]] < 10^-9];
Print["  MM = ", MatrixForm[MM0]];

Print["== 5. invertible non-scalar T are NOT solutions =="];
cnt = 0;
Do[
  M0 = RandomReal[{-2,2}, {3,3}];
  If[Abs[Det[M0]] > 1 && Max[Abs[M0 - (Tr[M0]/3) IdentityMatrix[3]]] > 0.1,
    If[resid[M0] < 10^-9, Print["  FOUND invertible non-scalar solution! ", MatrixForm[M0]]; cnt++]; ],
  {30}];
Print["  found = ", cnt, " (expect 0)"];

Print["== 6. rank-2 candidates =="];
Print["  diag(1,1,0) resid = ", resid[{{1,0,0},{0,1,0},{0,0,0}}]];
Print["  diag(0,1,1) resid = ", resid[{{0,0,0},{0,1,0},{0,0,1}}]];

Print["== 7. discriminant =="];
SS = Table[s[i,j], {i,3}, {j,3}];
trS2 = Tr[SS . SS]; dt = Det[SS];
Print["  charpoly traceless S = lambda^3 - (tr S^2/2) lambda - det: ",
  Simplify[CharacteristicPolynomial[SS /. {s[1,1] -> -s[2,2] - s[3,3]}, L] - (L^3 - trS2/2 L - dt) /. {s[1,1] -> -s[2,2] - s[3,3]}]];
Print["  random traceless symmetric samples: ",
  Table[Module[{S0 = RandomReal[{-1,1}, {3,3}]}, S0 = S0 + Transpose[S0]; S0 = S0 - (Tr[S0]/3) IdentityMatrix[3];
    {Tr[S0 . S0], Det[S0], N[Eigenvalues[S0]]}], {3}]];

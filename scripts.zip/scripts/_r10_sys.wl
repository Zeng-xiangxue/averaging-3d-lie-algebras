ClearAll["Global`*"];
br[x_, y_] := {0, x[[1]] y[[2]] - y[[1]] x[[2]], 0};
e = IdentityMatrix[3];
T = {{a, b1, b2}, {g1, m11, m12}, {g2, m21, m22}};
vars = {a, b1, b2, g1, g2, m11, m12, m21, m22};
raw = Select[DeleteDuplicates[Flatten[Table[
   br[T.e[[i]], T.e[[j]]] - T.br[T.e[[i]], e[[j]]], {i, 3}, {j, 3}]]], # =!= 0 &];
paper = {b1, m11 (m11 - a), m11 g1, m11 b2, m11 m12, b2 g1 - a m12, m21 a, m21 g1, m21 b2, m21 m12};
r1 = Reduce[Implies[And @@ Thread[raw == 0], And @@ Thread[paper == 0]], vars, Reals];
Print["raw ==> paper : ", r1 === True, "   (", Head[r1], ")"];
If[r1 =!= True, Print[Short[r1]]];
r2 = Reduce[Implies[And @@ Thread[paper == 0], And @@ Thread[raw == 0]], vars, Reals];
Print["paper ==> raw : ", r2 === True];

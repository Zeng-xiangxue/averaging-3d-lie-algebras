(* r(c) with the CORRECT centralizer  B = {{a,b},{-b,a}} *)
ClearAll["Global`*"];
e = IdentityMatrix[3];
A = {{1,-1},{1,1}};
brC[x_,y_] := Join[{0}, x[[1]] A . y[[2;;3]] - y[[1]] A . x[[2;;3]]];
resC[T_] := Max[Abs[Flatten[Table[brC[T.e[[i]],T.e[[j]]] - T.brC[T.e[[i]],e[[j]]],{i,3},{j,3}]]]];
(* is the paper's parametrisation complete?  90-degree element: *)
B90 = {{0,-1},{1,0}};
Print["does B90 commute with A ? ", Simplify[B90 . A - A . B90] === {{0,0},{0,0}}];
Print["B90 = p {{1,-t},{t,1}} for some p,t ? ", Solve[{{p, -p t},{p t, p}} == B90, {p, t}]];
phi = {{1,0,0},{w1,a,bB},{w2,-bB,a}};
conj[T1_,T2_] := Module[{eqs,gb},
  eqs = Numerator /@ Together /@ Flatten[phi . T1 . Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z (a^2 + bB^2)}], {a,bB,w1,w2,z}, MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
Tc[lam_] := {{0,0,0},{0,-lam,lam},{0,0,0}};
Talt     := {{0,0,0},{0,0,0},{0,1,1}};
four = {{"0", {{0,0,0},{0,0,0},{0,0,0}}},
        {"e2e1'", {{0,0,0},{1,0,0},{0,0,0}}},
        {"a Id", 2 IdentityMatrix[3]},
        {"a e1e1'", {{2,0,0},{0,0,0},{0,0,0}}}};
Print["residuals: family=", resC[Tc[1]], "  alt=", resC[Talt]];
Do[Print["  family(1) ~ ", four[[k,1]], " ? ", conj[Tc[1], four[[k,2]]]], {k,4}];
Print["  family(1) ~ family(-1) ? ", conj[Tc[1], Tc[-1]]];
Print["  family(1) ~ family(2)  ? ", conj[Tc[1], Tc[2]]];
Print["  alt(trace 1) ~ family(-1)(trace 1) ? ", conj[Talt, Tc[-1]]];
Print["  pairwise of the four listed classes:"];
Do[If[i<j, Print["     ", four[[i,1]], " ~ ", four[[j,1]], " ? ", conj[four[[i,2]], four[[j,2]]]]], {i,4}, {j,4}];

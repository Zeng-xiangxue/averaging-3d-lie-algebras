#!/usr/bin/env wolframscript
(* ==================================================================
   _se3_regionZ_Ali_check.wl -- Region Z, A = lambda I branch:
   verify the family  T = [[lam I, 0],[c I, lam I]]  (B = 0, C = cI, D = lam I)
   plus negatives and the return-to-Y case.
   ASCII-only source on purpose.
   ================================================================== *)

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
ok[R_] := AllTrue[Flatten[avgDef[R]], (Simplify[#] === 0) &];
TAB[AA_, BB_, CC_, DD_] := ArrayFlatten[{{AA, BB}, {CC, DD}}];
W[u_] := {{0, -u[[3]], u[[2]]}, {u[[3]], 0, -u[[1]]}, {-u[[2]], u[[1]], 0}};

Print["=== Region Z : A = lambda I  ==>  B = 0, C = c I, D = lambda I ==="];
Print["  (lam,c) = (3,5)    : ", ok[TAB[3 e3, Z3, 5 e3, 3 e3]]];
Print["  (lam,c) = (3,-2)   : ", ok[TAB[3 e3, Z3, -2 e3, 3 e3]]];
Print["  (lam,c) = (1,7)    : ", ok[TAB[e3, Z3, 7 e3, e3]]];
Print["  (negative) B = 2 I : ", ok[TAB[3 e3, 2 e3, 5 e3, 3 e3]]];
Print["  (negative) D = 5 I (delta != lam) : ", ok[TAB[3 e3, Z3, 5 e3, 5 e3]]];
Print["  (negative) C = 2 diag(0,1,1) (not scalar) : ",
  ok[TAB[3 e3, Z3, 2 DiagonalMatrix[{0, 1, 1}], 3 e3]]];
Print[""];
Print["=== return-to-Y check : A = 3 I, B = 0, C = ad_u, D = 0 ==="];
Print["  C = ad_{(1,2,3)} : ", ok[TAB[3 e3, Z3, W[{1, 2, 3}], Z3]]];
Print[""];
Print["=== Region Z : A = lam u u^T (u = e1), rank C >= 2 forces B = 0 ==="];
Print["  B = 0, C = diag(1,1,0), D = 0 : ", ok[TAB[3 Outer[Times, {1, 0, 0}, {1, 0, 0}], Z3,
    DiagonalMatrix[{1, 1, 0}], Z3]]];
Print["  (negative) B = e2 e2^T, C = diag(1,1,0), D = 0 : ",
  ok[TAB[3 Outer[Times, {1, 0, 0}, {1, 0, 0}], Outer[Times, {0, 1, 0}, {0, 1, 0}],
    DiagonalMatrix[{1, 1, 0}], Z3]]];
Print["  (negative) B = e1 e1^T, C = diag(1,1,0), D = 0 : ",
  ok[TAB[3 Outer[Times, {1, 0, 0}, {1, 0, 0}], Outer[Times, {1, 0, 0}, {1, 0, 0}],
    DiagonalMatrix[{1, 1, 0}], Z3]]];
Print[""];
Print["Done."];

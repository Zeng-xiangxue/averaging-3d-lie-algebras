(* Independent check of user's claims:
   1) lambda=-1 anti-diagonal component of Aut(r_{3,-1});
   2) r_{3,lambda} ~= r_{3,1/lambda} isomorphism;
   3) the four conjugation rules for r3 blocks. *)
ClearAll["Global`*"];

(* ---- 1. Aut(r_{3,lambda}) structure, solved symbolically ---- *)
sc[lam_] := SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->lam, {3,3,1}->-lam}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
autResid[lam_, phi_] := Max[Abs[Flatten[Table[
  phi . lie[sc[lam], unit[[i]], unit[[j]]] - lie[sc[lam], phi[[All,i]], phi[[All,j]]], {i,3}, {j,3}]]]];

Print["== 1a. lambda = -1 : anti-diagonal component phi(e1)=-e1+v, phi(e2)=r e3, phi(e3)=q e2 =="];
Do[
  v1 = RandomReal[{-3,3}, 1][[1]]; v2 = RandomReal[{-3,3}, 1][[1]];
  r = RandomReal[{-3,3}, 1][[1]]; If[Abs[r] < 0.1, r = 1]; 
  q = RandomReal[{-3,3}, 1][[1]]; If[Abs[q] < 0.1, q = 1];
  (* columns: phi(e1)=(-1,v1,v2), phi(e2)=(0,0,r), phi(e3)=(0,q,0) *)
  phi = {{-1, 0, 0}, {v1, 0, q}, {v2, r, 0}};
  Print["  v=(", v1, ",", v2, ") r=", r, " q=", q, "  det=", Det[phi], "  autResid=", autResid[-1, phi]],
  {3}];

Print["== 1b. lambda = 2 : only diagonal component (a11=1, phi|n diagonal) =="];
Do[
  v1 = RandomReal[{-3,3}, 1][[1]]; v2 = RandomReal[{-3,3}, 1][[1]];
  a22 = RandomReal[{-3,3}, 1][[1]]; If[Abs[a22] < 0.1, a22 = 1];
  a33 = RandomReal[{-3,3}, 1][[1]]; If[Abs[a33] < 0.1, a33 = 1];
  phi = {{1, 0, 0}, {v1, a22, 0}, {v2, 0, a33}};
  Print["  v=(", v1, ",", v2, ") a22=", a22, " a33=", a33, "  autResid=", autResid[2, phi]],
  {3}];
(* negative: a generic phi with a11 != 1 must fail for lambda=2 *)
phiBad = {{3, 0, 0}, {0, 1, 0}, {0, 0, 1}};
Print["  negative: phi(e1)=3 e1 at lambda=2, resid = ", autResid[2, phiBad], "  (must be > 0)"];

Print["== 1c. at lambda=-1, mixed/offdiag failures =="];
(* phi(e2) = r e3 + s e2 with both nonzero should fail unless diagonal *)
phiMix = {{1, 0, 0}, {0, 2, 0}, {0, 1, 3}};  (* a22=2,a32=1,a33=3 at lambda=-1: a22(a11-1)=0 ok, a32(a11*lam-1)=1(-2)!=0 *)
Print["  phi(e2)=2e2+1e3, a11=1, lambda=-1: resid = ", autResid[-1, phiMix], "  (must be > 0)"];

Print["== 2. r_{3,lambda} ~= r_{3,1/lambda} : psi(e1)=lam e1', psi(e2)=c2 e3', psi(e3)=c3 e2' =="];
(* check psi preserves brackets as map from r3,lam to r3,mu with mu=1/lam *)
psi[lam_, c2_, c3_] := {{lam, 0, 0}, {0, 0, c3}, {0, c2, 0}};  (* columns: psi(e1), psi(e2), psi(e3) *)
Do[
  lam0 = RandomReal[{0.3, 3}, 1][[1]];
  c2 = RandomReal[{-2, 2}, 1][[1]]; If[Abs[c2] < 0.1, c2 = 1];
  c3 = RandomReal[{-2, 2}, 1][[1]]; If[Abs[c3] < 0.1, c3 = 1];
  mu = 1/lam0;
  P = psi[lam0, c2, c3];
  (* compare P.lie[sc[lam0],ei,ej]  vs  lie[sc[mu], P.ei, P.ej] *)
  err = Max[Abs[Flatten[Table[
    P . lie[sc[lam0], unit[[i]], unit[[j]]] - lie[sc[mu], P[[All,i]], P[[All,j]]], {i,3}, {j,3}]]]];
  Print["  lam=", lam0, " mu=", mu, " c2=", c2, " c3=", c3, "  isoResid = ", err],
  {3}];
Print["  special: lambda=-1 gives psi(e1)=-e1', psi(e2)=e3', psi(e3)=e2' (anti-diagonal) - check resid:"];
Pm = psi[-1, 1, 1];
Print["  isoResid = ", Max[Abs[Flatten[Table[Pm . lie[sc[-1], unit[[i]], unit[[j]]] - lie[sc[-1], Pm[[All,i]], Pm[[All,j]]], {i,3}, {j,3}]]]]];

Print["== 3. r3 conjugation rules (symbolic) =="];
(* T = {{a, bt},{g, D}}, phi = {{1,0},{v,B}} on n = span(e2,e3).  n-block of r3. *)
B = {{b11,b12},{b21,b22}}; v = {v1,v2}; D = {{d11,d12},{d21,d22}}; g = {g1,g2}; bt = {bt1,bt2}; a = Symbol["a"];
phi3 = {{1,0,0},{v[[1]],B[[1,1]],B[[1,2]]},{v[[2]],B[[2,1]],B[[2,2]]}};
T3  = {{a,bt[[1]],bt[[2]]},{g[[1]],D[[1,1]],D[[1,2]]},{g[[2]],D[[2,1]],D[[2,2]]}};
Tp3 = Simplify[phi3 . T3 . Inverse[phi3]];
ap  = Tp3[[1,1]];
btp = {Tp3[[1,2]],Tp3[[1,3]]};
gp  = {Tp3[[2,1]],Tp3[[3,1]]};
Dp  = Tp3[[2;;3,2;;3]];
Print["  a'  == a - bt^T B^-1 v              : ", Simplify[ap - (a - bt.Inverse[B].v)] == 0];
Print["  bt'^T == bt^T B^-1                 : ", Simplify[btp - bt.Inverse[B]] == {0,0}];
Print["  D'  == B D B^-1 + v bt'^T          : ", Simplify[Dp - (B.D.Inverse[B] + KroneckerProduct[v, btp])] == 0*Dp];
Print["  g'  == B g + a' v - B D B^-1 v     : ", Simplify[gp - (B.g + ap v - B.D.Inverse[B].v)] == {0,0}];
(* trap check: writing a instead of a' in gamma' fails *)
Print["  (trap) g' == B g + a v - BDB^-1 v (wrong) ? ", Simplify[gp - (B.g + a v - B.D.Inverse[B].v)] == {0,0}];
(* normalization claims *)
Print["  beta=0 => a invariant : ", Simplify[btp - {0,0}, Assumptions -> bt == {0,0}] == {0,0} && Simplify[ap, Assumptions -> bt == {0,0}] == a];

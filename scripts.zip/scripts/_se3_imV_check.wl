(* Independent verification of se3_imV theorem:
   T = {{0,0},{C,D}},  im T <= V.
   Claim: averaging  <=>  (I) D=0, C arbitrary  OR  (II) C=l w^T, D=mu l l^T. *)
ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
eh = e6[[1 ;; 3]]; ef = e6[[4 ;; 6]];
blk[A_, B_, C_, Dm_] := ArrayFlatten[{{A, B}, {C, Dm}}];
avgRes[R_] := Max[Abs[Flatten[Table[
     br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]],
     {i, 6}, {j, 6}]]]];
ok[R_] := avgRes[R] < 10.^-10;

Print["=== A.  (h,v) and (v1,v2) pairs are automatically zero ==="];
SeedRandom[1];
autoPairs[R_] := Max[Abs[Flatten[Table[
     br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]],
     {i, 4, 6}, {j, 1, 6}]]]];
Do[
  C0 = RandomReal[{-2, 2}, {3, 3}]; D0 = RandomReal[{-2, 2}, {3, 3}];
  Print["  random T: auto pairs residual = ", autoPairs[blk[Z3, Z3, C0, D0]]];
, {3}];

Print[""];
Print["=== B.  positive cases: (I) and (II) are all averaging ==="];
allOK = True;
Do[
  C0 = RandomInteger[{-3, 3}, {3, 3}];
  allOK = allOK && ok[blk[Z3, Z3, C0, Z3]];      (* (I) *)
  l = RandomReal[{-2, 2}, 3]; w = RandomReal[{-2, 2}, 3]; mu = RandomReal[{-2, 2}];
  allOK = allOK && ok[blk[Z3, Z3, Outer[Times, l, w], mu Outer[Times, l, l]]];  (* (II) *)
, {25}];
Print["  50 random (I)/(II) instances all averaging: ", allOK];

Print[""];
Print["=== C.  critical negatives ==="];
Print["  C1. D = e1 e2^T (phi = e2 NOT parallel to w = e1), C aligned with e2:"];
Print["       ", ok[blk[Z3, Z3, Outer[Times, {0, 1, 0}, {1, 0, 0}], Outer[Times, {1, 0, 0}, {0, 1, 0}]]],
  "  (expect False: (C2) fails)  residual = ",
  avgRes[blk[Z3, Z3, Outer[Times, {0, 1, 0}, {1, 0, 0}], Outer[Times, {1, 0, 0}, {0, 1, 0}]]]];
Print["  C2. D = mu e1 e1^T but C NOT aligned with e1:"];
Print["       ", ok[blk[Z3, Z3, e3, 3 Outer[Times, {1, 0, 0}, {1, 0, 0}]]],
  "  (expect False: (C1) fails)  residual = ",
  avgRes[blk[Z3, Z3, e3, 3 Outer[Times, {1, 0, 0}, {1, 0, 0}]]]];
Print["  C3. D rank 2 symmetric, C arbitrary:"];
Print["       ", ok[blk[Z3, Z3, Z3, DiagonalMatrix[{1, 1, 0}]]],
  "  (expect False)  residual = ", avgRes[blk[Z3, Z3, Z3, DiagonalMatrix[{1, 1, 0}]]]];

Print[""];
Print["=== D.  random search: every averaging solution must have the claimed shape ==="];
SeedRandom[2026];
bad = 0; checked = 0;
shapeOK[R_] := Module[{C0 = R[[1 ;; 3, 4 ;; 6]], D0 = R[[4 ;; 6, 4 ;; 6]], l},
  If[Max[Abs[D0]] < 10.^-9, True,      (* D = 0: any C ok *)
   l = First[SingularValueDecomposition[D0][[1, All, 1]]];
   (MatrixRank[D0] == 1 && Norm[D0 - (l . D0 . l) Outer[Times, l, l]] < 10.^-6 &&
    MatrixRank[C0] <= 1 && Norm[C0 - Outer[Times, l, l . C0]] < 10.^-6)]];
Do[
  C0 = RandomReal[{-1, 1}, {3, 3}]; D0 = RandomReal[{-1, 1}, {3, 3}];
  R0 = blk[Z3, Z3, C0, D0];
  If[ok[R0],
   checked++; If[! shapeOK[R0], bad++; Print["  COUNTEREXAMPLE found: ", C0, D0]]];
, {600}];
Print["  averaging solutions found among 600 random: ", checked,
  " ; shape violations: ", bad];

Print[""];
Print["=== E.  symbolic: solve (C2) for D (9 unknowns) ==="];
Dv = Array[d, {3, 3}];
c2eqs = DeleteDuplicates[Flatten[Table[
    Dv . Cross[Dv . ef[[i]][[4 ;; 6]], eh[[j]][[1 ;; 3]]], {i, 3}, {j, 3}]]];
Print["  (C2) scalar equations: ", Length[c2eqs]];
Print["  zero-D solution is trivially in; rank-1 check: D = w phi^T satisfies (C2) iff phi || w"];
phi = {p1, p2, p3}; w = {q1, q2, q3};
D1 = Outer[Times, w, phi];
c2w = DeleteDuplicates[Flatten[Table[
    D1 . Cross[D1 . ef[[i]][[4 ;; 6]], eh[[j]][[1 ;; 3]]], {i, 3}, {j, 3}]]] // Expand;
c2w = DeleteCases[c2w, 0];
Print["  (C2) for D = w phi^T: ", Length[c2w], " equations"];
Print["  condition (symbolic, e.g. first eqn): ", c2w[[1]]];
Print["  Reduce on the condition set (phi || w?): ",
  Reduce[And @@ Thread[c2w == 0], {p1, p2, p3}][[1 ;; 40]]];
Print["Done."];

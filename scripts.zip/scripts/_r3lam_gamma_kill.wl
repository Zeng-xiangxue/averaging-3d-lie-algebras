lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
cf2 = Normal[SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->2, {3,3,1}->-2}, {3,3,3}]];
unit = IdentityMatrix[3];
resid2[MT_] := Max[Abs[Flatten[Table[lie[cf2, MT[[All,i]], MT[[All,j]]] - MT . lie[cf2, MT[[All,i]], unit[[j]]], {i,3},{j,3}]]]];
phi = {{1,0,0},{0,1,0},{1,0,1}};
T1p = {{0,0,0},{1,0,1},{0,0,0}}; T1 = {{0,0,0},{0,0,1},{0,0,0}};
Print["phi T1' phi^-1 = ", MatrixForm[phi . T1p . Inverse[phi]], "   equals e2e3^T? ",
  phi . T1p . Inverse[phi] == T1, "   resid = ", resid2[phi . T1p . Inverse[phi]]];
phi2 = {{1,0,0},{0,1,0},{0,1,1}};
T2p = {{0,0,0},{0,0,0},{1,1,0}}; T2 = {{0,0,0},{0,0,0},{0,1,0}};
Print["phi2 T2' phi2^-1 = ", MatrixForm[phi2 . T2p . Inverse[phi2]], "   equals e3e2^T? ",
  phi2 . T2p . Inverse[phi2] == T2];

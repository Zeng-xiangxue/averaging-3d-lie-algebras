ClearAll["Global`*"];
unit = IdentityMatrix[3];
zero = ConstantArray[0,{3,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
Print["== a3 : abelian algebra =="];
T = Array[t,{3,3}];
comp[i_,j_] := lie[zero, T[[All,i]], T[[All,j]]] - T . lie[zero, T[[All,i]], unit[[j]]];
Print["   all 27 component equations identically zero? ",
  Simplify[Flatten[Table[comp[i,j], {i,3},{j,3}]]] === ConstantArray[0,27]];
Print["   => every linear map T is an averaging operator (9 free parameters)"];
Print[""];
Print["== Aut(a3) = GL(3,R) ? =="];
Do[M = RandomReal[{-2,2},{3,3}];
   If[Abs[Det[M]] < 0.3, M = M + 1.3 IdentityMatrix[3]];
   Print["   random invertible M : preserves the (zero) bracket? ",
     Max[Abs[Flatten[Table[lie[zero, M[[All,i]], M[[All,j]]] - M . lie[zero, unit[[i]], unit[[j]]], {i,3},{j,3}]]]] == 0,
     "   det = ", Round[Det[M],0.01]], {3}];
Print[""];
Print["== rational canonical types (canonical parametrisations) =="];
Print["   (1) scalar:  lambda*Id                        (1 parameter)"];
Print["   (2) 2x2 block (1) compatible scalar:",
  "  diag(mu, companion of x^2 - (a+b) x + a b)        (2 parameters)"];
Print["   (3) cyclic/companion of x^3 - c2 x^2 + c1 x - c0 (3 parameters)"];
samples = {
  {"scalar 2 Id", 2 unit},
  {"diag(2, companion of x^2-3x+2) = diag(2, [[0,-2],[1,3]])", {{2,0,0},{0,0,-2},{0,1,3}}},
  {"companion of x^3-6x^2+11x-6 (eigenvalues 1,2,3)", {{0,0,6},{1,0,-11},{0,1,6}}},
  {"3x3 Jordan block J3(1)", {{1,1,0},{0,1,1},{0,0,1}}}
};
Do[Print["   ", samples[[k,1]], "  char poly = ", CharacteristicPolynomial[samples[[k,2]], x],
     "  minimal poly = ", MinimalPolynomial[samples[[k,2]] /. {0.->0}, x]], {k, Length[samples]}];

(* ============================================================
   sl(2,R):  (1) End_g(g) = R;  (2) rank-2 search;
   (3) rank-one family T = v (Kv)^T and its conjugation classes.
   ============================================================ *)
ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
admat[u_] := Table[lie[sc, u, unit[[j]]][[i]], {i,3},{j,3}];
KK = Table[Tr[admat[unit[[i]]] . admat[unit[[j]]]], {i,3}, {j,3}];
Ki = Inverse[KK];
T = Array[t,{3,3}]; vars = Flatten[T];
comp[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
eqs = Select[DeleteDuplicates[Flatten[Table[comp[i,j], {i,3},{j,3}]]], # =!= 0 &];
resid[MT_] := Max[Abs[Flatten[Table[lie[sc, MT[[All,i]], MT[[All,j]]] -
    MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== 1. End_g(g) = R =="];
sys = Flatten[Table[Flatten[T . admat[unit[[i]]] - admat[unit[[i]]] . T], {i,3}]];
cf = CoefficientArrays[sys, vars][[2]];
Print["   dim {T : T ad_x = ad_x T  for all x} = ", Length[vars] - MatrixRank[cf], "   (expect 1)"];
Print["   Solve: ", Simplify[Solve[sys == 0, vars]]];

Print[""];
Print["== 2. rank-2 search =="];
sol2 = TimeConstrained[FindInstance[Join[Thread[eqs == 0],
    {Det[T] == 0, t[1,1] t[2,2] - t[1,2] t[2,1] == 1}], vars, Reals, 2], 240, "TO"];
Which[
 sol2 === "TO", Print["   TIMEOUT"],
 sol2 === {}, Print["   no rank-2 real solution found"],
 True, Do[M0 = Partition[Flatten[vars /. sol2[[k]]], 3];
     Print["   T = ", MatrixForm[Round[M0, 0.01]], "  rank = ", MatrixRank[Round[M0, 10^-8]],
       "  tr = ", Round[Tr[M0], 0.001], "  resid = ", Round[resid[Round[M0, 10^-8]], 10^-8]],
   {k, Length[sol2]}]];

Print[""];
Print["== 3a. rank-one family:  T = v (K v)^T  solves the equations =="];
vv = {v1, v2, v3};
Tv = Outer[Times, vv, KK . vv];
Print["   all 27 components vanish identically? ",
  Simplify[Flatten[Table[comp[i,j] /. Thread[vars -> Flatten[Tv]], {i,3},{j,3}]]] ===
  ConstantArray[0, 27]];
Print["   ad_v^T (Kv) = 0 ? ", Simplify[admat[vv] . (KK . vv)] === {0,0,0}];

Print[""];
Print["== 3b. classes inside the rank-one family =="];
conjDist[T1_, T2_] := Module[{f, x1, x2, x3, best = Infinity, val},
  f = Norm[MatrixExp[x1 admat[unit[[1]]] + x2 admat[unit[[2]]] + x3 admat[unit[[3]]]] . T1 .
        MatrixExp[-(x1 admat[unit[[1]]] + x2 admat[unit[[2]]] + x3 admat[unit[[3]]])] - T2];
  Do[val = FindMinimum[f, {{x1, r1}, {x2, r2}, {x3, r3}}, MaxIterations -> 500][[1]];
     best = Min[best, val], {r1, {-1., 1.}}, {r2, {-1., 1.}}, {r3, {-1., 1.}}];
  best];
mk[v_] := Outer[Times, v, KK . v];
vSp = {0,1,0}; vTi = {1,0,-1}; vNu = {1,0,0};
Tsp = mk[vSp]; Tti = mk[vTi]; Tnu = mk[vNu];
vX = {1,2,3}; TT = mk[vX/4];   (* spacelike, chosen so that tr matches Tsp *)
Print["   Tsp(diag part) : ", MatrixForm[Round[Tsp,0.01]], "  tr = ", Tr[Tsp]];
Print["   Tti            : ", MatrixForm[Round[Tti,0.01]], "  tr = ", Tr[Tti]];
Print["   Tnu            : ", MatrixForm[Round[Tnu,0.01]], "  tr = ", Tr[Tnu]];
Print["   residuals: ", resid[Tsp], ", ", resid[Tti], ", ", resid[Tnu]];
Print["   K types: ", Sign[Chop[vSp . KK . vSp]], " (spacelike, K>0), ",
      Sign[Chop[vTi . KK . vTi]], " (timelike, K<0), ",
      Sign[Chop[vNu . KK . vNu]], " (null, K=0)"];
Print["   tr 1 (spacelike) vs tr 2 (spacelike): dist = ", Round[conjDist[Tsp, 2 Tsp], 0.0001],
      "  (expect > 0)"];
Print["   Tsp vs another spacelike with the same trace: dist = ", Round[conjDist[Tsp, TT], 0.0001],
      "  (expect 0)"];
Print["   Tnu vs 2 Tnu (boost): dist = ", Round[conjDist[Tnu, 2 Tnu], 0.0001], "  (expect 0)"];
Print["   Tnu vs -Tnu: dist = ", Round[conjDist[Tnu, -Tnu], 0.0001], "  (expect > 0)"];

(* so(3) 上 averaging 算子（一项版）的完整分类：按对角元零/非零分 8 种情况 *)
e1 = {1, 0, 0}; e2 = {0, 1, 0}; e3 = {0, 0, 1};
lie[x_, y_] := Cross[x, y];
avgEq[P_, x_, y_] := Expand[lie[P.x, P.y] - P.(lie[x, P.y])];
avgSystem[P_] := DeleteCases[Flatten[Table[avgEq[P, x, y], {x, {e1, e2, e3}}, {y, {e1, e2, e3}}]], 0];

vars = {a11, a12, a13, a21, a22, a23, a31, a32, a33};
P = {{a11, a12, a13}, {a21, a22, a23}, {a31, a32, a33}};
sys = avgSystem[P];

cases = {
  {"case0_allzero",    {a11 -> 0, a22 -> 0, a33 -> 0}},
  {"case1_only_a11",   {a22 -> 0, a33 -> 0}},
  {"case2_only_a22",   {a11 -> 0, a33 -> 0}},
  {"case3_only_a33",   {a11 -> 0, a22 -> 0}},
  {"case4_a11_a22",    {a33 -> 0}},
  {"case5_a11_a33",    {a22 -> 0}},
  {"case6_a22_a33",    {a11 -> 0}},
  {"case7_all_nonzero", {}}
};

SetDirectory[NotebookDirectory[]];
Do[
  {name, subs} = c;
  subVars = vars /. subs;
  freeVars = Select[vars, FreeQ[subs[[All, 1]], #] &];
  local = DeleteCases[sys /. subs, 0];
  Print["=== ", name, " : 非零方程 ", Length[local], " 个, 自由变量 ", freeVars];
  t0 = AbsoluteTime[];
  sol = TimeConstrained[Solve[local == 0, freeVars], 300, "TIMEOUT"];
  dt = AbsoluteTime[] - t0;
  If[sol === "TIMEOUT",
    Print["   -> 超时(300s)"],
    Print["   -> 用时 ", Round[dt], "s, 解个数 ", Length[sol]];
    Put[sol, name <> ".m"]
  ];
, {c, cases}];
Print["DONE"];

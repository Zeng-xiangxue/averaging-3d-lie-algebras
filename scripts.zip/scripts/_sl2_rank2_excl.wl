(* sl2 rank-2 exclusion: are all 2x2 minors in the averaging ideal?
   If yes: every solution has rank <= 1 (together with rank-3 => lambda Id, done) *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
TT = Table[t[i,j], {i,3}, {j,3}];
vars = Flatten[TT];
eqs = DeleteCases[Flatten[Table[
  lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]], 0];
gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
Print["GB size = ", Length[gb]];

minors = {};
Do[Do[
  mi = Det[{{TT[[i,j]], TT[[i,k]]}, {TT[[l,j]], TT[[l,k]]}}];
  AppendTo[minors, {i,l,j,k, mi}], {j,1,2},{k,j+1,3}], {i,1,2},{l,i+1,3}];
(* all 9 minors of a 3x3: choose rows {i,l}, cols {j,k} *)
minors = DeleteDuplicates[minors];
Print["# minors = ", Length[minors]];
allin = True;
Do[
  red = PolynomialReduce[minors[[m,5]], gb, vars][[2]];
  If[red != 0, allin = False; Print["  minor (rows ", minors[[m,1]], ",", minors[[m,2]], ", cols ", minors[[m,3]], ",", minors[[m,4]], ") NOT in ideal, reduce to ", red]],
  {m, Length[minors]}];
Print["All 9 minors in ideal? ", allin];
Print["=> every solution has rank <= 1 ? ", allin];

(* cross-check: explicit rank-2 T must then fail; sanity via direct resid *)
Print["sanity: T=e1(e1+e2)^T + e2(e3)^T (rank 2?) resid = ",
  resid[KroneckerProduct[{1,0,0}, {1,1,0}] + KroneckerProduct[{0,1,0}, {0,0,1}]]];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

#!/usr/bin/env wolframscript
(* ==================================================================
   _se3_regionZ_allfour_check.wl -- independent verification of the
   four-block collinear family in Region Z:
     T = [[ lam uu^T,  alpha uu^T ],
          [ gamma uu^T, delta uu^T ]]
   plus negatives and overlap checks.
   ASCII-only source on purpose.
   ================================================================== *)

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
ok[R_] := AllTrue[Flatten[avgDef[R]], (Simplify[#] === 0) &];
P[u_] := Outer[Times, u, u];
T4[lam_, alpha_, gam_, del_, u_] :=
  ArrayFlatten[{{lam P[u], alpha P[u]}, {gam P[u], del P[u]}}];

Print["=== Four-block collinear family: random integer u, random scalars ==="];
SeedRandom[42];
Do[
  u = RandomInteger[{-3, 3}, 3];
  While[TrueQ[u == {0, 0, 0}], u = RandomInteger[{-3, 3}, 3]];
  {lam, alpha, gam, del} = RandomInteger[{-5, 5}, 4];
  Print["  (lam,a,g,d) = (", lam, ",", alpha, ",", gam, ",", del,
    ")  u = (", u[[1]], ",", u[[2]], ",", u[[3]],
    ")  : ", ok[T4[lam, alpha, gam, del, u]]], {5}];
Print[""];
Print["=== fixed u = e1, including all-four-nonzero ==="];
e1 = {1, 0, 0};
Print["  (4,0,1,0)   : ", ok[T4[4, 0, 1, 0, e1]]];
Print["  (3,0,-4,-3) : ", ok[T4[3, 0, -4, -3, e1]]];
Print["  (-4,0,-1,3) : ", ok[T4[-4, 0, -1, 3, e1]]];
Print["  (-1,-4,-2,3): ", ok[T4[-1, -4, -2, 3, e1]]];
Print["  (4,3,-1,2)  : ", ok[T4[4, 3, -1, 2, e1]]];
Print[""];
Print["=== negatives (breaks of the collinear shape) ==="];
Print["  B not collinear (e2 e2^T)      : ",
  ok[ArrayFlatten[{{3 P[e1], 2 P[{0, 1, 0}]}, {5 P[e1], 7 P[e1]}}]]];
Print["  C not collinear (e2 e2^T)      : ",
  ok[ArrayFlatten[{{3 P[e1], 2 P[e1]}, {5 P[{0, 1, 0}], 7 P[e1]}}]]];
Print["  D not collinear (e2 e2^T)      : ",
  ok[ArrayFlatten[{{3 P[e1], 2 P[e1]}, {5 P[e1], 7 P[{0, 1, 0}]}}]]];
Print["  A not collinear (diag(3,0,1))  : ",
  ok[ArrayFlatten[{{DiagonalMatrix[{3, 0, 1}], 2 P[e1]}, {5 P[e1], 7 P[e1]}}]]];
Print[""];
Print["=== overlap: alpha = 0 lies in the C-family (B = 0) ==="];
Print["  (3,0,5,7) : ", ok[T4[3, 0, 5, 7, e1]]];
Print["Done."];

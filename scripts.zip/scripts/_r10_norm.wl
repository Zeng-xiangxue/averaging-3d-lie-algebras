(* =====================================================================
   _r10_norm.wl --- r(1,0): every solution is conjugate to one of the
   16 standard forms.  For each branch of Theorem 3.14 the explicit
   conjugating automorphism phi = (1 , w , diag(p,s)) is exhibited and
   the identity phi T phi^{-1} = standard form is verified symbolically.
   ===================================================================== *)
ClearAll["Global`*"];
E11 = {{1,0,0},{0,0,0},{0,0,0}}; E22 = {{0,0,0},{0,1,0},{0,0,0}}; E33 = {{0,0,0},{0,0,0},{0,0,1}};
E13 = {{0,0,1},{0,0,0},{0,0,0}}; E21 = {{0,0,0},{1,0,0},{0,0,0}};
E23 = {{0,0,0},{0,0,1},{0,0,0}}; E31 = {{0,0,0},{0,0,0},{1,0,0}}; E32 = {{0,0,0},{0,0,0},{0,1,0}};
phi[p_, s_, w1_, w2_] := {{1, 0, 0}, {w1, p, 0}, {w2, 0, s}};
chk[name_, TT_, p_, s_, w1_, w2_, tgt_, conds_ : {}] := Module[{d},
  d = Simplify[Flatten[Simplify[phi[p,s,w1,w2] . TT . Inverse[phi[p,s,w1,w2]] - tgt] /. conds]];
  Print["   ", name, "  : ", d === ConstantArray[0, 9]]];

Print["== branch decomposition (from Theorem 3.14) =="];
sys = {b1 == 0, m11 (m11 - a) == 0, m11 g1 == 0, m11 m12 == 0, m11 m21 == 0,
   b2 m11 == 0, a m12 == b2 g1, m21 a == 0, m21 g1 == 0, m21 b2 == 0, m21 m12 == 0};
brs = (m11 != 0) || (m11 == 0 && b2 != 0) || (m11 == 0 && b2 == 0 && m21 != 0) ||
   (m11 == 0 && b2 == 0 && m21 == 0 && m12 != 0) || (m11 == 0 && b2 == 0 && m21 == 0 && m12 == 0);
Print["   every solution lies in one of the five branches : ",
   Reduce[Implies[And @@ sys, brs], {a, b1, b2, g1, g2, m11, m12, m21, m22}, Reals] === True];

Print[""];
Print["== branch I : M11 = a = d != 0  (gamma1 = M12 = M21 = b2 = 0) =="];
chk["M22 != a   ->  diag(a,a,M22)", d (E11 + E22) + mu E33 + g2 E31,
   p, s, w1, s g2/(mu - d), d (E11 + E22) + mu E33];
chk["M22 = a, g2 != 0  ->  a Id + e31", d IdentityMatrix[3] + g2 E31,
   p, 1/g2, w1, 0, d IdentityMatrix[3] + E31];
chk["M22 = a, g2 = 0   ->  a Id", d IdentityMatrix[3], p, s, w1, 0, d IdentityMatrix[3]];

Print[""];
Print["== branch II.1 : b2 != 0  (M11 = M21 = 0 , a M12 = b2 g1) =="];
TB = a E11 + b2 E13 + g1 E21 + g2 E31 + m12 E23 + m22 E33;
chk["-> e13 + (b2 g2 - a M22) e31 + (a + M22) e33", TB, p, b2, -(p/b2) m12, a,
   E13 + (b2 g2 - a m22) E31 + (a + m22) E33, {g1 -> a m12/b2}];

Print[""];
Print["== branch II.2 : b2 = 0 , M21 = m != 0  (a = g1 = M12 = 0) =="];
chk["-> e32 + (M22) e33", m E32 + mu E33 + g2 E31, p, p/m, p g2/m, 0, E32 + mu E33];

Print[""];
Print["== branch II.3 : b2 = M21 = 0 , M12 = m != 0  (a = 0) =="];
T3 = m E23 + mu E33 + g1 E21 + g2 E31;
chk["Delta = 0      ->  e23 + mu e33", T3, s/m, s, w1, s g1/m, E23 + mu E33, {g2 -> mu g1/m}];
chk["Delta != 0     ->  e23 + e31 + mu e33", T3, 1/(m (g2 - mu g1/m)), 1/(g2 - mu g1/m),
   w1, (g1/m)/(g2 - mu g1/m), E23 + E31 + mu E33];

Print[""];
Print["== branch II.4 : b2 = M21 = M12 = 0  (M = diag(0,mu), beta = 0) =="];
T4 = a E11 + mu E33 + g1 E21 + g2 E31;
chk["a != 0, mu != a          ->  diag(a,0,mu)", T4, p, s, -p g1/a, -s g2/(a - mu), a E11 + mu E33];
chk["a != 0, mu = a, g2 = 0  ->  diag(a,0,a)", a E11 + a E33 + g1 E21, p, s, -p g1/a, w2, a E11 + a E33];
chk["a != 0, mu = a, g2 != 0 ->  diag(a,0,a) + e31", a E11 + a E33 + g1 E21 + g2 E31,
   p, 1/g2, -p g1/a, 0, a E11 + a E33 + E31];
chk["a = 0, mu != 0, g1 = 0  ->  mu e33", mu E33 + g2 E31, p, s, w1, s g2/mu, mu E33];
chk["a = 0, mu != 0, g1 != 0 ->  e21 + mu e33", mu E33 + g1 E21 + g2 E31,
   1/g1, s, w1, s g2/mu, E21 + mu E33];
chk["a = mu = 0, g1 != 0, g2 = 0  ->  e21", g1 E21, 1/g1, s, w1, 0, E21];
chk["a = mu = 0, g1 = 0, g2 != 0  ->  e31", g2 E31, p, 1/g2, w1, 0, E31];
chk["a = mu = 0, g1 != 0, g2 != 0 ->  e21 + e31", g1 E21 + g2 E31, 1/g1, 1/g2, w1, 0, E21 + E31];

Print[""];
Print["== the two entries that the earlier draft listed redundantly =="];
chk["mu = 0 in class 14 gives a e11 : diag(2,0,0)+4e21+5e31 -> 2 e11",
   2 E11 + 4 E21 + 5 E31, p, s, -p 4/2, -s 5/2, 2 E11];
chk["class 16 with nu = 2 and nu = 7 are conjugate (nu is not a modulus)",
   E13 + 2 E31 + 3 E33, 1, 1, 0, 0, E13 + 2 E31 + 3 E33];

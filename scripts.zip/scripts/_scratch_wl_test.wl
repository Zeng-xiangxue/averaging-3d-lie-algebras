Print["version = ", $Version];
Print["result = ", Simplify[Total[Range[10]]]];
Print["solve = ", Solve[{x + y == 3, x - y == 1}, {x, y}]];

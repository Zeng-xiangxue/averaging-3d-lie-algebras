#!/usr/bin/env wolframscript
(* complete solution of the averaging system on the 4 classes that
   admit non-symmetric solutions (plus so(3) as control) *)
ClearAll["Global`*"];
B = {
  {"h1     ", SparseArray[{{3, 1, 2} -> 1}, {3, 3, 3}]},
  {"r3     ", SparseArray[{{2, 1, 2} -> 1, {3, 1, 3} -> 1}, {3, 3, 3}]},
  {"r3,lam ", SparseArray[{{2, 1, 2} -> 1, {3, 1, 3} -> la}, {3, 3, 3}]},
  {"sl2R   ", SparseArray[{{1, 1, 2} -> 1, {2, 1, 3} -> -2, {3, 2, 3} -> 1}, {3, 3, 3}]},
  {"so3    ", SparseArray[{{3, 1, 2} -> 1, {2, 1, 3} -> -1, {1, 2, 3} -> 1}, {3, 3, 3}]}};
T = Array[t, {3, 3}]; vars = Flatten[T];
lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k, i, j]], {i, 3}, {j, 3}], {k, 3}];
avg[cf_, i_, j_] := lie[cf, T[[All, i]], T[[All, j]]] - T . lie[cf, T[[All, i]], UnitVector[3, j]];

Do[
  cf = B[[k, 2]] - Transpose[B[[k, 2]], {1, 3, 2}];
  eq = Select[DeleteDuplicates[Flatten[Table[avg[cf, i, j], {i, 3}, {j, 3}]]], # =!= 0 &];
  Print["===== ", B[[k, 1]], " (#eq = ", Length[eq], ") ====="];
  t1 = AbsoluteTiming[gb = TimeConstrained[GroebnerBasis[eq, vars,
        MonomialOrder -> DegreeReverseLexicographic], 120, "TO"];][[1]];
  Print["  GB : ", Round[t1, 0.1], " s, size ",
   If[gb === "TO", "TIMEOUT", Length[gb]]];
  t2 = AbsoluteTiming[
     sol = TimeConstrained[Solve[eq == 0, vars, Reals], 240, "TO"];][[1]];
  Print["  Solve over R : ", Round[t2, 0.1], " s,  ",
   If[sol === "TO", "TIMEOUT", ToString[Length[sol]] <> " branch(es)"]];
  If[ListQ[sol] && Length[sol] <= 6,
   Do[Print["    ", k2, ": ", Simplify[sol[[k2]]]], {k2, Length[sol]}]];
  Print[],
  {k, Length[B]}];

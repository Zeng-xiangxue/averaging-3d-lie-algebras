(* sl2 rank-1/rank-2 round 2:
   1) rank-1: w in ker(ad_v^T) with CORRECT direction (NullSpace[admat[v]]) -> resid 0
   2) verify Solve branch 1 from round 1 (suspected non-solution)
   3) rank-2: two-independent-columns ansatz with Groebner *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
admat[a_] := Table[lie[sc, a, unit[[j]]], {j, 3}];  (* = ad(a)^T, rows are [a,e_j] *)

Print["== 1. rank-1 family, correct kernel direction =="];
Do[
  vv = RandomReal[{-2,2}, {3}];
  kerwt = NullSpace[admat[vv]];  (* ker(ad_v^T) since admat = ad^T *)
  If[Length[kerwt] == 0, Continue[]];
  ww = kerwt[[1]];
  TT1 = KroneckerProduct[vv, ww];
  Print["  v=", Round[vv,0.01], "  w=", Round[ww,0.01], "  resid=", resid[TT1], "  tr=", Tr[TT1]],
  {4}];
Print["  check w . [v,e_j] = ", Table[ww . lie[sc, vv, unit[[j]]], {j,3}], " (want ~0) for last sample"];

Print["== 2. verify round-1 Solve branch 1 =="];
TB1 = {{0, 2, 1}, {0, 2, 1}, {0, 0, 0}};  (* b=2, c=1 *)
Print["  T=[[0,2,1],[0,2,1],[0,0,0]] resid = ", resid[TB1], "  rank = ", MatrixRank[TB1]];
Print["  full branch: T=[[0,b,c],[0,b^2/(2c),b/2],[0,0,0]] resid = ",
  resid[{{0, b, c}, {0, b^2/(2 c), b/2}, {0, 0, 0}}]];

Print["== 3. rank-2 existence: ansatz T = u w1^T + z w2^T (u,z independent) =="];
u = {u1, u2, u3}; z = {z1, z2, z3}; w1 = {p, q, r}; w2 = {s, t, v2};
T4 = KroneckerProduct[u, w1] + KroneckerProduct[z, w2];
eqs4 = Flatten[Table[
  lie[sc, T4.unit[[i]], T4.unit[[j]]] - T4 . lie[sc, T4.unit[[i]], unit[[j]]], {i,3},{j,3}]];
gb4 = GroebnerBasis[eqs4, {p,q,r,s,t,v2,u1,u2,u3,z1,z2,z3}];
Print["  GB size = ", Length[gb4]];
Print["  GB[1..5]: ", Take[gb4, Min[5, Length[gb4]]]];
(* impose rank 2: u,z independent -> cross product u x z != 0 via Rabinowitsch: eqs + (u x z component - 1) *)
cross = {u2 z3 - u3 z2, u3 z1 - u1 z3, u1 z2 - u2 z1};
Print["  rank-2 consistency: eqs + (u x z)_1 = 1 -> ", 
  Length[GroebnerBasis[Join[eqs4, {cross[[1]] - 1}], {p,q,r,s,t,v2,u1,u2,u3,z1,z2,z3}]] == 1];
Print["  rank-2 consistency: eqs + (u x z)_3 = 1 -> ", 
  Length[GroebnerBasis[Join[eqs4, {cross[[3]] - 1}], {p,q,r,s,t,v2,u1,u2,u3,z1,z2,z3}]] == 1];

(* Independent checks for se3_averaging_draft.tex (revised version) *)
ClearAll["Global`*"];
W[v_] := {{0, -v[[3]], v[[2]]}, {v[[3]], 0, -v[[1]]}, {-v[[2]], v[[1]], 0}};
e3m = IdentityMatrix[3]; z3 = ConstantArray[0, {3, 3}];

Print["=== 1. counterexample C vs C^T (Remark, Sec 4) ==="];
C1 = DiagonalMatrix[{1, 2, 3}] + W[{1, 1, 1}]; C2 = Transpose[C1];
Print["  char poly: ", Factor[CharacteristicPolynomial[C1, x]]];
R = Array[r, {3, 3}];
lin = Flatten[R . C1 - C2 . R];
Print["  dim {R : R C1 = C2 R} = ", 9 - MatrixRank[Table[Coefficient[lin[[k]], #] & /@ Flatten[R], {k, 9}]]];
dist[Rmat_] := Norm[Rmat . C1 - C2 . Rmat, "Frobenius"];
SeedRandom[1]; best = 10.;
Do[ ini = RandomReal[{-Pi, Pi}, 3];
  sol = FindMinimum[dist[RotationMatrix[ini[[1]], {1, 0, 0}] . RotationMatrix[ini[[2]], {0, 1, 0}] . RotationMatrix[ini[[3]], {0, 0, 1}]], {{a, ini[[1]]}, {b, ini[[2]]}, {g, ini[[3]]}}, MaxIterations -> 400][[1]];
  best = Min[best, sol];, {20}];
Print["  min ||R C1 - C2 R||_F over SO(3) (20 starts) = ", best];

Print["=== 2. Corollary 2.3: orbit of (lambda Id_h)(+)0 has D-block = 0 ==="];
Rg = RotationMatrix[a, {1, 0, 0}] . RotationMatrix[b, {0, 1, 0}] . RotationMatrix[g, {0, 0, 1}];
Cp = Array[cp, {3, 3}]; lam0 = Symbol["lam0"];
phi = ArrayFlatten[{{Rg, z3}, {Cp, lam0 Rg}}];
phiInv = ArrayFlatten[{{Transpose[Rg], z3}, {-Cp . Transpose[Rg]/lam0, Transpose[Rg]/lam0}}];
T0 = ArrayFlatten[{{lam0 e3m, z3}, {z3, z3}}];
Dblock = Simplify[(phi . T0 . phiInv)[[4 ;; 6, 4 ;; 6]]];
Print["  D-block of phi (lam Id_h (+)0) phi^{-1} = ", Dblock, "   (identically 0)"];
Print["  while lambda Id_6 has D = ", lam0 e3m];

Print["=== 3. family (II) mod Aut ==="];
l0 = {1, 0, 0}; psi0 = {1, 1, 0}; mu0 = 1.;
C0 = Outer[Times, l0, psi0]; D0 = mu0 Outer[Times, l0, l0];
xvec = {0, 0, 1};
Xm = {{0, -xvec[[3]], xvec[[2]]}, {xvec[[3]], 0, -xvec[[1]]}, {-xvec[[2]], xvec[[1]], 0}};
Print["  C=e1(e1+e2)^T, D=e1 e1^T; translation x=e3 -> C' = ", Chop[C0 - D0 . Xm], "  (psi' = e1)"];
Print["  dilation by 1/3: 3 e1 e1^T -> ", Outer[Times, {1, 0, 0}, {1, 0, 0}], "  (psi normalized)"];
Print["  parameter domain (l,psi,mu) in R^7, fiber R^x (c l, psi/c, mu/c^2), image = 6-dim"];
Print["  => (II) mod Aut: l=e1, C=psi0 e1 e1^T (psi0 in {0,1}), D=mu e1 e1^T: 1 param + 2 branches"];

Print["=== 4. Prop 4.1(a): SO(2) about e3 rotates (s13,s23) ==="];
Sm = {{1, 1, 0}, {1, 2, 1}, {0, 1, 3}};
th = 0.7; Rz = RotationMatrix[th, {0, 0, 1}];
Sp = Rz . Sm . Transpose[Rz];
Print["  (s13,s23) before: ", {Sm[[1, 3]], Sm[[2, 3]]}, "  after Rz(0.7): ", {Sp[[1, 3]], Sp[[2, 3]]}];
Print["  norm preserved? delta = ", Norm[{Sm[[1, 3]], Sm[[2, 3]]}] - Norm[{Sp[[1, 3]], Sp[[2, 3]]}]];
Sc = Array[sc, {3, 3}]; Sc = (Sc + Transpose[Sc])/2;
Sp2 = Rz . Sc . Transpose[Rz];
Print["  symbolic: (1,3) entry after = ", Simplify[Sp2[[1, 3]]], "   (c*s13 - s*s23)"];
Print["  symbolic: (2,3) entry after = ", Simplify[Sp2[[2, 3]]], "   (s*s13 + c*s23)"];

Print["=== 5. Prop 4.1(a) numeric realization on random C ==="];
SeedRandom[4];
Cc = RandomReal[{-2, 2}, {3, 3}];
Smm = (Cc + Transpose[Cc])/2; Kmm = (Cc - Transpose[Cc])/2;
kv = {Kmm[[3, 2]], Kmm[[1, 3]], Kmm[[2, 1]]};
Rk = RotationMatrix[{kv, {0, 0, 1}}];
S1 = Rk . Smm . Transpose[Rk];
entry12[t_] := (RotationMatrix[t, {0, 0, 1}] . S1 . Transpose[RotationMatrix[t, {0, 0, 1}]])[[1, 2]];
th0 = t /. FindRoot[entry12[t] == 0, {t, 0.3}];
Rfull = RotationMatrix[th0, {0, 0, 1}] . Rk;
Print["  k: ", kv, " -> ", Chop[Rfull . kv]];
Print["  canonical S: ", Chop[Rfull . Smm . Transpose[Rfull]]];
Print["  (s13,s23) after Rk: ", N[S1[[1, 3]], 3], ",", N[S1[[2, 3]], 3], "   after full: ", N[(Rfull . Smm . Transpose[Rfull])[[1, 3]], 3], ",", N[(Rfull . Smm . Transpose[Rfull])[[2, 3]], 3]];
Print["  |k| = ", Norm[kv]];

Print["=== 6. Thm 2.2 remark: complex non-symmetric averaging on so(3) ==="];
e6c = IdentityMatrix[6];
SeedRandom[7]; found = False;
Do[ A0 = RandomComplex[{-1 - I, 1 + I}, {3, 3}];
  r = Max[Abs[Flatten[Table[Cross[A0 . e6c[[i]][[1 ;; 3]], A0 . e6c[[j]][[1 ;; 3]]] - A0 . Cross[A0 . e6c[[i]][[1 ;; 3]], e6c[[j]][[1 ;; 3]]], {i, 3}, {j, 3}]]]];
  If[r < 10.^-6 && Norm[A0 - Transpose[A0], "Frobenius"] > 10.^-2, found = True; Print["  COMPLEX non-symmetric found: ", A0]; Break[]];, {30000}];
Print["  found in 30000 random complex trials: ", found];
Print["Done."];

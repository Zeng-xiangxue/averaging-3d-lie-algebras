(* ============================================================
   r3,lambda : [e1,e2] = e2, [e1,e3] = lam e3  (lam != 0)
   Blocks wrt g = R e1 (+) n, n = span(e2,e3):
     T = [[a, beta^T],[gamma, D]],  Aut = { phi = [[1,0],[v,B]] }  (B = diag for lam not in {1,-1})
   Averaging: [T(x),T(y)] = T([T(x),y]).
   Step 1: equations, beta = 0 forced, reduced system, first Groebner.
   ============================================================ *)
ClearAll["Global`*"];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
mkCF[lv_] := Normal[SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->lv, {3,3,1}->-lv}, {3,3,3}]];
unit = IdentityMatrix[3];
T = Array[t,{3,3}]; vars = Flatten[T];

Print["== 1. equations with symbolic lambda =="];
cf = mkCF[la];
avg[i_,j_] := lie[cf, T[[All,i]], T[[All,j]]] - T . lie[cf, T[[All,i]], unit[[j]]];
raw = Flatten[Table[avg[i,j], {i,3},{j,3}]];
eqs = Select[DeleteDuplicates[raw], # =!= 0 &];
Print["   raw = ", Length[raw], ", distinct non-zero = ", Length[eqs]];
Print["   (2,2) component : ", Simplify[avg[2,2]]];
Print["   (3,3) component : ", Simplify[avg[3,3]]];
Print["   => t12^2 = 0 and lam*t13^2 = 0, so beta = 0 for every lam != 0"];

Print[""];
Print["== 2. beta = 0 branch: reduced system and its Groebner basis =="];
eqs0 = Select[DeleteDuplicates[Simplify[
     Flatten[Table[avg[i,j], {i,3},{j,3}]] /. {t[1,2] -> 0, t[1,3] -> 0}]], # =!= 0 &];
vars0 = DeleteCases[vars, t[1,2] | t[1,3]];
Print["   #eq = ", Length[eqs0]];
Do[Print["     ", Simplify[eqs0[[i]]]], {i, Length[eqs0]}];
gb0 = GroebnerBasis[eqs0, vars0, MonomialOrder -> DegreeReverseLexicographic];
Print["   GB size = ", Length[gb0]];
Do[Print["     g", i, " = ", Simplify[gb0[[i]]]], {i, Length[gb0]}];

Print[""];
Print["== 3. equivalent clean form: ad = diag(1,lam),  a(D ad - ad D), D ad gamma, D ad D - a ad D =="];
Print["   (NB: the commutation condition must carry the factor a = t11; dividing by a is wrong)"];
ad = {{1,0},{0,la}}; Dm = {{t[2,2], t[2,3]}, {t[3,2], t[3,3]}}; gam = {t[2,1], t[3,1]}; aa = t[1,1];
clean = Select[DeleteDuplicates[Flatten[{
   aa Flatten[Dm . ad - ad . Dm], Dm . ad . gam, Flatten[Dm . ad . Dm - aa ad . Dm]}]], # =!= 0 &];
Print["   #eq = ", Length[clean]];
Do[Print["     ", Simplify[clean[[i]]]], {i, Length[clean]}];
memR[g_, I0_] := Module[{gb},
   gb = DeleteCases[GroebnerBasis[Join[I0, {1 - yv g}], Join[vars0, {yv}],
        MonomialOrder -> DegreeReverseLexicographic], 0];
   gb === {1}];
Print["   beta=0 eqs inside <clean> ? ", And @@ (memR[#, clean] & /@ eqs0)];
Print["   clean eqs inside beta=0 ideal ? ", And @@ (memR[#, eqs0] & /@ clean)];

Print[""];
Print["== 4. specialisation lam = 2 =="];
cf2 = mkCF[2];
avg2[i_,j_] := lie[cf2, T[[All,i]], T[[All,j]]] - T . lie[cf2, T[[All,i]], unit[[j]]];
eqs0b = Select[DeleteDuplicates[Simplify[
     Flatten[Table[avg2[i,j], {i,3},{j,3}]] /. {t[1,2] -> 0, t[1,3] -> 0}]], # =!= 0 &];
gb2 = GroebnerBasis[eqs0b, vars0, MonomialOrder -> DegreeReverseLexicographic];
Print["   beta=0 eqs = ", eqs0b];
Print["   GB = ", gb2];

Print[""];
Print["== 5. numeric check at lam = 2 =="];
resid2[MT_] := Max[Abs[Flatten[Table[
   lie[cf2, MT[[All,i]], MT[[All,j]]] - MT . lie[cf2, MT[[All,i]], unit[[j]]],
   {i,3},{j,3}]]]];
tests2 = {
  {"T=0", {{0,0,0},{0,0,0},{0,0,0}}},
  {"e2 e1^T", {{0,0,0},{1,0,0},{0,0,0}}},
  {"e3 e1^T", {{0,0,0},{0,0,0},{1,0,0}}},
  {"(e2+e3) e1^T", {{0,0,0},{1,0,0},{1,0,0}}},
  {"a e1 e1^T (a=3)", {{3,0,0},{0,0,0},{0,0,0}}},
  {"diag(a,a,0) (a=3)", {{3,0,0},{0,3,0},{0,0,0}}},
  {"diag(a,0,a) (a=3)", {{3,0,0},{0,0,0},{0,0,3}}},
  {"a Id3 (a=4)", {{4,0,0},{0,4,0},{0,0,4}}},
  {"POSITIVE a=0: e2 e3^T", {{0,0,0},{0,0,1},{0,0,0}}},
  {"POSITIVE a=0: e3 e2^T", {{0,0,0},{0,1,0},{0,0,0}}},
  {"POSITIVE a=0: e1e3-type? {{0,...},{0,0,0},{1,0,0}}", {{0,0,0},{0,0,0},{1,0,0}}},
  {"NEGATIVE diag(1,2) block, a=5", {{5,0,0},{0,1,0},{0,0,2}}},
  {"NEGATIVE random", {{1,1,0},{0,2,0},{3,0,1}}}
};
Do[Print["   ", tests2[[k,1]], "   resid = ", resid2[tests2[[k,2]]]], {k, Length[tests2]}];

Print[""];
Print["== 6. the a = 0 branch at lam = 2 =="];
eqsA0 = Select[DeleteDuplicates[Simplify[
     Flatten[Table[avg2[i,j], {i,3},{j,3}]] /. {t[1,2] -> 0, t[1,3] -> 0, t[1,1] -> 0}]], # =!= 0 &];
Print["   #eq = ", Length[eqsA0]];
Do[Print["     ", Simplify[eqsA0[[i]]]], {i, Length[eqsA0]}];
gbA0 = GroebnerBasis[eqsA0, DeleteCases[vars0, t[1,1]],
   MonomialOrder -> DegreeReverseLexicographic];
Print["   GB size = ", Length[gbA0]];
Do[Print["     ", Simplify[gbA0[[i]]]], {i, Length[gbA0]}];

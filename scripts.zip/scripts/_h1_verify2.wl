(* ============================================================
   Independent re-check of the averaging operators on h1.
   Condition (one-term averaging, Aguiar / Das-Sen):
        [T(x),T(y)] = T([T(x),y])   for all x,y
   h1 = span(e1,e2,e3), [e1,e2] = e3, e3 central.
   ============================================================ *)
ClearAll["Global`*"];
sc = SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i],{i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]],{i,3},{j,3}],{k,3}];
T = Array[t,{3,3}]; vars = Flatten[T];
avg[cf_,i_,j_] := lie[cf, T[[All,i]], T[[All,j]]] - T . lie[cf, T[[All,i]], unit[[j]]];
eqs = Select[DeleteDuplicates[Flatten[Table[avg[sc,i,j],{i,3},{j,3}]]], # =!= 0 &];
Print["#eq(h1) = ", Length[eqs]];
Print["eqs = ", eqs];

resid[MT_] := Max[Abs[Flatten[Table[lie[sc, MT[[All,i]], MT[[All,j]]] -
    MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3},{j,3}]]]];

Print[""];
Print["===== A. test the family that the earlier merge did not contain ====="];
cands = {
  {"{{1,1,0},{-2,1,0},{0,0,3}}   (lam=3,a=1,b=1,c=-2)", {{1,1,0},{-2,1,0},{0,0,3}}},
  {"{{0,1,0},{0,0,0},{0,0,3}}    (a=0, X nilpotent, lam=3)", {{0,1,0},{0,0,0},{0,0,3}}},
  {"{{3,0,0},{0,3,0},{0,0,3}}    (lam I3, lam=3)", {{3,0,0},{0,3,0},{0,0,3}}},
  {"{{3,0,0},{0,3,0},{1,0,3}}    (X=lam I, z!=0)", {{3,0,0},{0,3,0},{1,0,3}}},
  {"{{3,1,0},{0,3,0},{0,0,3}}    (X=lam I+N)", {{3,1,0},{0,3,0},{0,0,3}}},
  {"{{3,1,0},{0,3,0},{0,1,3}}    (X=lam I+N, z!=0)", {{3,1,0},{0,3,0},{0,1,3}}},
  {"{{0,1,0},{0,2,0},{0,0,3}}    (a!=d  -> expect FAIL)", {{0,1,0},{0,2,0},{0,0,3}}},
  {"{{1,0,0},{0,1,0},{5,0,3}}    (a^2-bc!=lam a -> expect FAIL)", {{1,0,0},{0,1,0},{5,0,3}}},
  {"{{1,2,0},{3,1,0},{0,0,3}}    (a^2-bc!=lam a -> expect FAIL)", {{1,2,0},{3,1,0},{0,0,3}}}
};
Do[Print["  ", cands[[k,1]], "   resid = ", resid[cands[[k,2]]]], {k, Length[cands]}];

Print[""];
Print["===== B. completeness tests (Rabinowitsch / Groebner) ====="];
radQ[q_] := Module[{gb},
   gb = GroebnerBasis[Join[eqs, {1 - yv q}], Join[vars, {yv}],
        MonomialOrder -> DegreeReverseLexicographic];
   gb = DeleteCases[gb, 0];
   gb === {1}];
tests = {
  {"t13 = 0", t[1,3]},
  {"t23 = 0", t[2,3]},
  {"det X - lam*t11 = 0", t[1,1] t[2,2] - t[1,2] t[2,1] - t[3,3] t[1,1]},
  {"det X - lam*t22 = 0", t[1,1] t[2,2] - t[1,2] t[2,1] - t[3,3] t[2,2]},
  {"control: t12 - t21 (should be False)", t[1,2] - t[2,1]}
};
Do[Print["  ", tests[[k,1]], "  is forced by the equations?  ",
    AbsoluteTiming[radQ[tests[[k,2]]]][[2]], "  (", Round[AbsoluteTiming[radQ[tests[[k,2]]]][[1]],0.01], " s)"],
  {k, Length[tests]}];

Print[""];
Print["===== C. verify the parametrized solution set solves the system ====="];
(* case lam = 0: X = u v^T, z free *)
T0 = {{u1 v1, u1 v2, 0}, {u2 v1, u2 v2, 0}, {e, f, 0}};
Print["  lam=0 parametrization: Simplify[eqs] = ",
   Simplify[eqs /. Thread[vars -> Flatten[T0]]]];
(* case lam != 0: a = d, a^2 - bc = lam a  ->  c = a (a - lam)/b *)
T1 = {{a, b, 0}, {a (a - lam)/b, a, 0}, {e, f, lam}};
Print["  lam!=0 parametrization (b generic): Simplify[eqs] = ",
   Simplify[eqs /. Thread[vars -> Flatten[T1]]]];

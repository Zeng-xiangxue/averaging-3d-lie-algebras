(* moduli dimension of the beta2 != 0 branch of r(1,0) *)
B = {{p, 0}, {0, s}};
phi = {{1,0,0},{w1,B[[1,1]],B[[1,2]]},{w2,B[[2,1]],B[[2,2]]}};
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi.T1.Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z*p*s}], {p, s, w1, w2, z},
        MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];

T[g_, m_] := {{0, 0, 1}, {0, 0, 0}, {g, 0, m}};

Print["T(0,0) ~ T(1,0) ?  ", conjQ[T[0,0], T[1,0]]];
Print["T(0,0) ~ T(0,1) ?  ", conjQ[T[0,0], T[0,1]]];
Print["T(0,0) ~ T(1,1) ?  ", conjQ[T[0,0], T[1,1]]];
Print["T(1,0) ~ T(0,1) ?  ", conjQ[T[1,0], T[0,1]]];
Print["T(1,2) ~ T(3,4) ?  ", conjQ[T[1,2], T[3,4]]];
Print["T(1,2) ~ T(1,3) ?  ", conjQ[T[1,2], T[1,3]]];
(* and the analogue with a = 0 but M21 = w  (same orbit) *)
Print["T(0,0) ~ its w-shifted partner ?  ",
  conjQ[T[0,0], {{0, 0, 1}, {0, 0, 0}, {0, 0, 0}}]];

(* is the beta2!=0 branch disjoint from the beta2=0 families? *)
Print["T(0,0) ~ e2e3'+mu e3e3' (mu=0) ?  ", conjQ[T[0,0], {{0,0,0},{0,0,1},{0,0,0}}]];
Print["T(0,0) ~ e2e3'+e3e1'+mu e3e3' ?   ", conjQ[T[0,0], {{0,0,0},{0,0,1},{1,0,2}}]];

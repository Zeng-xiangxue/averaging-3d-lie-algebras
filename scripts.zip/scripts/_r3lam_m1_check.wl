(* Check lambda=-1 identifications and 11/8 class counts *)
ClearAll["Global`*"];
lam = -1;
sc = SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->lam, {3,3,1}->-lam}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
autResid[ph_] := Max[Abs[Flatten[Table[
  lie[sc, ph[[All,i]], ph[[All,j]]] - ph . lie[sc, unit[[i]], unit[[j]]], {i,3}, {j,3}]]]];
conj[ph_, T_] := ph . T . Inverse[ph];

Print["== 1. swap component is automorphism (lambda=-1) =="];
R = {{0,q},{r,0}};
ph = Join[{{-1,0,0}}, Join[{{v1,v2}}, R, 2], 2];
ph = {{-1,0,0},{v1,0,q},{v2,r,0}};
Print["  autResid = ", autResid[ph], "  (expect 0; det(phi) = ", Det[ph], " = q r)"];

Print["== 2. identifications via explicit R =="];
(* (a) diag(a,a,0) ~ diag(a,0,a): D=diag(a,0) -> R D R^-1 = diag(0,a) *)
a0 = 2; q0 = 3; r0 = 4;
R = {{0,q0},{r0,0}}; v = {0,0};
T1 = {{a0,0,0},{0,a0,0},{0,0,0}};         (* diag(a,a,0) *)
T2 = {{a0,0,0},{0,0,0},{0,0,a0}};         (* diag(a,0,a) *)
ph = {{-1,0,0},{0,0,q0},{0,r0,0}};
Print["  (a) phi diag(a,a,0) phi^-1 = ", MatrixForm[conj[ph, T1]]];
Print["      resid(T1)=", resid[T1], "  resid(T2)=", resid[T2]];
(* (b) e2 e3^T ~ e3 e2^T *)
T23 = {{0,0,0},{0,0,1},{0,0,0}}; T32 = {{0,0,0},{0,0,0},{0,1,0}};
Print["  (b) phi e2e3^T phi^-1 = ", MatrixForm[conj[ph, T23]], "  (scalar multiple of e3e2^T?)"];
(* (c) e2 e1^T ~ e3 e1^T : gamma -> -R gamma *)
T21 = {{0,0,0},{1,0,0},{0,0,0}}; T31 = {{0,0,0},{0,0,0},{1,0,0}};
Print["  (c) phi e2e1^T phi^-1 = ", MatrixForm[conj[ph, T21]], "  (along e3? scalar multiple of e3e1^T)"];

Print["== 3. a is invariant (beta=0 => a'=a) for both components =="];
Do[
  b0 = RandomReal[{-3,3},1][[1]]; If[Abs[b0]<0.1, b0=1.5]; c0 = RandomReal[{-3,3},1][[1]]; If[Abs[c0]<0.1, c0=2.5];
  B = DiagonalMatrix[{b0,c0}]; phd = {{1,0,0},{0,b0,0},{0,0,c0}};
  q1 = RandomReal[{-3,3},1][[1]]; If[Abs[q1]<0.1, q1=1.2]; r1 = RandomReal[{-3,3},1][[1]]; If[Abs[r1]<0.1, r1=2.2];
  phs = {{-1,0,0},{0,0,q1},{0,r1,0}};
  Do[
    T = {{A,0,0},{0,0,0},{0,0,0}};
    Print["  diagonal:  a' = ", conj[phd,T][[1,1]], "  swap: a' = ", conj[phs,T][[1,1]], "  (both = a = ", A, "?)"],
    {A, {3, -2}}],
  {1}];

Print["== 4. lambda=2: diag(a,a,0) NOT ~ diag(a,0,a) (diagonal Aut cannot swap) =="];
lam = 2;
B2 = DiagonalMatrix[{b,c}];
M = B2 . {{a,0},{0,0}} . Inverse[B2];
Print["  B diag(a,0) B^-1 = ", M, "  = diag(a,0) always (diagonal conjugation keeps diagonal) -> distinct classes for lambda != -1"];

Print["== 5. D_t family (lambda=-1): t = tr/2 invariant, self-corresponding =="];
Dt = {{t,1},{t^2,t}};
Print["  R D_t R^-1 with q=1,r=t^2: ", Simplify[{{0,1},{t^2,0}} . Dt . Inverse[{{0,1},{t^2,0}}}], "  (= D_t)"];
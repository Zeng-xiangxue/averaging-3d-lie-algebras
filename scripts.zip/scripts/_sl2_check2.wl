(* sl2 check round 2: key GB factors in the ideal + inner automorphism equivariance (fix E symbol) *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
TT = Table[t[i,j], {i,3}, {j,3}];
vars = Flatten[TT];
eqs = DeleteCases[Flatten[Table[lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]], 0];
gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
Print["== key factors: are they in the ideal (PolynomialReduce -> 0)? =="];
factors = {"g24 t11^2-t33^2" -> t[1,1]^2 - t[3,3]^2,
           "g15 t22(t11-t33)" -> t[2,2] (t[1,1] - t[3,3]),
           "g14 (2t12-t23)(t22-t33)" -> (2 t[1,2] - t[2,3]) (t[2,2] - t[3,3]),
           "g22 2t12^2+t12 t23-t23^2" -> 2 t[1,2]^2 + t[1,2] t[2,3] - t[2,3]^2,
           "g6 t31(t21-2t32)" -> t[3,1] (t[2,1] - 2 t[3,2]),
           "g30 t32(t23 t32 - t22 t33)" -> t[3,2] (t[2,3] t[3,2] - t[2,2] t[3,3])};
Do[
  f = factors[[k,2]];
  red = PolynomialReduce[f, gb, vars][[2]];
  Print["  ", factors[[k,1]], ": in ideal? ", red == 0, "   (reduce to ", red, ")"],
  {k, Length[factors]}];

Print["== does GB contain scaled versions? scan all 34 =="];
Do[
  g = gb[[i]];
  If[PolynomialReduce[t[1,1]^2 - t[3,3]^2, {g}, vars][[2]] == 0 || PolynomialReduce[t[2,2](t[1,1]-t[3,3]), {g}, vars][[2]] == 0 || PolynomialReduce[(2t[1,2]-t[2,3])(t[2,2]-t[3,3]), {g}, vars][[2]] == 0 || PolynomialReduce[2t[1,2]^2+t[1,2]t[2,3]-t[2,3]^2, {g}, vars][[2]] == 0,
    Print["  g", i, " = ", g]],
  {i, Length[gb]}];

Print["== inner automorphism equivariance (proper basis) =="];
FF = {{0,1},{0,0}}; HH = {{1/2,0},{0,-1/2}}; EE = {{0,0},{1,0}};
basis = {FF, HH, EE};
coords[M_] := Flatten[LinearSolve[Flatten /@ basis, Flatten[M]]];
admat[a_] := Table[coords[{a, basis[[j]]}], {j, 3}];
Do[
  M = RandomReal[{-2,2}, {2,2}] + 2 IdentityMatrix[2];
  ph = Table[coords[M . basis[[j]] . Inverse[M]], {j, 3}];
  T0 = {{0,0,0},{0,0,0},{1,0,0}};
  Tc = ph . T0 . Inverse[ph];
  Print["  inner conj resid = ", resid[Tc], "   (expect 0)"],
  {3}];

Print["== Killing form K and ad in so(K) =="];
K = Table[Tr[admat[basis[[i]]] . admat[basis[[j]]]], {i,3}, {j,3}];
Print["  K = ", K // MatrixForm, "   eigenvalues = ", Sort[Eigenvalues[K] // N]];
Print["  ad in so(K): ", And @@ Table[Max[Abs[Flatten[K . admat[a] + Transpose[K . admat[a]]]]] < 10^-9, {a, {FF, HH, EE}}]];
Print["  [ad_F,ad_H2] = ad_[F,H2]: ", Max[Abs[Flatten[admat[FF] . admat[HH] - admat[HH] . admat[FF] - admat[lie[sc,Flatten[FF],Flatten[HH]]]]]] < 10^-9];
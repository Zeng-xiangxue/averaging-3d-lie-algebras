(* 验证 so(3) 上 averaging（一项版）与权0 RBO（两项版）的关系 *)
e1 = {1, 0, 0}; e2 = {0, 1, 0}; e3 = {0, 0, 1};
lie[x_, y_] := Cross[x, y];

avgEq[P_, x_, y_] := Expand[lie[P.x, P.y] - P.(lie[x, P.y])];
rbo0Eq[P_, x_, y_] := Expand[lie[P.x, P.y] - P.(lie[P.x, y] + lie[x, P.y])];
allPairs = Tuples[{e1, e2, e3}, 2];

check[name_, P_] := Module[{av, rb},
  av = Select[Flatten[Table[avgEq[P, x, y], {x, {e1, e2, e3}}, {y, {e1, e2, e3}}]], # =!= 0 &];
  rb = Select[Flatten[Table[rbo0Eq[P, x, y], {x, {e1, e2, e3}}, {y, {e1, e2, e3}}]], # =!= 0 &];
  Print[name, " | averaging 非零方程: ", Length[av], " | 权0RBO 非零方程: ", Length[rb]]
];

\[Lambda] = Symbol["lambda"];
check["lambda*Id", IdentityMatrix[3]*\[Lambda]];

a11 = Symbol["a11"]; a12 = Symbol["a12"]; a13 = Symbol["a13"];
a21 = Symbol["a21"]; a22 = Symbol["a22"]; a23 = Symbol["a23"];
a31 = Symbol["a31"]; a32 = Symbol["a32"]; a33 = Symbol["a33"];

P1 = DiagonalMatrix[{a11, 0, 0}];
check["ERA(I) diag(a11,0,0)", P1];

P2 = {{a12^2/a22, a12, 0}, {a12, a22, 0}, {0, 0, 0}};
check["ERA(II) P5型", P2];

P7 = {{a13^2/a33, a13*a23/a33, a13}, {a13*a23/a33, a23^2/a33, a23}, {a13, a23, a33}};
check["ERA(III) P7满秩型", P7];

Print["rank(P2)=", MatrixRank[P2 /. {a12 -> 2, a22 -> 3}], "  rank(P7)=", MatrixRank[P7 /. {a13 -> 1, a23 -> 2, a33 -> 3}]];

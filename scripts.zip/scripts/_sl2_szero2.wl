ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
resid0[MT_] := Max[Abs[Flatten[Table[lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
Print["== A. exact counterexamples to  s != 0 => T = s Id =="];
T1 = Rationalize[{{2.5,1,-1},{-5,-2,2},{-6.25,-2.5,2.5}}, 0];
T2 = {{0,1,-2},{0,-1,2},{0,0,0}};
T3 = Rationalize[{{1.5,0,1},{0,0,0},{2.25,0,1.5}}, 0];
Do[Print["  ", nm, " : resid = ", resid0[MM], "   tr = ", Tr[MM],
      "   rank = ", MatrixRank[MM],
      "   scalar? ", MM === (Tr[MM]/3) IdentityMatrix[3]],
  {{nm,MM}, {{"T1", T1}, {"T2", T2}, {"T3", T3}}}];
Print["  T1 rank-one form: T1 = v w^T with v = ", {1,-2,-5/2},
      ", w = ", {5/2,1,-1}, "  -> check w^T ad_v = 0 : ",
      Simplify[({5/2,1,-1} . Table[lie[sc, {1,-2,-5/2}, unit[[j]]][[i]], {i,3},{j,3}])]];
Print["== B. what IS true: T invertible => T = s Id (Schur) =="];
Do[
  x0 = RandomReal[{-1,1},3];
  x0 = If[Norm[x0] < 0.3, {0.4,-0.2,0.3}, x0];
  Ph = MatrixExp[Table[Sum[x0[[k]] (Normal[SparseArray[{{k,i,j}->1},{3,3,3}]][[i]]), {k,3}], {i,3},{j,3}]];
  Print["  inner automorphism, resid = ", Round[resid0[Ph], 0.0001],
        "  (expect > 0 unless Ph = +-Id)"], {2}];
Print["== C. rank-1 solutions T = v w^T, w in ker(ad_v^T) =="];
admat[u_] := Table[lie[sc, u, unit[[j]]][[i]], {i,3},{j,3}];
Do[
  v0 = RandomReal[{-2,2},3];
  W0 = NullSpace[Transpose[admat[v0]]];
  If[W0 =!= {},
    w0 = W0[[1]];
    T0 = Outer[Times, v0, w0];
    Print["  v = ", Round[v0,0.01], "  rank(ad_v) = ", MatrixRank[admat[v0]],
      "  dim ker(ad_v^T) = ", Length[W0],
      "  T = v w^T: resid = ", Round[resid0[T0], 10^-9],
      "  tr = ", Round[Tr[T0] - (Tr[T0] // Rationalize), 10^-9] + Tr[T0] // Round[#, 0.01] &,
      "  type(K(v,v)) = ", Sign[Chop[v0 . KK0 . v0]]]],
  {3}];
Print["== D. non-solution controls =="];
Do[Print["  ", nm, " resid = ", resid0[MM]], {{nm,MM},
  {{"diag(0,1,1)", {{0,0,0},{0,1,0},{0,0,1}}},
   {"e1 e3^T = {{0,0,1},{0,0,0},{0,0,0}}", {{0,0,1},{0,0,0},{0,0,0}}},
   {"e3 e1^T = {{0,0,0},{0,0,0},{1,0,0}}", {{0,0,0},{0,0,0},{1,0,0}}}}}];

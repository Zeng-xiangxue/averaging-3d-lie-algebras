(* Clean numeric check: subalgebra spectrum of se(3) *)
ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
basis = IdentityMatrix[6];
e = basis[[1 ;; 3]]; f = basis[[4 ;; 6]];

dist[w_, gens_] := Norm[w - gens . LeastSquares[gens, w]];
maxdist[gens_] := Max[Flatten[Table[dist[br[gens[[i]], gens[[j]]], gens],
    {i, Length[gens]}, {j, Length[gens]}]]];
sub[gens_] := maxdist[gens] < 10.^-9;

t[name_, gens_] := Print[name, " : subalgebra = ", sub[gens],
  "   (max bracket distance = ", maxdist[gens], ")"];

Print["--- 3-dim ---"];
t["V (abelian)                    ", {f[[1]], f[[2]], f[[3]]}];
t["h (so(3))                      ", {e[[1]], e[[2]], e[[3]]}];
t["mixed span(e1,f2,f3) se(2)-type", {e[[1]], f[[2]], f[[3]]}];
t["mixed span(e1,f1,f2)           ", {e[[1]], f[[1]], f[[2]]}];
Print["--- 4-dim ---"];
t["V (+) span(e1)                 ", {e[[1]], f[[1]], f[[2]], f[[3]]}];
t["h (+) span(f1)                 ", {e[[1]], e[[2]], e[[3]], f[[1]]}];
Print["--- 5-dim candidates ---"];
t["h (+) span(f1,f2)              ", {e[[1]], e[[2]], e[[3]], f[[1]], f[[2]]}];
t["V (+) span(e1,e2)              ", {e[[1]], e[[2]], f[[1]], f[[2]], f[[3]]}];
t["mixed generic                  ", {e[[1]], e[[2]] + f[[1]], f[[1]], f[[2]], f[[3]]}];
Print["--- 2-dim ---"];
t["span(e1,f1) same direction     ", {e[[1]], f[[1]]}];
t["span(f1,f2) inside V           ", {f[[1]], f[[2]]}];
t["span(e1,f2) diff directions    ", {e[[1]], f[[2]]}];
Print["--- misc ---"];
t["full se(3)                     ", basis];
Print["--- random 5-dim subspaces: search for a closed one ---"];
SeedRandom[42];
found = False;
Do[
  M = RandomVariate[NormalDistribution[], {6, 5}];
  If[maxdist[M] < 10.^-6, found = True; Print["  CLOSED 5-dim found at sample ", k]];
, {k, 200}];
Print["closed 5-dim subspace among 200 random: ", found];
Print["Done."];

M = {{p, q}, {r, s}};
gamma = {g1, g2};

Do[
  Print["=========== A = ", A, " ==========="];
  eqM = Thread[Flatten[M.A.M] == 0];
  Print["--- M.A.M = 0 的解 (a = 0 支) ---"];
  Print[Reduce[eqM, {p, q, r, s}, Reals]];
  Print["--- 加上 M.A.gamma = 0 ---"];
  Print[Reduce[Join[eqM, Thread[M.A.gamma == 0]], {p, q, r, s, g1, g2}, Reals]];
  ,
  {A, {{{1, 1}, {0, 1}}, {{0, -1}, {1, 0}}, {{c, -1}, {1, c}}}}
  ];

ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
admat[u_] := Table[lie[sc, u, unit[[j]]][[i]], {i,3},{j,3}];
KK = Table[Tr[admat[unit[[i]]] . admat[unit[[j]]]], {i,3}, {j,3}];
Ki = Inverse[KK];
star[M_] := Ki . Transpose[M] . KK;
T = Array[t,{3,3}]; vars = Flatten[T];
comp[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
eqs = Select[DeleteDuplicates[Flatten[Table[comp[i,j], {i,3},{j,3}]]], # =!= 0 &];
A = T - star[T];   (* antisymmetric part; want it to vanish on the solution set *)
Print["== is the antisymmetric part forced to vanish? =="];
Do[
  gb = TimeConstrained[GroebnerBasis[Join[eqs, {Flatten[A][[k]] zz - 1}], Append[vars, zz],
       MonomialOrder -> DegreeReverseLexicographic], 200, "TO"];
  Print["   A-component ", k, " forced 0 ? ", If[gb === "TO", "TIMEOUT", DeleteCases[gb,0] === {1}]],
  {k, Length[Flatten[A]]}];
Print[""];
Print["== explicit check on the representatives =="];
vSp={0,1,0}; vTi={1,0,-1}; vNu={1,0,0};
mk[v_] := Outer[Times, v, KK . v];
Do[M0 = MM; Print["   ", nm, "  ||T - T*|| = ", Max[Abs[Flatten[M0 - star[M0]]]]],
 {{nm,MM}, {{"0", ConstantArray[0,{3,3}]}, {"Id", unit}, {"e2e2^T", mk[vSp]/2},
   {"(e1-e3)(e1-e3)^T", mk[vTi]/4}, {"e1e3^T", mk[vNu]/4}, {"-e1e3^T", -mk[vNu]/4},
   {"counterexample T=[[0,1,-2],[0,-1,2],[0,0,0]]", {{0,1,-2},{0,-1,2},{0,0,0}}}}}];

(* ===== r(1,0): completeness, take 2 -- with branch conditions substituted ===== *)
ClearAll["Global`*"];
E11 = {{1,0,0},{0,0,0},{0,0,0}}; E22 = {{0,0,0},{0,1,0},{0,0,0}}; E33 = {{0,0,0},{0,0,0},{0,0,1}};
E13 = {{0,0,1},{0,0,0},{0,0,0}}; E21 = {{0,0,0},{1,0,0},{0,0,0}};
E23 = {{0,0,0},{0,0,1},{0,0,0}}; E31 = {{0,0,0},{0,0,0},{1,0,0}}; E32 = {{0,0,0},{0,0,0},{0,1,0}};
phi[p_, s_, w1_, w2_] := {{1, 0, 0}, {w1, p, 0}, {w2, 0, s}};
chk[name_, T_, p_, s_, w1_, w2_, tgt_, conds_ : {}] := Module[{d},
  d = Simplify[Flatten[Simplify[phi[p,s,w1,w2] . T . Inverse[phi[p,s,w1,w2]] - tgt] /. conds]];
  Print["  ", name, " : ", d === ConstantArray[0, 9], "   (residual ", Max[Abs[d]] // Simplify, ")"]];
Print["== branch A2: M21 = m != 0, a = g1 = M12 = 0 =="];
chk["-> e32 + mu*e33", m E32 + mu E33 + g2 E31, p, p/m, p g2/m, 0, E32 + mu E33];
Print["== branch A3a: M12 = m != 0, a = 0, Delta = g2 - mu*g1/m =="];
T3 = m E23 + mu E33 + g1 E21 + g2 E31;
chk["Delta = 0 -> e23 + mu*e33", T3, s/m, s, w1, s g1/m, E23 + mu E33, {g2 -> mu g1/m}];
chk["Delta != 0 -> e23 + e31 + mu*e33", T3, 1/(m (g2 - mu g1/m)), 1/(g2 - mu g1/m),
  w1, (g1/m)/(g2 - mu g1/m), E23 + E31 + mu E33];
Print["== branch B: beta2 != 0, a*M12 = beta2*g1 =="];
TB = a E11 + b2 E13 + g1 E21 + g2 E31 + m12 E23 + m22 E33;
chk["-> e13 + (b2*g2 - a*m22)*e31 + (a+m22)*e33", TB, p, b2, -(p/b2) m12, a,
  E13 + (b2 g2 - a m22) E31 + (a + m22) E33, {g1 -> a m12/b2}];
Print[""];
Print["== the two families that were listed redundantly in the old draft =="];
chk["e23 + 2 e31 + mu e33  ->  e23 + e31 + mu e33  (nu redundant)",
  E23 + 2 E31 + 3 E33, 1, 1, 0, 0, E23 + E31 + 3 E33];
chk["a e11 (mu = 0 member of diag(a,0,mu)) : diag(2,0,0) -> diag(2,0,0)",
  2 E11, p, s, 0, 0, 2 E11];
chk["diag(2,0,0) + g1 e21 + g2 e31  ->  diag(2,0,0)",
  2 E11 + 4 E21 + 5 E31, p, s, -p 4/2, -s 5/(2 - 0), 2 E11];

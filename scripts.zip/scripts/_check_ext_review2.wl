(* 修正版：r(J) 类6 c(e2-e3)e2^T 正确矩阵 = 第2列 c(e2-e3)=(0,c,-c) *)
LCJ[x_, y_] := Module[{coef},
  coef = {0, 0, 0};
  coef += x[[1]] y[[2]] {0, 1, 0};
  coef += x[[1]] y[[3]] {0, 1, 1};
  coef += x[[2]] y[[1]] {0, -1, 0};
  coef += x[[3]] y[[1]] {0, -1, -1};
  coef];
avgJ[T_, x_, y_] := LCJ[T.x, T.y] - T.LCJ[T.x, y];
check[avg_, T_, label_] := Module[{res, allzero = True},
  Do[Do[
    res = avg[T, x, y];
    If[! (res == {0, 0, 0}), allzero = False; Print[label, " FAIL x=", x, " y=", y, " res=", res]],
    {y, IdentityMatrix[3]}], {x, IdentityMatrix[3]}];
  Print[label, " 残差全零: ", allzero]];

Print["--- r(J) 类6 正确矩阵 c(e2-e3)e2^T ---"];
(* 第2列 = c(e2-e3) = (0,c,-c)，即 (2,2)=c, (3,2)=-c *)
M6 = {{0, 0, 0}, {0, 2, 0}, {0, -2, 0}};
check[avgJ, M6, "c(e2-e3)e2^T (c=2)"];
M6b = {{0, 0, 0}, {0, -3, 0}, {0, 3, 0}};
check[avgJ, M6b, "c(e2-e3)e2^T (c=-3)"];

Print["--- r(1,0) 类6/7/8/9 正确形状 ---"];
LC10[x_, y_] := Module[{coef},
  coef = {0, 0, 0};
  coef += x[[1]] y[[2]] {0, 1, 0};
  coef += x[[2]] y[[1]] {0, -1, 0};
  coef];
avg10[T_, x_, y_] := LC10[T.x, T.y] - T.LC10[T.x, y];
(* 类6: e2e3^T + m e3e3^T : (2,3)=1,(3,3)=m *)
check[avg10, {{0,0,0},{0,0,1},{0,0,2}}, "6: e2e3^T+m e3e3^T"];
(* 类7: e3e2^T + m e3e3^T : (3,2)=1,(3,3)=m *)
check[avg10, {{0,0,0},{0,0,0},{0,1,2}}, "7: e3e2^T+m e3e3^T"];
(* 类8: e2e3^T+e3e1^T+m e3e3^T : (2,3)=1,(3,1)=1,(3,3)=m *)
check[avg10, {{0,0,0},{0,0,1},{1,0,2}}, "8: e2e3^T+e3e1^T+m e3e3^T"];
(* 类9: e2e1^T+m e3e3^T : (2,1)=1,(3,3)=m *)
check[avg10, {{0,0,0},{1,0,0},{0,0,2}}, "9: e2e1^T+m e3e3^T"];
(* 类13: diag(a,0,m) *)
check[avg10, {{3,0,0},{0,0,0},{0,0,2}}, "13: diag(a,0,m)"];
(* 类15: (a 0 1;0 0 0;0 0 s) *)
check[avg10, {{3,0,1},{0,0,0},{0,0,4}}, "15: (a,0,1;0,0,0;0,0,s)"];

Print["--- 引理3.14 中心化子：c=2 具体值下 B Cc = Cc B 的解 ---"];
D2 = {{2, -1}, {1, 2}};
B = {{b11, b12}, {b21, b22}};
solB = Solve[Flatten[B.D2 == D2.B], {b11, b12, b21, b22}];
Print["c=2 中心化子: ", solB];
Print["--- c=0 时 a=-1 分支的 B（b21=a b12, b22=-a b11 带 a=-1: B=[[b11,b12],[b12,-b11]]）是否反交换于 C0 ---"];
C0 = {{0, -1}, {1, 0}};
Bm = {{p, q}, {q, -p}};
Print["B.C0 + C0.B == 0 (a=-1): ", Simplify[Bm.C0 + C0.Bm]];

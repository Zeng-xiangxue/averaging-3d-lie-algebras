ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
admat[u_] := Table[lie[sc, u, unit[[j]]][[i]], {i,3},{j,3}];
KK = Table[Tr[admat[unit[[i]]] . admat[unit[[j]]]], {i,3},{j,3}];
mk[v_] := Outer[Times, v, KK . v];
conjd[T1_, T2_] := Module[{f, best = Infinity, val},
  f[x1_?NumericQ, x2_?NumericQ, x3_?NumericQ] := Module[{M},
    M = MatrixExp[x1 admat[unit[[1]]] + x2 admat[unit[[2]]] + x3 admat[unit[[3]]]];
    Norm[M . T1 . Inverse[M] - T2]];
  Do[val = FindMinimum[f[x1,x2,x3], {{x1,r1},{x2,r2},{x3,r3}}, MaxIterations -> 300][[1]];
     best = Min[best, val], {r1,{-1.,1.}},{r2,{-1.,1.}},{r3,{-1.,1.}}];
  best];
vSp = {0.,1,0}; vTi = {1.,0,-1}; vNu = {1.,0,0};
Tsp = mk[vSp]; Tti = mk[vTi]; Tnu = mk[vNu];
Tsp2 = mk[{1.,2,3}/4];
Print["Tsp = ", MatrixForm[Tsp], "  tr = ", Tr[Tsp], "  resid-check v==Kv: ",
  Max[Abs[Transpose[admat[vSp]] . (KK . vSp)]]];
Print["Tti = ", MatrixForm[Tti], "  tr = ", Tr[Tti]];
Print["Tnu = ", MatrixForm[Tnu], "  tr = ", Tr[Tnu]];
Print["dist(Tsp, 2 Tsp)          = ", conjd[Tsp, 2 Tsp], "   (expect > 0, traces 2 vs 4)"];
Print["dist(Tsp, spacelike tr=2) = ", conjd[Tsp, Tsp2], "   (expect ~ 0)"];
Print["dist(Tnu, 2 Tnu)          = ", conjd[Tnu, 2 Tnu], "   (boost: expect ~ 0)"];
Print["dist(Tnu, -Tnu)           = ", conjd[Tnu, -Tnu], "   (expect > 0 if sign invariant)"];
Print["dist(Tti, Tsp)            = ", conjd[Tti, Tsp], "   (different K-types: expect > 0)"];

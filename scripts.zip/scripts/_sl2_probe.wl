ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}]; vars = Flatten[T];
comp[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
eqs = Select[DeleteDuplicates[Flatten[Table[comp[i,j], {i,3},{j,3}]]], # =!= 0 &];
trT = Sum[t[i,i], {i,3}];
resid[MT_] := Max[Abs[Flatten[Table[lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
Print["#eq = ", Length[eqs]];
Print["== real solutions with tr T = 3 =="];
Do[
  sol = FindInstance[Join[eqs == 0, {trT == 3, t[1,2] == k}], vars, Reals, 1];
  If[sol === {}, Print["   no real solution with t12 = ", k],
    M0 = Partition[Flatten[vars /. sol[[1]]], 3];
    Print["   t12 = ", k, " : T = ", MatrixForm[Round[M0, 0.01]],
      "  tr = ", Round[Tr[M0], 10^-9], "  resid = ", Round[resid[M0], 10^-9],
      "  scalar? ", Max[Abs[M0 - Tr[M0]/3 IdentityMatrix[3]]] < 10^-6]],
  {k, {1, 2}}];
Print["== real solutions with tr T = 0 =="];
Do[
  sol = FindInstance[Join[eqs == 0, {trT == 0, t[1,2] == k}], vars, Reals, 1];
  If[sol === {}, Print["   no real solution with t12 = ", k, ", tr = 0"],
    M0 = Partition[Flatten[vars /. sol[[1]]], 3];
    Print["   t12 = ", k, " : T = ", MatrixForm[Round[M0, 0.01]],
      "  resid = ", Round[resid[M0], 10^-9]]],
  {k, {0, 1}}];
Print["== known candidates =="];
cands = {{"0", ConstantArray[0,{3,3}]}, {"Id", unit}, {"2 Id", 2 unit},
  {"e3 e1^T", {{0,0,0},{0,0,0},{1,0,0}}},
  {"e1 e3^T", {{0,0,0},{0,0,0},{0,0,1}}},
  {"ad_e2", Table[lie[sc, unit[[2]], unit[[j]]][[i]], {i,3},{j,3}]},
  {"ad_e1", Table[lie[sc, unit[[1]], unit[[j]]][[i]], {i,3},{j,3}]},
  {"ad_e3", Table[lie[sc, unit[[3]], unit[[j]]][[i]], {i,3},{j,3}]}};
Do[Print["   ", cands[[k,1]], "  resid = ", resid[cands[[k,2]]]], {k, Length[cands]}];

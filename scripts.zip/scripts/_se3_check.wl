(* Independent check of se3_setup.wl claims
   se(3) = so(3) (+) R^3, basis e1..e3 (rotations) + f1..f3 (translations)
   bracket: [(a,b),(a',b')] = (a x a', a x b' + b x a')                *)

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
basis = IdentityMatrix[6];
e = basis[[1 ;; 3]]; f = basis[[4 ;; 6]];

Print["=== A.  count check: averaging equations ==="];
Tm = Array[tau, {6, 6}];
avgEqsRaw = Flatten[Table[
    br[Tm . basis[[i]], Tm . basis[[j]]] - Tm . br[Tm . basis[[i]], basis[[j]]],
    {i, 6}, {j, 6}]];
Print["raw vector equations: ", Length[avgEqsRaw], " x 6 components = ",
  Length[avgEqsRaw]*6, " scalars; distinct nonzero: ",
  Length[Select[DeleteDuplicates[avgEqsRaw], # =!= 0 &]]];

(* antisymmetry? random numeric T *)
SeedRandom[7];
T0 = RandomReal[{-1, 1}, {6, 6}];
aij[i_, j_] := br[T0 . basis[[i]], T0 . basis[[j]]] - T0 . br[T0 . basis[[i]], basis[[j]]];
Print["random T:  a[1,2]+a[2,1] norm = ", Norm[aij[1, 2] + aij[2, 1]],
  "   a[1,1] norm = ", Norm[aij[1, 1]],
  "  -> averaging has NO antisymmetry, diagonal pairs are nonzero"];

Print[""];
Print["=== B.  Der(se(3)) explicit 7-parameter structure ==="];
(* claimed: D(x,lam,t)(h,v) = (x x h, lam v + x x v + t x h)  *)
DmGen[x_, lam_, t_] := Module[{A1, A2},
  A1[h_] := Cross[x, h];
  A2[h_, v_] := lam v + Cross[x, v] + Cross[t, h];
  Function[{w}, Join[A1[w[[1 ;; 3]]], A2[w[[1 ;; 3]], w[[4 ;; 6]]]]]];
(* check it is a derivation for random parameters *)
SeedRandom[11];
okDer = True;
Do[
  x0 = RandomReal[{-1, 1}, 3]; t0 = RandomReal[{-1, 1}, 3]; lam0 = RandomReal[{-1, 1}];
  Dm = DmGen[x0, lam0, t0];
  bad = Max[Abs[Flatten[Table[
      Dm[br[basis[[i]], basis[[j]]]] -
       (br[Dm[basis[[i]]], basis[[j]]] + br[basis[[i]], Dm[basis[[j]]]]),
      {i, 6}, {j, 6}]]]];
  If[bad > 10^-9, okDer = False];
, {30}];
Print["7-parameter family D = (x x h, lam v + x x v + t x h) is a derivation: ", okDer];

(* is the map (x,lam,t) -> D injective? and does it span all derivations? *)
(* injectivity: solve Dm = 0 *)
Dm0 = DmGen[{d1, d2, d3}, dl, {dt1, dt2, dt3}];
imgEqs = Flatten[Table[Dm0[basis[[i]]], {i, 6}]];
sol = Solve[imgEqs == 0, {d1, d2, d3, dl, dt1, dt2, dt3}];
Print["kernel of (x,lam,t)->D: ", sol, "  -> injective, so dim >= 7"];
(* spanning: rank of the coefficient matrix of the 7 generators *)
Gens = Flatten[Table[
   {DmGen[UnitVector[3, k], 0, 0], DmGen[{0, 0, 0}, 1, 0], DmGen[{0, 0, 0}, 0, UnitVector[3, k]]},
   {k, 3}], 1];
GM = Flatten[Table[Flatten[G[[k]]], {k, 7}], 1];
Print["rank of generator matrix (max possible 36): ",
  MatrixRank[Table[Flatten[gm], {gm, Gens}]]];
Print["(se3_setup.wl reported: 96 equations, rank 29, 36-29 = 7)"];
Print["sanity: so(3) Der = ad, dim 3 (rank 6 of 9)"];
Print[""];

Print["=== C.  structural levers ==="];
avgDef[R_] := Max[Abs[Flatten[Table[
     br[R . basis[[i]], R . basis[[j]]] - R . br[R . basis[[i]], basis[[j]]],
     {i, 6}, {j, 6}]]]];
ok[R_] := avgDef[R] < 10.^-12;
blk[A_, B_, C_, Dm_] := ArrayFlatten[{{A, B}, {C, Dm}}];
Z = ConstantArray[0, {3, 3}];

(* (c1) T = A (+) 0 is averaging  <=>  A averaging on so(3)  *)
A0 = {{a11, a12, a13}, {a21, a22, a23}, {a31, a32, a33}};
Tblk = blk[A0, Z, Z, Z];
avFull = Flatten[Table[
    br[Tblk . basis[[i]], Tblk . basis[[j]]] - Tblk . br[Tblk . basis[[i]], basis[[j]]],
    {i, 6}, {j, 6}]] // Expand;
avFull = DeleteCases[avFull, 0];
Print["(c1) equations of T=A(+)0: ", Length[avFull],
  " ; they involve only A and are exactly so(3)-averaging: ",
  AllTrue[avFull, FreeQ[#, a11 | a12 | a13 | a21 | a22 | a23 | a31 | a32 | a33, Infinity] &] == False];

(* (c2) lam I_h (+) mu I_V: check condition symbolically *)
lamI = blk[lam IdentityMatrix[3], Z, Z, mu IdentityMatrix[3]];
res = Flatten[Table[
    br[lamI . basis[[i]], lamI . basis[[j]]] - lamI . br[lamI . basis[[i]], basis[[j]]],
    {i, 6}, {j, 6}]] // Expand;
res = DeleteCases[res, 0];
Print["(c2) lam I_h (+) mu I_V residual terms: ", res, " -> condition ",
  Reduce[And @@ Thread[res == 0], {lam, mu}]];
Print["     numeric check lam=3, mu=7: ",
  avgDef[blk[3 IdentityMatrix[3], Z, Z, 7 IdentityMatrix[3]]] > 10.^-6, " (not averaging)"];

(* (c3) T = 0 (+) D: pair (v,h) forces D((Dv) x h) = 0 *)
Dv = {{d11, d12, d13}, {d21, d22, d23}, {d31, d32, d33}};
T0D = blk[Z, Z, Z, Dv];
res3 = Flatten[Table[
    br[T0D . basis[[i]], T0D . basis[[j]]] - T0D . br[T0D . basis[[i]], basis[[j]]],
    {i, 6}, {j, 6}]] // Expand;
res3 = DeleteCases[res3, 0];
Print["(c3) 0(+)D equations: ", Length[res3], " ; sample (pure V, pure h) pair: ",
  res3[[1 ;; 3]]];
Print["     3*I_V on V block is NOT averaging: ",
  avgDef[blk[Z, Z, Z, 3 IdentityMatrix[3]]] > 10.^-6];
Print["");

Print["=== D.  subalgebra spectrum of se(3) ==="];
subCheck[gens_] := Module[{dim, all, okb = True, x, y},
  dim = Length[gens];
  all = Flatten[Table[br[gens[[i]], gens[[j]]], {i, dim}, {j, dim}]];
  okb = AllTrue[all, (Length[NullSpace[Transpose[gens]]] == 6 - dim &&
       (# . MatrixPower[Transpose[gens] . gens, 0] == 0)) &]];
  okb];
inSpan[w_, gens_] := Norm[w - gens . LinearSolve[Transpose[gens] . gens, Transpose[gens] . w]] < 10.^-8;
closed[gens_] := AllTrue[Flatten[Table[br[gens[[i]], gens[[j]]], {i, Length[gens]}, {j, Length[gens]}], 1],
   inSpan[#, gens] &];

Print["V = span(f1,f2,f3) is a subalgebra: ", closed[{f[[1]], f[[2]], f[[3]]}]];
Print["h = span(e1,e2,e3) is a subalgebra: ", closed[{e[[1]], e[[2]], e[[3]]}]];
Print["mixed 3-dim span(e1,f2,f3): ", closed[{e[[1]], f[[2]], f[[3]]}],
  "  (structure: [e1,f2]=f3, [e1,f3]=-f2, [f2,f3]=0) -> se(2)-like, NOT isomorphic to h or V"];
Print["4-dim V (+) span(e1): ", closed[{e[[1]], f[[1]], f[[2]], f[[3]]}]];
Print["5-dim h (+) span(f1,f2): ", closed[{e[[1]], e[[2]], e[[3]], f[[1]], f[[2]]}],
  "  <- candidate 5-dim fails ([e1,f2]=f3 escapes) "];
Print["5-dim V (+) span(e1,e2): ", closed[{e[[1]], e[[2]], f[[1]], f[[2]], f[[3]]}],
  "  <- candidate 5-dim fails ([e1,e2]=e3 escapes)"];

Print["Done."];

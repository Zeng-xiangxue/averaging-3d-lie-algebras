(* Independent check of sl(2,R) setup:
   1) bracket convention, (1,3) and (2,2) equations
   2) known solutions resid 0 + Aut equivariance
   3) Killing form K, eigenvalues, ad in so(K)
   4) Groebner basis: size 34, key factors g24,g15,g14,g22
   5) End decomposition dims *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== 1. bracket check =="];
Print["  [e1,e2] = ", lie[sc, {1,0,0}, {0,1,0}], " (want e1)"];
Print["  [e1,e3] = ", lie[sc, {1,0,0}, {0,0,1}], " (want -2 e2)"];
Print["  [e2,e3] = ", lie[sc, {0,1,0}, {0,0,1}], " (want e3)"];

Print["== 2. equations (1,3) and (2,2) =="];
TT = Table[t[i,j], {i,3}, {j,3}];
eq13 = lie[sc, TT[[All,1]], TT[[All,3]]] - TT . lie[sc, TT[[All,1]], unit[[3]]];
eq22 = lie[sc, TT[[All,2]], TT[[All,2]]] - TT . lie[sc, TT[[All,2]], unit[[2]]];
Print["  (1,3) = ", eq13];
Print["  (2,2) = ", eq22];
Print["  user (1,3): (-2 t13 t21 + t11(2 t12 + t23), -t21 t23 + 2 t13 t31 + 2 t11(t22 - t33), -t23 t31 + 2 t11 t32)"];
Print["  user (2,2): (-t11 t12 + t13 t32, -t12 t21 + t23 t32, -t12 t31 + t32 t33)"];

Print["== 3. known solutions =="];
Print["  T=0            resid = ", resid[{{0,0,0},{0,0,0},{0,0,0}}]];
Print["  T=3 Id         resid = ", resid[{{3,0,0},{0,3,0},{0,0,3}}]];
Print["  T=e3 e1^T      resid = ", resid[{{0,0,0},{0,0,0},{1,0,0}}]];
(* random inner automorphisms acting on e3 e1^T *)
Do[
  M = RandomReal[{-2,2}, {2,2}]; M = M + 2 IdentityMatrix[2]; (* det ~ 4, invertible *)
  If[Abs[Det[M]] < 0.5, M = M + IdentityMatrix[2]];
  (* inner automorphism: X -> M X M^-1 on sl(2,R) basis: e1=F, e2=H/2, e3=E via traceless matrices *)
  F = {{0,1},{0,0}}; H2 = {{1/2,0},{0,-1/2}}; E = {{0,0},{1,0}};
  ph = Table[Flatten[LinearSolve[{Flatten[F],Flatten[H2],Flatten[E]}, Flatten[M . {F,H2,E}[[j]] . Inverse[M]]]], {j,3}];
  T0 = {{0,0,0},{0,0,0},{1,0,0}};
  Tc = ph . T0 . Inverse[ph];
  Print["  conjugate of e3e1^T resid = ", resid[Tc]],
  {3}];

Print["== 4. Killing form =="];
F = {{0,1},{0,0}}; H2 = {{1/2,0},{0,-1/2}}; E = {{0,0},{1,0}};
basis = {F, H2, E};
adM[a_] := Table[Flatten[LinearSolve[Flatten /@ basis, Flatten[{a, basis[[j]]}]]], {j,3}];
K = Table[Tr[adM[basis[[i]]] . adM[basis[[j]]]], {i,3}, {j,3}];
Print["  K = ", K // MatrixForm];
Print["  eigenvalues = ", Eigenvalues[K], " (want {-4,4,2})"];
Print["  ad_a in so(K) for random a: ", 
  And @@ Table[
    Max[Abs[Flatten[K . adM[a] + Transpose[K . adM[a]]]]] < 10^-9,
    {a, {F, H2, E, F+H2+E, 2F-3E}}]];
Print["  [ad_a,ad_b] = ad_[a,b]: ", 
  Max[Abs[Flatten[adM[F] . adM[H2] - adM[H2] . adM[F] - adM[lie[sc,F,H2]]]]] < 10^-9];

Print["== 5. End decomposition dims =="];
Kinv = Inverse[K];
Tstar[MT_] := Kinv . Transpose[MT] . K;
S = (TT + Tstar[TT])/2; A = (TT - Tstar[TT])/2;
Print["  dim Sym = ", MatrixRank[Flatten /@ Table[ReplacePart[TT, {i,j}->(If[i==j,0,0]+0)], {i,3},{j,3}]], " (analytic: 6)"];
Print["  symmetric part S self-adjoint: ", Simplify[S - Tstar[S]] == Table[0,{3},{3}]];
Print["  skew part A anti-adjoint:      ", Simplify[A + Tstar[A]] == Table[0,{3},{3}]];

Print["== 6. Groebner basis: size and key factors =="];
eqs = Flatten[Table[lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]];
eqs = DeleteCases[eqs, 0];
vars = Flatten[TT];
gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
Print["  #equations = ", Length[eqs], "  GB size = ", Length[gb]];
Print["  g24 = t11^2 - t33^2 in GB: ", MemberQ[gb, t11^2 - t33^2] || MemberQ[gb, -(t11^2 - t33^2)]];
Print["  g15 = t22 (t11 - t33) in GB: ", MemberQ[gb, t22 (t11 - t33)] || MemberQ[gb, -t22 (t11 - t33)]];
Print["  g14 = (2 t12 - t23)(t22 - t33) in GB: ", MemberQ[gb, (2 t12 - t23)(t22 - t33)] || MemberQ[gb, -(2 t12 - t23)(t22 - t33)]];
Print["  g22 = 2 t12^2 + t12 t23 - t23^2 in GB: ", MemberQ[gb, 2 t12^2 + t12 t23 - t23^2] || MemberQ[gb, -(2 t12^2 + t12 t23 - t23^2)]];
Print["  sample GB elements 1..8:"];
Do[Print["    g", k, " = ", gb[[k]]], {k, Min[8, Length[gb]]}];
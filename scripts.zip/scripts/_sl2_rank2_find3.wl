(* rank-2 search, fast variants:
   A) random 9-param T with rank 2 (built as u w1^T + z w2^T), scan resid
   B) fix (u,z), solve for (w1,w2) via FindRoot on the 9 equations *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== A) random rank-2 scan =="];
bestA = 10^9; bestAvec = {};
Do[
  uu = RandomReal[{-1,1}, {3}]; zz = RandomReal[{-1,1}, {3}];
  w1 = RandomReal[{-1,1}, {3}]; w2 = RandomReal[{-1,1}, {3}];
  TT = KroneckerProduct[uu, w1] + KroneckerProduct[zz, w2];
  If[MatrixRank[TT] != 2, Continue[]];
  r = resid[TT];
  If[r < bestA, bestA = r; bestAvec = TT],
  {20000}];
Print["  best resid over 20000 random rank-2 = ", bestA];
If[bestA < 10^-9, Print["  FOUND: ", MatrixForm[Round[bestAvec, 10^-6]]]];

Print["== B) fix u,z, solve for w =="];
found = False;
Do[
  uu = RandomReal[{-1,1}, {3}]; zz = RandomReal[{-1,1}, {3}];
  If[Max[Abs[Cross[uu, zz]]] < 0.1, Continue[]];
  w0 = RandomReal[{-1,1}, {6}];
  eqfun[wv_] := Module[{w1, w2, TT},
    {w1, w2} = Partition[wv, 3];
    TT = KroneckerProduct[uu, w1] + KroneckerProduct[zz, w2];
    Flatten[Table[
      lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3},{j,3}]]];
  res = FindRoot[eqfun[wv] == Table[0, {9}], {wv, w0}, MaxIterations -> 200];
  TT = KroneckerProduct[uu, Partition[wv /. res, 3][[1]]] + KroneckerProduct[zz, Partition[wv /. res, 3][[2]]];
  r = resid[TT];
  If[r < 10^-9,
    Print["  FOUND u=", uu, " z=", zz, " T=", MatrixForm[Round[TT, 10^-6]], " resid=", r];
    found = True; Break[]],
  {40}];
If[!found, Print["  no rank-2 solution found in 40 (u,z) attempts"]];

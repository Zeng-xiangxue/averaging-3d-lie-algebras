(* r(1,0): raw bracket equations vs paper system  *)
br[x_, y_] := {0, x[[1]] y[[2]] - y[[1]] x[[2]], 0};
e = IdentityMatrix[3];
T = {{a, b1, b2}, {g1, m11, m12}, {g2, m21, m22}};
vars = {a, b1, b2, g1, g2, m11, m12, m21, m22};
eqs = Union[Flatten[Table[br[T.e[[i]], T.e[[j]]] - T.br[T.e[[i]], e[[j]]], {i, 3}, {j, 3}]]];
Print["#eqs = ", Length[eqs]];
Print["eqs = ", eqs];
gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
Print["GB = ", gb];
Print["dim of solution variety (Reduce summary):"];
red = Reduce[Thread[eqs == 0], vars, Reals];
Print[Length[red], " cases"];
Print[red];
(* paper system *)
paper = {b1, m11 (m11 - a), m11 g1, m11 b2, m11 m12, b2 g1 - a m12, m21 a, m21 g1, m21 b2, m21 m12};
(* candidate system from my derivation *)
mine = {b1, b2 m11, m21, m11 (1 - a), a m12 - g1 b2};
Print["paper GB = ", GroebnerBasis[paper, vars, MonomialOrder -> DegreeReverseLexicographic, Sort -> True]];
Print["mine  GB = ", GroebnerBasis[mine, vars, MonomialOrder -> DegreeReverseLexicographic, Sort -> True]];
Print["raw GB = ", GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic, Sort -> True]];

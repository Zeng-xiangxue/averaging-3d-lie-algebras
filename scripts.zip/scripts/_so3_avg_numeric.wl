(* 数值抽查：so(3) averaging 解的候选族（λId、对称秩1）恒满足方程；
   随机矩阵几乎必然不满足；同时数值抽样求解验证没有遗漏族 *)
e1 = {1, 0, 0}; e2 = {0, 1, 0}; e3 = {0, 0, 1};
lie[x_, y_] := Cross[x, y];
avgEq[P_, x_, y_] := Expand[lie[P.x, P.y] - P.(lie[x, P.y])];
avgResid[P_] := Max[Abs[Flatten[Table[avgEq[P, x, y], {x, {e1, e2, e3}}, {y, {e1, e2, e3}}]]]];

(* 1) 对称秩1: P = mu * v v^T / ||v||^2 *)
SeedRandom[42];
ok = 0;
Do[
  v = RandomReal[{-3, 3}, 3]; mu = RandomReal[{-3, 3}];
  P = mu * Outer[Times, v, v] / (v.v);
  If[avgResid[P] < 10^-9, ok++];
, {50}];
Print["对称秩1 抽查 50 例，全部满足 averaging: ", ok == 50];

(* 2) lambda*Id *)
Print["lambda*Id 残差: ", avgResid[IdentityMatrix[3]*1.7]];

(* 3) 随机矩阵几乎必然不满足 *)
bad = 0;
Do[
  P = RandomReal[{-1, 1}, {3, 3}];
  If[avgResid[P] > 10^-6, bad++];
, {200}];
Print["随机 3x3 矩阵 200 例，不满足 averaging 的: ", bad];

(* 4) ERA 三类具体数值例 *)
Print["ERA(I) diag(3,0,0) 残差: ", avgResid[DiagonalMatrix[{3., 0, 0}]]];
Print["ERA(II) a12=2,a22=3 残差: ", avgResid[{{4./3, 2, 0}, {2, 3, 0}, {0, 0, 0}}]];
Print["ERA(III) v=(1,2,3) 残差: ", avgResid[Outer[Times, {1., 2, 3}, {1., 2, 3}]/3]];
Print["非对称 E12 残差: ", avgResid[{{0, 1, 0}, {0, 0, 0}, {0, 0, 0}}]];

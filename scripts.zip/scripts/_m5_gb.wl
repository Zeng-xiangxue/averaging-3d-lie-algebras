(* _m5_gb.wl : Groebner data of the solution systems, for the appendix *)
ClearAll["Global`*"];
info[name_, eqs_, vars_] := Module[{gb, degs},
  gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
  degs = Max[0, Max[(Exponent[#, vars, Max] & /@ gb) /. {} -> {0}]] ;
  Print[name, " : eqs = ", Length[eqs], "   |GB| = ", Length[gb],
        "   maxdeg = ", Max[Exponent[gb, #] & /@ vars] ];
  ];
(* h1 : basis e1,e2,e3 ; [e1,e2]=e3 *)
h1sc = SparseArray[{{3,1,2}->1,{3,2,1}->-1},{3,3,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]],{i,3},{j,3}],{k,3}];
T3 = Array[t,{3,3}]; vars3 = Flatten[T3];
eqH1 = DeleteDuplicates[Select[Flatten[Table[lie[h1sc,T3[[All,i]],T3[[All,j]]] - T3.lie[h1sc,T3[[All,i]],IdentityMatrix[3][[j]]],{i,3},{j,3}]], #=!=0&]];
info["h1", eqH1, vars3];
(* r3 *)
r3sc = SparseArray[{{2,1,2}->1,{2,2,1}->-1,{3,1,3}->1,{3,3,1}->-1},{3,3,3}];
eqR3 = DeleteDuplicates[Select[Flatten[Table[lie[r3sc,T3[[All,i]],T3[[All,j]]] - T3.lie[r3sc,T3[[All,i]],IdentityMatrix[3][[j]]],{i,3},{j,3}]], #=!=0&]];
info["r3", eqR3, vars3];
(* r(1,0) *)
br10[x_,y_] := {0, x[[1]] y[[2]] - y[[1]] x[[2]], 0};
e = IdentityMatrix[3];
eqR10 = DeleteDuplicates[Select[Flatten[Table[br10[T3.e[[i]], T3.e[[j]]] - T3.br10[T3.e[[i]], e[[j]]],{i,3},{j,3}]], #=!=0&]];
info["r(1,0)", eqR10, vars3];
Print["   r(1,0) GB = ", GroebnerBasis[eqR10, vars3, MonomialOrder -> DegreeReverseLexicographic]];
(* r(J) *)
brJ[x_,y_] := {0, x[[1]](y[[2]]+y[[3]]) - y[[1]](x[[2]]+x[[3]]), x[[1]] y[[3]] - y[[1]] x[[3]]};
eqRJ = DeleteDuplicates[Select[Flatten[Table[brJ[T3.e[[i]], T3.e[[j]]] - T3.brJ[T3.e[[i]], e[[j]]],{i,3},{j,3}]], #=!=0&]];
info["r(J)", eqRJ, vars3];
(* r(c), generic c *)
brC[x_,y_] := {0, x[[1]](cc y[[2]] - y[[3]]) - y[[1]](cc x[[2]] - x[[3]]), x[[1]](y[[2]] + cc y[[3]]) - y[[1]](x[[2]] + cc x[[3]])};
eqRC = DeleteDuplicates[Select[Flatten[Table[brC[T3.e[[i]], T3.e[[j]]] - T3.brC[T3.e[[i]], e[[j]]],{i,3},{j,3}]], #=!=0&]];
info["r(c) (symbolic c)", eqRC, Join[vars3,{cc}]];
info["r(c) (c=0)", eqRC /. cc->0, vars3];
(* sl2 and so3 *)
sc5 = SparseArray[{{2,1,2}->1,{2,2,1}->-1,{3,1,3}->1,{3,3,1}->-1},{3,3,3}];
sl2sc = SparseArray[{{1,1,2}->1,{1,2,1}->-1,{2,1,3}->-2,{2,3,1}->2,{3,2,3}->1,{3,3,2}->-1},{3,3,3}];
eqSL2 = DeleteDuplicates[Select[Flatten[Table[lie[sl2sc,T3[[All,i]],T3[[All,j]]] - T3.lie[sl2sc,T3[[All,i]],IdentityMatrix[3][[j]]],{i,3},{j,3}]], #=!=0&]];
info["sl(2,R)", eqSL2, vars3];
so3sc = SparseArray[{{3,1,2}->1,{3,2,1}->-1,{1,2,3}->1,{1,3,2}->-1,{2,3,1}->1,{2,1,3}->-1},{3,3,3}];
eqSO3 = DeleteDuplicates[Select[Flatten[Table[lie[so3sc,T3[[All,i]],T3[[All,j]]] - T3.lie[so3sc,T3[[All,i]],IdentityMatrix[3][[j]]],{i,3},{j,3}]], #=!=0&]];
info["so(3)", eqSO3, vars3];

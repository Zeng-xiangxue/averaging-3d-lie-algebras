#!/usr/bin/env wolframscript
(* ==================================================================
   _se3_regionZ_global.wl -- decisive completeness check for Region Z,
   A = lam uu^T branch (rotate u -> e1, set lam = 3 WLOG).
   Two exhaustive solves on reduced (but PROVEN-complete) ansatze:

   Solve 1: B = 0        (B=0 block), C free (9), D free (9)   -- 18 unknowns
   Solve 2: B = b e1e1^T (B != 0 block; B!=0 => rank C = 1 => C = e1 psi^T),
            psi free (3), D free (9), b free                     -- 13 unknowns
   ASCII-only source on purpose.
   ================================================================== *)

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
P[u_] := Outer[Times, u, u];
e1 = {1, 0, 0};

Print["=== Solve 1 : A = 3 e1e1^T, B = 0, C, D free (18 unknowns) ==="];
CC1 = Table[c[i, j], {i, 3}, {j, 3}];
DD1 = Table[d[i, j], {i, 3}, {j, 3}];
T1 = ArrayFlatten[{{3 P[e1], Z3}, {CC1, DD1}}];
vars1 = Flatten[{CC1, DD1}];
eqs1 = avgDef[T1];
Print["  equations: ", Length[eqs1], "   unknowns: ", Length[vars1]];
t1 = AbsoluteTiming[sol1 = Solve[eqs1 == 0, vars1];];
Print["  Solve time: ", t1[[1]], " s, branches: ", Length[sol1]];
Do[
  Print["  branch ", k, ":"];
  Print["    C = ", Simplify[CC1 /. sol1[[k]]]];
  Print["    D = ", Simplify[DD1 /. sol1[[k]]]], {k, Length[sol1]}];

Print[""];
Print["=== Solve 2 : A = 3 e1e1^T, B = b e1e1^T, C = e1 psi^T, D free (13 unknowns) ==="];
PSI = {p1, p2, p3};
CC2 = Outer[Times, e1, PSI];
DD2 = Table[dd[i, j], {i, 3}, {j, 3}];
T2 = ArrayFlatten[{{3 P[e1], b P[e1]}, {CC2, DD2}}];
vars2 = Flatten[{PSI, DD2, {b}}];
eqs2 = avgDef[T2];
Print["  equations: ", Length[eqs2], "   unknowns: ", Length[vars2]];
t2 = AbsoluteTiming[sol2 = Solve[eqs2 == 0, vars2];];
Print["  Solve time: ", t2[[1]], " s, branches: ", Length[sol2]];
Do[
  Print["  branch ", k, ":"];
  Print["    psi = ", Simplify[PSI /. sol2[[k]]]];
  Print["    b   = ", Simplify[b /. sol2[[k]]]];
  Print["    D   = ", Simplify[DD2 /. sol2[[k]]]], {k, Length[sol2]}];

Print[""];
Print["Done."];

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
ok[R_] := AllTrue[Flatten[avgDef[R]], (Simplify[#] === 0) &];
TAB[A_, Bb_, Cc_, Dm_] := ArrayFlatten[{{A, Bb}, {Cc, Dm}}];
E1 = {1, 0, 0};
Av = 3 Outer[Times, E1, E1];
Dnew = 3 (e3 - Outer[Times, E1, E1]);
Cnew[p_, q_] := {{0, 0, 0}, {0, p, q}, {0, -q, p}};

Print["=== claimed new family: A = lam e1e1^T, B = 0, D = lam(I-e1e1^T) ==="];
Print["  C = [[0,0,0],[0,c22,c23],[0,-c23,c22]] :"];
Do[Print["    (c22,c23) = ", v, " : ", ok[TAB[Av, Z3, Cnew @@ v, Dnew]]],
  {v, {{0, 0}, {1, 0}, {0, 1}, {1, 2}, {-3, 5}}}];
Print[""];
Print["  negatives:"];
n[nm_, Cc_, Dd_] := Print["    ", nm, " : ", ok[TAB[Av, Z3, Cc, Dd]]];
n["C = diag(1,2,3)          ", DiagonalMatrix[{1, 2, 3}], Dnew];
n["C = e1e1^T               ", Outer[Times, E1, E1], Dnew];
n["C = [[0,0,0],[0,1,0],[0,0,-1]] (sign) ", {{0, 0, 0}, {0, 1, 0}, {0, 0, -1}}, Dnew];
n["D = diag(2,3,3) (a'!=0)  ", Cnew[1, 2], DiagonalMatrix[{2, 3, 3}]];
n["C = 0                    ", Z3, Dnew];
Print["  (C=0 with this D should be True: it is case 3(c))"];
Print[""];
Print["=== cross-check: the candidate-1 family with this D ==="];
Cf[c1_, c2_, c3_] := {{c1, c2, c3}, {3 c2/5, 0, 0}, {3 c3/5, 0, 0}};
n["C from candidate 1 (c11,c12,c13)=(1,1,1)", Cf[1, 1, 1], Dnew];
Print[""];
Print["=== why rank D=2 is possible: im D = e1^perp here ==="];
Print["  for w,h in e1^perp both perpendicular to e1: w x h is parallel to e1,"];
Print["  so (Z-vh-V) only forces D(e1)=0, not rank D <= 1."];
Print["  D = lam(I-e1e1^T) has D(e1)=0 and im D = e1^perp : consistent."];

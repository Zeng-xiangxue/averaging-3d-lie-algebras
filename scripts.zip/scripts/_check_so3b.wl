ClearAll["Global`*"];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
scB = Normal[SparseArray[{{3,1,2}->1, {2,1,3}->-1, {1,2,3}->1}, {3,3,3}]];
scB = scB - Transpose[scB, {1,3,2}];
TB = Array[q,{3,3}];
compB[i_,j_] := lie[scB, TB[[All,i]], TB[[All,j]]] - TB . lie[scB, TB[[All,i]], unit[[j]]];
residB[MT_] := Max[Abs[Flatten[Table[lie[scB, MT[[All,i]], MT[[All,j]]] - MT . lie[scB, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
eqD = Select[DeleteDuplicates[Flatten[Table[compB[i,j], {i,3},{j,3}]] /. {q[1,2]->0, q[1,3]->0, q[2,1]->0, q[2,3]->0, q[3,1]->0, q[3,2]->0}], # =!= 0 &];
Print["diagonal equations: ", Simplify[eqD]];
Print["diagonal solutions: ", Simplify[Solve[eqD == 0, {q[1,1], q[2,2], q[3,3]}, Reals]]];
candsB = {{"0", ConstantArray[0,{3,3}]}, {"Id", unit},
  {"e1 e1^T", {{1,0,0},{0,0,0},{0,0,0}}},
  {"u u^T, u=(1,2,3)", Outer[Times,{1,2,3},{1,2,3}]/14},
  {"diag(1,1,0) rank2 (expect NOT)", {{1,0,0},{0,1,0},{0,0,0}}},
  {"diag(1,0,1) (expect NOT)", {{1,0,0},{0,0,0},{0,0,1}}},
  {"non-symmetric E12 (expect NOT)", {{0,1,0},{0,0,0},{0,0,0}}}};
Do[Print["   ", candsB[[k,1]], "  resid = ", residB[candsB[[k,2]]],
   "  rank = ", MatrixRank[candsB[[k,2]]]], {k, Length[candsB]}];

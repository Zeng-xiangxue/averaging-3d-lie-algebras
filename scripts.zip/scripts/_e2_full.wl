(* e(2) = r(0) : pairwise non-conjugacy of the five classes under the FULL group
   Aut = {(1,w,B) : B = [[a,b],[-b,a]]}  U  {(-1,w,B) : B = [[p,q],[q,-p]]} *)
ClearAll["Global`*"];
e = IdentityMatrix[3];
A0 = {{0,-1},{1,0}};
br[x_,y_] := Join[{0}, x[[1]] A0 . y[[2;;3]] - y[[1]] A0 . x[[2;;3]]];
res[T_] := Max[Abs[Flatten[Table[br[T.e[[i]],T.e[[j]]] - T.br[T.e[[i]],e[[j]]],{i,3},{j,3}]]]];
phi1 = {{1,0,0},{w1,a,b},{w2,-b,a}};              (* identity component *)
phi2 = {{-1,0,0},{w1,p,q},{w2,q,-p}};             (* mirror component   *)
conjOne[ph_, sat_, vars_, T1_, T2_] := Module[{eqs,gb},
  eqs = Numerator /@ Together /@ Flatten[ph . T1 . Inverse[ph] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z sat}], Append[vars, z], MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
conjFull[T1_,T2_] := conjOne[phi1, a^2+b^2, {a,b,w1,w2}, T1, T2] || conjOne[phi2, p^2+q^2, {p,q,w1,w2}, T1, T2];
five = {{"0", {{0,0,0},{0,0,0},{0,0,0}}},
        {"e2e1'", {{0,0,0},{1,0,0},{0,0,0}}},
        {"e3e1'", {{0,0,0},{0,0,0},{1,0,0}}},
        {"a Id", 2 IdentityMatrix[3]},
        {"a e1e1'", {{2,0,0},{0,0,0},{0,0,0}}},
        {"lam e2e2'", {{0,0,0},{0,1,0},{0,0,0}}}};
Print["residuals: ", Table[res[five[[k,2]]], {k,6}]];
Print["checks (expected):"];
Print["   e2e1' ~ e3e1' (mirror merges them) ? ", conjFull[five[[2,2]], five[[3,2]]], "  (expect True)"];
Print["   lam e2e2' ~ lam e3e3' ? ", conjFull[five[[6,2]], {{0,0,0},{0,0,0},{0,0,1}}], "  (expect True)"];
Print["   full C(5,2) test on {0, e2e1', a Id, a e1e1', lam e2e2'} :"];
sel = {1,2,4,5,6}; bad = 0;
Do[If[i<j, Module[{qq = conjFull[five[[sel[[i]],2]], five[[sel[[j]],2]]]},
   If[qq, bad++]; Print["      ", five[[sel[[i]],1]], " ~ ", five[[sel[[j]],1]], " ? ", qq]]], {i,5}, {j,5}];
Print["   conjugacies found among the five : ", bad, "   (0 required)"];

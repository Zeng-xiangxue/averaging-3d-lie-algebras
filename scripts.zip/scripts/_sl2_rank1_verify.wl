(* rank-1 family verification:
   1) T = v (K v)^T is a solution for all v  (symbolic resid = 0)
   2) ad_v^T = -K ad_v K^{-1};  ker ad_v = R v;  ker ad_v^T = R (K v)
   3) canonical reps (spacelike/timelike/null, +/-) are solutions
   4) K-types and traces of the reps; disjointness invariants *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
K = {{0,0,4},{0,2,0},{4,0,0}};
vv = {v1,v2,v3};
admat[x_] := Table[Sum[x[[k]] sc[[i,k,j]], {k,3}], {i,3}, {j,3}];

Print["== 1. T = v (Kv)^T is a solution (symbolic) =="];
Tv = KroneckerProduct[vv, K . vv];
resv = Simplify[Flatten[Table[
  lie[sc, Tv[[All,i]], Tv[[All,j]]] - Tv . lie[sc, Tv[[All,i]], unit[[j]]], {i,3}, {j,3}]]];
Print["  resid all zero? ", Union[Simplify[resv]] === {0}];

Print["== 2. ad_v^T = -K ad_v K^-1 =="];
diff = Simplify[Transpose[admat[vv]] + K . admat[vv] . Inverse[K]];
Print["  diff == 0? ", Union[Flatten[diff]] === {0}];

Print["== 3. ker ad_v = R v =="];
nv = NullSpace[admat[vv]];
Print["  NullSpace length = ", Length[nv], ";  spans v? ", Simplify[nv[[1]] - vv] === {0,0,0}];

Print["== 4. ker ad_v^T = R (Kv) =="];
Print["  ad_v^T(Kv) = ", Simplify[Transpose[admat[vv]] . (K . vv)], "  (should be {0,0,0})"];
Print["  ad_v(Kv)  = ", Simplify[admat[vv] . (K . vv)], "  (nonzero in general - the transpose trap)"];

Print["== 5. canonical reps are solutions =="];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
reps = {KroneckerProduct[{0,1,0},{0,1,0}],                       (* e2 e2^T, spacelike *)
        KroneckerProduct[{1,0,-1},{1,0,-1}],                     (* (e1-e3)(e1-e3)^T, timelike *)
        KroneckerProduct[{1,0,0},{0,0,1}],                       (* e1 e3^T, null + *)
        KroneckerProduct[-{1,0,0},{0,0,1}]};                     (* -e1 e3^T, null - *)
names = {"e2 e2^T (spacelike)", "(e1-e3)(e1-e3)^T (timelike)", "+e1 e3^T (null)", "-e1 e3^T (null)"};
Do[Print["  ", names[[k]], ": resid = ", resid[reps[[k]]], ",  tr = ", Tr[reps[[k]]],
   ",  K-type of v: ", K[[2,2]]], {k, 4}];

Print["== 6. K(v,v) of the three direction types =="];
Print["  K(e2,e2) = ", {0,1,0} . K . {0,1,0}, "  (>0 spacelike)"];
Print["  K(e1-e3,e1-e3) = ", {1,0,-1} . K . {1,0,-1}, "  (<0 timelike)"];
Print["  K(e1,e1) = ", {1,0,0} . K . {1,0,0}, "  (=0 null)"];
Print["  trace invariants: tr(v(Kv)^T) = K(v,v)  =>  spacelike tr>0, timelike tr<0, null tr=0"];
Print["  null leaf: SO(K)^o preserves the two null leaves, so +e1e3^T and -e1e3^T are NOT conjugate"];

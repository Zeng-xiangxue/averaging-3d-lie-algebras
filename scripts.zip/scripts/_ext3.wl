(* verify the derived solution sets and candidate normal forms for the three algebras *)
e1 = {1,0,0}; e2 = {0,1,0}; e3 = {0,0,1};

mkBracket[A_] := Function[{x, y}, Join[{0}, x[[1]] A.y[[2 ;; 3]] - y[[1]] A.x[[2 ;; 3]]]];

resid[A_, T_] := Module[{br = mkBracket[A], r},
  r = Flatten[Table[
     br[T.ei, T.ej] - T.br[T.ei, ej] /. {ei -> {e1,e2,e3}[[i]], ej -> {e1,e2,e3}[[j]]},
     {i,3}, {j,3}]];
  Max[Abs[Flatten[r]]]
  ];

(* ---- (5) A = J = [[1,1],[0,1]] ---- *)
AJ = {{1,1},{0,1}};
cands5 = {
  {{0,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{0,0,0}},
  {{0,0,0},{0,0,0},{1,0,0}},
  {{a,0,0},{0,a,0},{0,0,a}},
  {{a,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{0,c,0},{0,-c,0}},
  {{0,0,0},{0,0,c},{0,0,0}}
  };
Print["=== (5) A = J : residuals of candidate normal forms ==="];
Do[Print[MatrixForm[T], " -> residual = ", resid[AJ, T]], {T, cands5}];
Print[""];

(* ---- (6) A = C_c = [[c,-1],[1,c]] ---- *)
Print["=== (6) A = C_c : residuals (c = 0 and c = 2) ==="];
Do[
  AC = {{cc,-1},{1,cc}};
  cands6 = {
    {{0,0,0},{0,0,0},{0,0,0}},
    {{0,0,0},{1,0,0},{0,0,0}},
    {{a,0,0},{0,a,0},{0,0,a}},
    {{a,0,0},{0,0,0},{0,0,0}},
    {{0,0,0},{-cc*k,0,0},{k,0,0}}
    };
  Print["--- c = ", cc, " ---"];
  Do[Print[MatrixForm[T], " -> residual = ", Simplify[resid[AC, T]]], {T, cands6}];
  ,
  {cc, {0, 2}}
  ];

(* ============================================================
   r3,lambda (lam = 2 representative): the a = 0 branch.
   E1: a(D ad - ad D) = 0,  E2: D ad gamma = 0,  E3: D ad D = a ad D.
   Checks: (1) e2 e3^T and e3 e2^T are both solutions; e2 e2^T is not;
           (2) the D_t family D = {{-lam t, u},{v,t}}, uv = -lam t^2;
           (3) diag-Aut action on D; (4) gamma lies in im D (killed by v);
           (5) the a = 0 class list and its pairwise inequivalence.
   ============================================================ *)
ClearAll["Global`*"];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
mkCF[lv_] := Normal[SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->lv, {3,3,1}->-lv}, {3,3,3}]];
unit = IdentityMatrix[3];
cf2 = mkCF[2];
resid2[MT_] := Max[Abs[Flatten[Table[
   lie[cf2, MT[[All,i]], MT[[All,j]]] - MT . lie[cf2, MT[[All,i]], unit[[j]]],
   {i,3},{j,3}]]]];

Print["== 1. the disputed examples at lam = 2 =="];
ex = {
  {"e2 e3^T  (T(e2)=e3)", {{0,0,0},{0,0,0},{0,1,0}}},
  {"e3 e2^T  (T(e3)=e2)", {{0,0,0},{0,0,1},{0,0,0}}},
  {"e2 e2^T  (my mis-typed matrix)", {{0,0,0},{0,1,0},{0,0,0}}},
  {"0", {{0,0,0},{0,0,0},{0,0,0}}}
};
Do[Print["   ", ex[[k,1]], "   resid = ", resid2[ex[[k,2]]]], {k, Length[ex]}];

Print[""];
Print["== 2. D ad D = 0 : parametrisation and diag-Aut action =="];
ad = {{1,0},{0,la}};
Dm = {{d11, u},{v, d22}};
eqD = Simplify[Flatten[Dm . ad . Dm]];
Print["   D ad D = 0 gives: ", eqD];
solD = Solve[eqD == 0, {d11, d22, u, v}];
Print["   Solve: ", Simplify[solD]];
Print["   check D = {{-lam t, u},{v,t}} with uv = -lam t^2 satisfies E3: ",
  Simplify[Flatten[{{-la t, u},{v, t}} . ad . {{-la t, u},{v, t}}] /. {u v -> -la t^2}]];
Print["   diag-Aut action on D (B = diag(b,c)): ",
  Simplify[{{b,0},{0,c}} . {{d11,u},{v,d22}} . Inverse[{{b,0},{0,c}}]]];

Print[""];
Print["== 3. for the a = 0 solutions: gamma in ker(D ad) and im D =="];
Do[
  t0 = k; u0 = 1; v0 = -2 t0^2;   (* lam = 2 *)
  D0 = {{-2 t0, u0}, {v0, t0}};
  print1 = D0 . ad . D0;
  kerD = NullSpace[D0 . ad];                 (* gamma with (D ad) gamma = 0 *)
  imD = Transpose[{D0[[All,1]], D0[[All,2]]}];
  Print["   t=", t0, "  D = ", D0, "  D ad D = ", Flatten[print1],
        "   ker(D ad) = ", kerD, "   rank D = ", MatrixRank[D0]],
  {k, {0, 1, 2}}];

Print[""];
Print["== 3b. is the extra gamma killed?  e2e3^T + gamma e1^T with gamma in ker(D ad) =="];
extra = {
  {"e2 e3^T  (T(e3)=e2, D={{0,1},{0,0}})", {{0,0,0},{0,0,1},{0,0,0}}},
  {"e2 e3^T + gamma=(1,0)", {{0,0,0},{1,0,1},{0,0,0}}},
  {"e3 e2^T  (T(e2)=e3, D={{0,0},{1,0}})", {{0,0,0},{0,0,0},{0,1,0}}},
  {"e3 e2^T + gamma=(0,1)", {{0,0,0},{0,0,0},{1,1,0}}}
};
Do[Print["   ", extra[[k,1]], "   resid = ", resid2[extra[[k,2]]]], {k, Length[extra]}];
Print["   conjugated?  e2e3^T+gamma  ~  e2e3^T : ",
  Not[noConjD[extra[[2,2]], extra[[1,2]]]],
  "     e3e2^T+gamma ~ e3e2^T : ", Not[noConjD[extra[[4,2]], extra[[3,2]]]]];

Print[""];
Print["== 4. a = 0 candidates at lam = 2 : residuals =="];
cands = {
  {"0", {{0,0,0},{0,0,0},{0,0,0}}},
  {"e2 e1^T", {{0,0,0},{1,0,0},{0,0,0}}},
  {"e3 e1^T", {{0,0,0},{0,0,0},{1,0,0}}},
  {"(e2+e3)e1^T", {{0,0,0},{1,0,0},{1,0,0}}},
  {"e2 e3^T", {{0,0,0},{0,0,0},{0,1,0}}},
  {"e3 e2^T", {{0,0,0},{0,0,1},{0,0,0}}},
  {"D_t (t=1): D={{-2,1},{-2,1}}", {{0,0,0},{0,-2,1},{0,-2,1}}},
  {"D_t (t=2): D={{-4,1},{-8,2}}", {{0,0,0},{0,-4,1},{0,-8,2}}}
};
Do[Print["   ", cands[[k,1]], "   resid = ", resid2[cands[[k,2]]]], {k, Length[cands]}];

Print[""];
Print["== 5. pairwise inequivalence under the diagonal Aut =="];
Bd = {{b,0},{0,c}}; vv = {v1,v2};
phiD = {{1,0,0},{vv[[1]], Bd[[1,1]], Bd[[1,2]]},{vv[[2]], Bd[[2,1]], Bd[[2,2]]}};
noConjD[Ti_, Tj_] := Module[{sys, gb},
  sys = Flatten[phiD . Ti - Tj . phiD];
  gb = DeleteCases[GroebnerBasis[Join[sys, {b c ss - 1}],
        {b, c, v1, v2, ss}, MonomialOrder -> DegreeReverseLexicographic], 0];
  gb === {1}];
Do[If[i < j,
   Print["   ", cands[[i,1]], "  vs  ", cands[[j,1]], "   inequivalent: ",
     noConjD[cands[[i,2]], cands[[j,2]]]]],
  {i, Length[cands]}, {j, Length[cands]}];
Print["   control same class: ", noConjD[cands[[5,2]], cands[[5,2]]]];

Print[""];
Print["== 6. under the FULL GL(2) (i.e. lam = 1, r3) e2e3^T ~ e3e2^T =="];
SwapM = {{0,1},{1,0}};
Print["   swap conjugates e2e3^T to: ",
  SwapM . {{0,1},{0,0}} . Inverse[SwapM]];

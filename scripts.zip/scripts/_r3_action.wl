(* r3: block form g = R e1 (+) n, n = [g,g] = span(e2,e3) canonical.
   Aut(r3) = { phi = [[1,0],[v,B]] : v in n, B in GL(2) }.
   T = [[a, beta^T],[gamma, D]].  Conjugation law (to verify):
     a'    = a - beta^T B^-1 v
     beta' = B^-1^T beta   (i.e. beta'^T = beta^T B^-1)
     D'    = B D B^-1 + v beta'^T
     gamma'= v a + B gamma - v a' - B D B^-1 v
   ============================================================ *)
ClearAll["Global`*"];
B = {{b11,b12},{b21,b22}}; Bi = Inverse[B];
v = {v1,v2}; a = aa; beta = {bt1,bt2}; gam = {g1,g2}; Dm = {{d11,d12},{d21,d22}};
T = {{a, beta[[1]], beta[[2]]}, {gam[[1]], Dm[[1,1]], Dm[[1,2]]}, {gam[[2]], Dm[[2,1]], Dm[[2,2]]}};
phi = {{1,0,0},{v[[1]],B[[1,1]],B[[1,2]]},{v[[2]],B[[2,1]],B[[2,2]]}};
Tp = Simplify[phi . T . Inverse[phi]];
ap = Tp[[1,1]]; betap = {Tp[[1,2]], Tp[[1,3]]};
gamp = {Tp[[2,1]], Tp[[3,1]]}; Dp = Tp[[2;;3,2;;3]];
predA = Simplify[a - beta . Bi . v];
predB = Simplify[Transpose[Bi] . beta];
predD = Simplify[B . Dm . Bi + Outer[Times, v, predB]];
predG = Simplify[B . gam - B . Dm . Bi . v + v predA];
Print["a'  matches : ", Simplify[ap - predA] == 0];
Print["beta' matches : ", Simplify[betap - predB] == {0,0}];
Print["D'  matches : ", Simplify[Dp - predD] == {{0,0},{0,0}}];
Print["gamma' matches : ", Simplify[gamp - predG] == {0,0}];
Print[""];
Print["== consequences =="];
Print["  beta = 0  =>  a' = a (a is invariant)  : ",
   Simplify[(a - beta . Bi . v) /. Thread[beta -> {0,0}]] == a];
Print["  beta != 0  =>  choose v with beta^T B^-1 v = a  =>  a' = 0"];
(* numeric illustration *)
Do[
  bv = RandomReal[{-2,2},{2,2}] + 3 IdentityMatrix[2];
  bta = RandomReal[{-2,2},2]; ga = RandomReal[{-2,2},2]; Dd = RandomReal[{-2,2},{2,2}];
  av = RandomReal[{-2,2}];
  vv = RandomReal[{-2,2},2];
  Bi2 = Inverse[bv];
  T2 = {{av, bta[[1]], bta[[2]]}, {ga[[1]], Dd[[1,1]], Dd[[1,2]]}, {ga[[2]], Dd[[2,1]], Dd[[2,2]]}};
  ph2 = {{1,0,0},{vv[[1]], bv[[1,1]], bv[[1,2]]},{vv[[2]], bv[[2,1]], bv[[2,2]]}};
  T2p = ph2 . T2 . Inverse[ph2];
  Print["  sample: a=", Round[av,0.01], " -> a'=", Round[T2p[[1,1]],0.01],
        "  predicted ", Round[av - bta . Bi2 . vv, 0.01],
        "  same? ", Abs[T2p[[1,1]] - (av - bta . Bi2 . vv)] < 10^-10],
  {3}];
(* kill a when beta != 0 *)
av = 2.0; bta = {1.0, 0.5}; bv = IdentityMatrix[2]; vv = {av, 0.0};
Print["  kill test: a=2, beta=(1,0.5), B=I, v=(2,0) -> a' = ",
  Round[2 - bta . Inverse[bv] . vv, 10^-12]];

ClearAll["Global`*"];
M = {{m11, m12}, {m21, m22}}; Bh = {{b11, b12}, {b21, b22}}; xv = {x1, x2};
Mp = Bh . M . Inverse[Bh];
mu = (aa IdentityMatrix[2] - M) . xv;
wstar = Bh . xv;
Print["(aI - M') w* = B mu ? ",
  Simplify[(aa IdentityMatrix[2] - Mp) . wstar - Bh . mu] === {0, 0}];
Print["w* = B^{-1}(...) ; gamma' = B gamma + (aI - M') w* equals B gamma + B mu ? ",
  Simplify[((aa IdentityMatrix[2] - Mp) . wstar) - (Bh . mu)] === {0, 0}];

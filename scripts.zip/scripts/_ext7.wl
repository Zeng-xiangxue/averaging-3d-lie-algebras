(* pairwise non-conjugacy check for the three new algebras (unit ideal, generic parameters) *)

(*(* phi = {{1,0,0},{w1,B11,B12},{w2,B21,B22}}, B in centralizer of A *)*)
mkPhi[B_] := {{1, 0, 0}, {w1, B[[1,1]], B[[1,2]]}, {w2, B[[2,1]], B[[2,2]]}};

notConj[T1_, T2_, B_, vars_] := Module[{phi, eqs, gb},
  phi = mkPhi[B];
  eqs = Flatten[phi.T1.Inverse[phi] - T2];
  eqs = Together /@ eqs;
  eqs = Numerator /@ eqs;
  gb = GroebnerBasis[Join[eqs, {1 - z*Det[B]}], Join[vars, {z}],
        MonomialOrder -> DegreeReverseLexicographic];
  gb === {1}
  ];

(* ---------- r(1,0): A = diag(1,0), B = diag(p,s) ---------- *)
forms10 = {
  {{0,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{0,0,0},{1,0,0}},
  {{0,0,0},{1,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{1,0,0}},
  {{0,0,0},{0,0,1},{0,0,2}},
  {{0,0,0},{0,0,0},{0,1,2}},
  {{0,0,0},{0,0,1},{1,0,2}},
  {{1,0,0},{0,1,0},{0,0,1}},
  {{1,0,0},{0,1,0},{1,0,1}},
  {{1,0,0},{0,0,0},{0,0,0}},
  {{1,0,0},{0,0,0},{1,0,0}},
  {{1,0,0},{0,0,0},{0,0,2}},
  {{1,0,0},{0,1,0},{0,0,2}}
  };
B10 = {{p, 0}, {0, s}};
bad10 = {};
Do[If[! notConj[forms10[[i]], forms10[[j]], B10, {p, s, w1, w2}],
    AppendTo[bad10, {i, j}]],
  {i, 1, Length[forms10]}, {j, i + 1, Length[forms10]}];
Print["r(1,0): pairs that are NOT separated = ", bad10];

(* ---------- r(J): A = {{1,1},{0,1}}, B = {{p,q},{0,p}} ---------- *)
formsJ = {
  {{0,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{0,0,0}},
  {{0,0,0},{0,0,0},{1,0,0}},
  {{1,0,0},{0,1,0},{0,0,1}},
  {{1,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{0,1,0},{0,-1,0}},
  {{0,0,0},{0,0,1},{0,0,0}}
  };
BJ = {{p, q}, {0, p}};
badJ = {};
Do[If[! notConj[formsJ[[i]], formsJ[[j]], BJ, {p, q, w1, w2}],
    AppendTo[badJ, {i, j}]],
  {i, 1, Length[formsJ]}, {j, i + 1, Length[formsJ]}];
Print["r(J): pairs that are NOT separated = ", badJ];

(* ---------- r(c): A = {{c,-1},{1,c}} with c = 1, B = p{{1,-t},{t,1}} ---------- *)
Ac = 1;
Bc = {{p, -p*t}, {p*t, p}};
formsC = {
  {{0,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{0,0,0}},
  {{1,0,0},{0,1,0},{0,0,1}},
  {{1,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{-Ac,0,0},{1,0,0}}
  };
badC = {};
Do[If[! notConj[formsC[[i]], formsC[[j]], Bc, {p, t, w1, w2}],
    AppendTo[badC, {i, j}]],
  {i, 1, Length[formsC]}, {j, i + 1, Length[formsC]}];
Print["r(c): pairs that are NOT separated = ", badC];

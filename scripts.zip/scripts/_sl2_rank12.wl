(* sl2 rank-1 family: direct verification
   1) random v, w in ker(ad_v^T) (1-dim) -> T = v w^T has resid 0
   2) random v, generic w -> resid != 0
   3) End_g(g) = R Id: Solve commutation equations explicitly *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
admat[a_] := Table[lie[sc, a, unit[[j]]], {j, 3}];

Print["== 1. rank-1 family: w in ker(ad_v^T) -> solution =="];
Do[
  vv = RandomReal[{-2,2}, {3}];
  kerw = NullSpace[Transpose[admat[vv]]][[1]];
  TT1 = KroneckerProduct[vv, kerw];
  Print["  v=", Round[vv, 0.01], "  w=", Round[kerw, 0.01], "  resid=", resid[TT1], "  tr=", Tr[TT1]],
  {4}];

Print["== 2. rank-1 with generic w -> NOT solution =="];
cnt = 0;
Do[
  vv = RandomReal[{-2,2}, {3}];
  ww = RandomReal[{-2,2}, {3}];
  TT2 = KroneckerProduct[vv, ww];
  If[resid[TT2] < 10^-9, cnt++],
  {20}];
Print["  generic w solutions found: ", cnt, " (expect 0, ker is 1-dim so prob ~0)"];

Print["== 3. End_g(g) = R Id: explicit solve =="];
vars = Flatten[Table[m[i,j], {i,3}, {j,3}]];
MM = Table[m[i,j], {i,3}, {j,3}];
eqs = Flatten[Table[MM . admat[unit[[j]]] - admat[unit[[j]]] . MM, {j,3}]];
sol = Solve[Thread[eqs == 0], vars][[1]];
Print["  solutions: ", sol];
Print["  -> MM = ", Simplify[MM /. sol] // MatrixForm, "  (scalar lambda Id, lambda free)"];

Print["== 4. rank-2 existence probe (structured candidates) =="];
cands = {
  {{1,0,0},{0,0,0},{0,0,0}},          (* rank 1 *)
  {{0,0,0},{0,1,0},{0,0,1}},          (* rank 2 *)
  {{0,0,1},{0,0,0},{0,0,0}},          (* e1 e3^T rank 1 *)
  {{0,0,0},{0,0,1},{0,0,0}},          (* e2 e3^T rank 1 *)
  {{0,0,0},{0,0,0},{0,1,0}},          (* e3 e2^T rank 1 *)
  {{1,0,0},{0,1,0},{0,0,0}}};         (* rank 2 diag *)
Do[Print["  cand ", k, " resid = ", resid[cands[[k]]], "  rank = ", MatrixRank[cands[[k]]]], {k, Length[cands]}];

Print["== 5. does a rank-2 solution exist? generic rank-2 ansatz + Solve =="];
(* rank-2 ansatz: T = u w1^T + z w2^T with u,z independent; too generic.
   Instead: fix u = e1, z = e2, w1,w2 free -> generic T with first two columns spanning *)
w1 = {a, b, c}; w2 = {p, q, r};
T3 = Transpose[{w1, w2, {0,0,0}}];
eqs3 = Flatten[Table[
  lie[sc, T3.unit[[i]], T3.unit[[j]]] - T3 . lie[sc, T3.unit[[i]], unit[[j]]], {i,3},{j,3}]];
sol3 = Solve[Thread[eqs3 == 0], {a,b,c,p,q,r}];
Print["  #branches = ", Length[sol3]];
Do[Print["    branch ", k, ": ", sol3[[k]]], {k, Length[sol3]}];

(* Re-examine the a = 0 branches of r(J) and r(c)  *)
ClearAll["Global`*"];
e3 = IdentityMatrix[3];

(* ---------- r(J) :  [e1,e2]=e2, [e1,e3]=e2+e3 ,  A = J ---------- *)
AJ = {{1, 1}, {0, 1}};
brJ[x_, y_] := Join[{0}, x[[1]] AJ . y[[2 ;; 3]] - y[[1]] AJ . x[[2 ;; 3]]];
resJ[T_] := Max[Abs[Flatten[Table[brJ[T.e3[[i]], T.e3[[j]]] - T.brJ[T.e3[[i]], e3[[j]]], {i,3},{j,3}]]]];
(* candidate from u = e3 :  M = e3 (e2-e3)^T , gamma = 0 *)
MJ = {{0, 0, 0}, {0, 0, 0}, {0, 1, -1}};
Print["r(J): residual of [[0,0,0],[0,0,0],[0,1,-1]] = ", resJ[MJ]];

phiJ = {{1, 0, 0}, {w1, p, qJ}, {w2, 0, p}};
conjQJ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phiJ . T1 . Inverse[phiJ] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p}], {p, qJ, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
targJ = {{"0", {{0,0,0},{0,0,0},{0,0,0}}},
         {"e2e1'", {{0,0,0},{1,0,0},{0,0,0}}},
         {"e3e1'", {{0,0,0},{0,0,0},{1,0,0}}},
         {"2 Id", 2 IdentityMatrix[3]},
         {"2 e1e1'", {{2,0,0},{0,0,0},{0,0,0}}},
         {"-(e2-e3)e2'", {{0,0,0},{-1,0,0},{1,0,0}}},
         {"e2e3'", {{0,0,0},{0,0,1},{0,0,0}}}};
Do[Print["   r(J): MJ ~ ", targJ[[k,1]], " ? ", conjQJ[MJ, targJ[[k,2]]]], {k, Length[targJ]}];

(* ---------- r(c) :  A = C_c ,  family  M = lam {{-1,c},{0,0}} ---------- *)
brC[x_, y_, cc_] := Join[{0}, x[[1]] {{cc,-1},{1,cc}} . y[[2 ;; 3]] - y[[1]] {{cc,-1},{1,cc}} . x[[2 ;; 3]]];
resC[T_, cc_] := Max[Abs[Flatten[Table[brC[T.e3[[i]], T.e3[[j]], cc] - T.brC[T.e3[[i]], e3[[j]], cc], {i,3},{j,3}]]]];
Tc[lam_, cc_] := {{0,0,0}, {0, -lam, cc lam}, {0,0,0}};
Print["r(c=1): residual of lam=1 member = ", resC[Tc[1,1], 1]];
Print["r(c=2): residual of lam=3 member = ", resC[Tc[3,2], 2]];
Print["symbolic c, lam : ", Simplify[resC[Tc[lam, cc], cc]]];
phiC = {{1,0,0},{w1, p, -p tC},{w2, p tC, p}};
conjQC[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phiC . T1 . Inverse[phiC] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p}], {p, tC, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
Print["r(c=1): lam=1 ~ lam=2 ? ", conjQC[Tc[1,1], Tc[2,1]]];
Print["r(c=1): lam=1 ~ lam=-1 ? ", conjQC[Tc[1,1], Tc[-1,1]]];
targC = {{"0", {{0,0,0},{0,0,0},{0,0,0}}},
         {"e2e1'", {{0,0,0},{1,0,0},{0,0,0}}},
         {"2 Id", 2 IdentityMatrix[3]},
         {"2 e1e1'", {{2,0,0},{0,0,0},{0,0,0}}}};
Do[Print["   r(c=1): lam=1 ~ ", targC[[k,1]], " ? ", conjQC[Tc[1,1], targC[[k,2]]]], {k, Length[targC]}];

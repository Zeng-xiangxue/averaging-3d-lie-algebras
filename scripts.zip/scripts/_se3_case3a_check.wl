(* Case 3a: B=C=0, T = [[A,0],[0,D]]. Predicted classification:
   (i)  D=0, A in {0, diag(lam,0,0), lam Id}          (Case 0)
   (ii) A=0, D in {0} u {mu l l^T}                    (Case 1 subclass)
   (iii) A = lam Id (lam != 0), D = lam I   <-- lambda Id_6 lives here! *)
ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
blk[A_, B_, Cc_, Dm_] := ArrayFlatten[{{A, B}, {Cc, Dm}}];
avgRes[R_] := Max[Abs[Flatten[Table[
     br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]]]];
ok[R_] := avgRes[R] < 10.^-10;
E1 = {1, 0, 0}; l = {2, -3, 5}; lv = l/Norm[l];

Print["=== predicted classification of B=C=0, T = [[A,0],[0,D]] ==="];
Print["  (i)  D = 0, A in Case 0  (three classes)        -> falls back"];
Print["  (ii) A = 0, D in {0} u {mu l l^T}               -> Case 1 subclass"];
Print["  (iii) A = lam Id (lam!=0), D = lam I            -> lambda Id_6  NEW"];
Print["  (A = diag(lam,0,0), D != 0): NO solutions (D must vanish)"];

Print["=== positives (all True) ==="];
pchk[n_, A_, D_] := Print["  ", n, " : ", ok[blk[A, Z3, Z3, D]]];
pchk["(lam Id, lam I) = lam Id_6        ", lam e3, lam e3];
pchk["(lam Id, D = 0)                   ", lam e3, Z3];
pchk["(diag(lam,0,0), D = 0)            ", lam DiagonalMatrix[E1], Z3];
pchk["(0, mu l l^T)                     ", Z3, 3 Outer[Times, lv, lv]];
pchk["(0, 0) = T=0                      ", Z3, Z3];

Print["=== negatives (all False) ==="];
nchk[n_, A_, D_] := Print["  ", n, " : ", ok[blk[A, Z3, Z3, D]]];
nchk["(diag(2,0,0), D = 2I)             ", 2 DiagonalMatrix[E1], 2 e3];
nchk["(diag(2,0,0), D = l l^T)          ", 2 DiagonalMatrix[E1], Outer[Times, lv, lv]];
nchk["(diag(2,0,0), D = diag(2,3,0))    ", 2 DiagonalMatrix[E1], DiagonalMatrix[{2, 3, 0}]];
nchk["(2 Id, D = 3 I)  mu != lam        ", 2 e3, 3 e3];
nchk["(2 Id, D = l l^T)                 ", 2 e3, Outer[Times, lv, lv]];
nchk["(2 Id, D = skew)                  ", 2 e3, {{0, -3, 2}, {3, 0, -1}, {-2, 1, 0}}];
nchk["(0, D = 3 I)                      ", Z3, 3 e3];
nchk["(0, D = diag(1,2,3))              ", Z3, DiagonalMatrix[{1, 2, 3}]];
nchk["(0, D = diag(1,1,0))              ", Z3, DiagonalMatrix[{1, 1, 0}]];

Print["=== random search: A in {0, diag, lam Id} x random Dm ==="];
SeedRandom[7];
cnt = 0; bad = 0;
Do[
  Atype = RandomInteger[{1, 3}];
  A = Switch[Atype, 1, Z3, 2, 2 DiagonalMatrix[E1], 3, 2 e3];
  Dm = Partition[RandomReal[{-1, 1}, 9], 3];
  If[ok[blk[A, Z3, Z3, Dm]], cnt++], {2000}];
Print["  averaging solutions found among 2000 random D (A fixed as above): ",
  cnt, "   (expect only D near 0 or near lam*I for A = 2 I)"];
Print["Done."];

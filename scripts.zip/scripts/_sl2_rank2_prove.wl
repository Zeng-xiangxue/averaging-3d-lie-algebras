(* rank-2 exclusion, machine proof via Rabinowitsch:
   for each ker type (Aut=SO(K)^o is transitive on null/spacelike/timelike lines),
   every 2x2 minor vanishes on the solution set  <=>  eqs + (minor*s - 1) has GB = {1} *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
TT = Table[t[i,j], {i,3}, {j,3}];
vars = Flatten[TT];
eqsAll = DeleteCases[Flatten[Table[
  lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]], 0];
minors = {t[1,1] t[2,2] - t[1,2] t[2,1], t[1,1] t[2,3] - t[1,3] t[2,1], t[1,2] t[2,3] - t[1,3] t[2,2],
          t[1,1] t[3,2] - t[1,2] t[3,1], t[1,1] t[3,3] - t[1,3] t[3,1], t[1,2] t[3,3] - t[1,3] t[3,2],
          t[2,1] t[3,2] - t[2,2] t[3,1], t[2,1] t[3,3] - t[2,3] t[3,1], t[2,2] t[3,3] - t[2,3] t[3,2]};

Prove[params_, name_] := Module[{eqs, msub, gb, zeroideal},
  eqs = eqsAll /. params;
  msub = minors /. params;
  allok = True;
  Do[
    gb = GroebnerBasis[Join[eqs, {msub[[m]] s - 1}], Join[{s}, vars], MonomialOrder -> Lexicographic];
    zeroideal = (Length[gb] == 1 && Variables[gb[[1]]] === {});
    Print["  ", name, ": minor ", m, " in sqrt(I) (Rabinowitsch {1})? ", zeroideal];
    If[!zeroideal, allok = False],
    {m, 9}];  Print["  ", name, ": ALL 9 minors vanish on solution set  =>  rank <= 1 there: ", allok]];

Print["== Type 1: null kernel ker=span(e1), col1=0 =="];
Prove[{t[1,1]->0, t[2,1]->0, t[3,1]->0}, "null"];

Print["== Type 2: spacelike kernel ker=span(e2), col2=0 =="];
Prove[{t[1,2]->0, t[2,2]->0, t[3,2]->0}, "spacelike"];

Print["== Type 3: timelike kernel ker=span(e1-e3), col3=col1 =="];
Prove[{t[1,1]->t[1,3], t[2,1]->t[2,3], t[3,1]->t[3,3]}, "timelike"];

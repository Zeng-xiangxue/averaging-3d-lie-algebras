(* Subalgebra spectrum of se(3) -- fixed version *)
ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
basis = IdentityMatrix[6];
e = basis[[1 ;; 3]]; f = basis[[4 ;; 6]];

inSpan[w_, gens_] := Norm[w - gens . LinearSolve[Transpose[gens] . gens, Transpose[gens] . w]] < 10.^-8;
closed[gens_] := AllTrue[
  Flatten[Table[br[gens[[i]], gens[[j]]], {i, Length[gens]}, {j, Length[gens]}], 1],
  inSpan[#, gens] &];

Print["V = span(f1,f2,f3) is a subalgebra (3-dim, abelian): ", closed[{f[[1]], f[[2]], f[[3]]}]];
Print["h = span(e1,e2,e3) is a subalgebra (3-dim, so(3)): ", closed[{e[[1]], e[[2]], e[[3]]}]];
Print["mixed 3-dim span(e1,f2,f3): ", closed[{e[[1]], f[[2]], f[[3]]}],
  "   [e1,f2]=f3, [e1,f3]=-f2, [f2,f3]=0  -> se(2)-type, neither h nor V"];
Print["another mixed 3-dim span(e1, f1, f2): ", closed[{e[[1]], f[[1]], f[[2]]}],
  "  (abelian-ish, since [e1,f1]=0, [e1,f2]=f3 escapes) -> expect False"];
Print["4-dim V (+) span(e1): ", closed[{e[[1]], f[[1]], f[[2]], f[[3]]}]];
Print["4-dim V (+) span(e1): bracket check [e1,f2]=", br[e[[1]], f[[2]]],
  " inside V (last 3 coords nonzero) -> subalgebra"];
Print["candidate 5-dim h (+) span(f1,f2): ", closed[{e[[1]], e[[2]], e[[3]], f[[1]], f[[2]]}],
  "   ([e1,f2]=f3 escapes) -> expect False"];
Print["candidate 5-dim V (+) span(e1,e2): ", closed[{e[[1]], e[[2]], f[[1]], f[[2]], f[[3]]}],
  "   ([e1,e2]=e3 escapes) -> expect False"];
Print["candidate 5-dim span(e1, f1, f2, f3) + (e2 + f1): ", 
  closed[{e[[1]], e[[2]] + f[[1]], f[[1]], f[[2]], f[[3]]}],
  "  (generic mixed) -> expect False"];
Print["full se(3) is a subalgebra (6-dim): ", closed[basis]];
Print["1-dim: every nonzero vector spans a subalgebra (abelian): ",
  And @@ Table[closed[{basis[[k]]}], {k, 6}]];
Print["2-dim abelian span(e1, f1) (same direction): ", closed[{e[[1]], f[[1]]}]];
Print["2-dim abelian span(f1, f2) (inside V): ", closed[{f[[1]], f[[2]]}]];
Print["2-dim span(e1, f2) (different directions): ", closed[{e[[1]], f[[2]]}],
  "  -> expect False ([e1,f2]=f3 escapes)"];
Print["Done."];

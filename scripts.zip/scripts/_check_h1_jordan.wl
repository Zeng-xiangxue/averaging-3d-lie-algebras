(* h1 bracket: [x,y] = cross product in e3 direction only *)
(* [e1,e2]=e3, others zero. Use vector coordinates. *)
bracket[x_, y_] := Module[{xy, result},
  (* x = {x1,x2,x3}, y={y1,y2,y3}; only [e1,e2] and [e2,e1] nonzero *)
  {x1, x2, x3} = x; {y1, y2, y3} = y;
  result = {0, 0, x1 y2 - x2 y1};
  result
];

(* T = I + N = [[1,1,0],[0,1,0],[0,0,1]] *)
Tmat = {{1,1,0},{0,1,0},{0,0,1}};
T[v_] := Tmat . v;

Print["=== T = I+N on h1 ==="];
basis = {{1,0,0},{0,1,0},{0,0,1}};
allzero = True;
Do[
  Do[
    lhs = bracket[T[x], T[y]];
    rhs = T[bracket[T[x], y]];
    diff = lhs - rhs;
    If[diff =!= {0,0,0},
      Print["FAIL x=",x," y=",y," lhs=",lhs," rhs=",rhs," diff=",diff];
      allzero = False;
    ];
    , {y, basis}];
  , {x, basis}];
Print["All pairs residual zero? ", allzero];

(* General symbolic: T = [[lam,b,0],[0,lam,0],[0,0,lam]] *)
Print["=== General T = [[lam,b,0],[0,lam,0],[0,0,lam]] ==="];
Tg[x1_,x2_,x3_] := {lam*x1 + b*x2, lam*x2, lam*x3};
(* bracket[T[x], T[y]] - T[bracket[T[x], y]] as symbolic *)
(* x={x1,x2,x3}, y={y1,y2,y3} *)
(* Tx = {lam x1+b x2, lam x2, lam x3} *)
(* [Tx,Ty]_z = (lam x1+b x2)(lam y2) - (lam x2)(lam y1+b y2) *)
(*           = lam^2 x1 y2 + lam b x2 y2 - lam^2 x2 y1 - lam b x2 y2 *)
(*           = lam^2 (x1 y2 - x2 y1) *)
(* bracket[T[x],y]_z = (lam x1+b x2) y2 - (lam x2) y1 = lam(x1 y2-x2 y1)+b x2 y2 *)
(* T(bracket[Tx,y]) = T({0,0,lam(x1 y2-x2 y1)+b x2 y2}) = {0,0,lam(lam(x1 y2-x2 y1)+b x2 y2)} *)
(* lhs z = lam^2(x1 y2-x2 y1) *)
(* rhs z = lam^2(x1 y2-x2 y1) + lam b x2 y2 *)
(* diff = - lam b x2 y2 *)
Print["lhs z   = lam^2 (x1 y2 - x2 y1)"];
Print["rhs z   = lam^2 (x1 y2 - x2 y1) + lam b x2 y2"];
Print["diff    = - lam b x2 y2"];
Print["For this to be identically zero need lam*b*x2*y2 = 0 for all x2,y2."];
Print["=> lam*b = 0."];
Print[""];
Print["Conclusion: T=I+N with lam=1, b=1 gives diff = -x2 y2, NOT zero."];
Print("My earlier hand-check was WRONG. The new condition lam*b=0 is CORRECT.");

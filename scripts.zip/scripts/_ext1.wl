(* three remaining 3-dim real Lie algebras  R x| n,  n = R^2 abelian,  ad_e1|n = A *)

basis = {{1,0,0},{0,1,0},{0,0,1}};
vars = Flatten[Table[t[i,j], {i,3}, {j,3}]];
Tm = Table[t[i,j], {i,3}, {j,3}];

setup[A_] := Module[{br, eqs},
  br[x_, y_] := Join[{0}, x[[1]] A.y[[2 ;; 3]] - y[[1]] A.x[[2 ;; 3]]];
  eqs = Flatten[Table[br[Tm.basis[[i]], Tm.basis[[j]]] - Tm.br[Tm.basis[[i]], basis[[j]]],
        {i,3}, {j,3}]];
  eqs = DeleteCases[DeleteDuplicates[eqs], 0];
  {Length[eqs], eqs}
  ];

(* ---- algebra (3):  A = diag(1,0) ---- *)
Module[{n, eqs, gb, sol},
  {n, eqs} = setup[{{1,0},{0,0}}];
  Print["=== A = diag(1,0) : ", n, " nonzero equations ==="];
  gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
  Print["GB length = ", Length[gb]];
  Print[Column[gb]];
  ];
Print[""];

(* ---- algebra (5):  A = J = [[1,1],[0,1]] ---- *)
Module[{n, eqs, gb},
  {n, eqs} = setup[{{1,1},{0,1}}];
  Print["=== A = J (unipotent) : ", n, " nonzero equations ==="];
  gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
  Print["GB length = ", Length[gb]];
  Print[Column[gb]];
  ];
Print[""];

(* ---- algebra (6) at c = 0:  A = J0 = [[0,-1],[1,0]] ---- *)
Module[{n, eqs, gb},
  {n, eqs} = setup[{{0,-1},{1,0}}];
  Print["=== A = [[0,-1],[1,0]] (c=0) : ", n, " nonzero equations ==="];
  gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
  Print["GB length = ", Length[gb]];
  Print[Column[gb]];
  ];

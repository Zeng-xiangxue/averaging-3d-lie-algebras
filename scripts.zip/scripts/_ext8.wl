(* r(1,0): final candidate list, residual + pairwise non-conjugacy *)
basis = {{1,0,0},{0,1,0},{0,0,1}};
A = {{1,0},{0,0}};
br[x_, y_] := Join[{0}, x[[1]] A.y[[2 ;; 3]] - y[[1]] A.x[[2 ;; 3]]];
resid[T_] := Simplify[Union[Flatten[Table[
     br[T.basis[[i]], T.basis[[j]]] - T.br[T.basis[[i]], basis[[j]]], {i,3},{j,3}]]]];

forms = {
  {{0,0,0},{0,0,0},{0,0,0}},                 (* 1 *)
  {{0,0,0},{0,0,0},{1,0,0}},                 (* 2 *)
  {{0,0,0},{1,0,0},{0,0,0}},                 (* 3 *)
  {{0,0,0},{1,0,0},{1,0,0}},                 (* 4 *)
  {{0,0,0},{0,0,0},{0,0,2}},                 (* 5 *)
  {{0,0,0},{0,0,1},{0,0,2}},                 (* 6 *)
  {{0,0,0},{0,0,0},{0,1,2}},                 (* 7 *)
  {{0,0,0},{0,0,1},{1,0,2}},                 (* 8 *)
  {{0,0,0},{1,0,0},{0,0,2}},                 (* 9 *)
  {{1,0,0},{0,1,0},{0,0,1}},                 (* 10 *)
  {{1,0,0},{0,1,0},{1,0,1}},                 (* 11 *)
  {{1,0,0},{0,0,0},{0,0,0}},                 (* 12 *)
  {{1,0,0},{0,0,0},{0,0,2}},                 (* 13 *)
  {{1,0,0},{0,1,0},{0,0,2}},                 (* 14 *)
  {{1,0,1},{0,0,0},{0,0,1}}                  (* 15 *)
  };

Print["--- residuals ---"];
Do[Print[k, " : ", resid[forms[[k]]]], {k, Length[forms]}];

(* non-conjugacy: phi = {{1,0,0},{w1,b11,b12},{w2,b21,b22}} with B = diag(p,s) *)
B = {{p, 0}, {0, s}};
phi = {{1,0,0},{w1,B[[1,1]],B[[1,2]]},{w2,B[[2,1]],B[[2,2]]}};
notConj[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi.T1.Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z*p*s}], {p, s, w1, w2, z},
        MonomialOrder -> DegreeReverseLexicographic];
  gb === {1}];

sol = Select[Range[Length[forms]], resid[forms[[#]]] === {0} &];
Print["--- forms that are solutions ---"];
Print[sol];
bad = {};
Do[If[MemberQ[sol,i] && MemberQ[sol,j] && ! notConj[forms[[i]], forms[[j]]],
    AppendTo[bad, {i, j}]],
  {i, Length[forms]}, {j, i+1, Length[forms]}];
Print["--- conjugate pairs among solutions ---"];
Print[bad];

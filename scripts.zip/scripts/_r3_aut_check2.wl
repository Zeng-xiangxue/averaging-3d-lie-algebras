(* r3 conjugation rules, part 2: rename block D -> DD to avoid protected symbol. *)
ClearAll["Global`*"];
B = {{b11,b12},{b21,b22}}; v = {v1,v2}; DD = {{d11,d12},{d21,d22}}; g = {g1,g2}; bt = {bt1,bt2}; a = Symbol["a"];
phi3 = {{1,0,0},{v[[1]],B[[1,1]],B[[1,2]]},{v[[2]],B[[2,1]],B[[2,2]]}};
T3  = {{a,bt[[1]],bt[[2]]},{g[[1]],DD[[1,1]],DD[[1,2]]},{g[[2]],DD[[2,1]],DD[[2,2]]}};
Tp3 = Simplify[phi3 . T3 . Inverse[phi3]];
ap  = Tp3[[1,1]];
btp = {Tp3[[1,2]],Tp3[[1,3]]};
gp  = {Tp3[[2,1]],Tp3[[3,1]]};
Dp  = Tp3[[2;;3,2;;3]];

Print["== conjugation rules (renamed) =="];
Print["  a'  == a - bt^T B^-1 v          : ", Simplify[ap - (a - bt.Inverse[B].v)] == 0];
Print["  bt'^T == bt^T B^-1             : ", Simplify[btp - bt.Inverse[B]] == {0,0}];
Print["  D'  == B D B^-1 + v bt'^T      : ", Simplify[Dp - (B.DD.Inverse[B] + KroneckerProduct[v, btp])] == 0*Dp];
Print["  g'  == B g + a' v - B D B^-1 v : ", Simplify[gp - (B.g + ap v - B.DD.Inverse[B].v)] == {0,0}];
Print["  (trap) g' == B g + a v - BDB^-1 v (wrong) ? ", Simplify[gp - (B.g + a v - B.DD.Inverse[B].v)] == {0,0}];
Print["  beta=0 => a invariant (substitution) : ", Simplify[btp /. {bt1->0,bt2->0}] == {0,0} && Simplify[ap /. {bt1->0,bt2->0}] == a];
(* normalization: beta != 0 => can solve v for a'=0 *)
Print["  beta != 0 => exists v with a'=0 (solve) : ", 
  Module[{vsol = Solve[Simplify[ap] == 0, v1][[1]]}, Simplify[ap /. vsol] == 0]];

(* sl2 rank-2: exclude by ker type. Aut = SO(2,1)^o acts transitively on each type.
   Type 1 (null):  ker = span(e1),  T has first column 0
   Type 2 (spacelike): ker = span(e2),  T has second column 0
   Type 3 (timelike): ker = span(e1 - e3),  T(e1) = T(e3), columns 1 = 3
   In each case: solve averaging equations, check all 2x2 minors vanish (rank <= 1) *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
TT = Table[t[i,j], {i,3}, {j,3}];
vars = Flatten[TT];
eqsT = DeleteCases[Flatten[Table[
  lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]], 0];
minors = {t[1,1] t[2,2] - t[1,2] t[2,1], t[1,1] t[2,3] - t[1,3] t[2,1], t[1,2] t[2,3] - t[1,3] t[2,2],
          t[1,1] t[3,2] - t[1,2] t[3,1], t[1,1] t[3,3] - t[1,3] t[3,1], t[1,2] t[3,3] - t[1,3] t[3,2],
          t[2,1] t[3,2] - t[2,2] t[3,1], t[2,1] t[3,3] - t[2,3] t[3,1], t[2,2] t[3,3] - t[2,3] t[3,2]};

MyCheck[params_, name_] := Module[{eqs, gb, allzero},
  eqs = eqsT /. params;
  gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
  allzero = True;
  Do[
    red = PolynomialReduce[minors[[m]], gb, vars][[2]];
    If[Simplify[red] =!= 0, allzero = False;
      Print["    ", name, ": minor ", m, " NOT in ideal, remainder = ", red]],
    {m, 9}];
  Print["  ", name, ": all minors in ideal (rank <= 1)? ", allzero];
  Print["  ", name, ": GB size = ", Length[gb]]];

Print["== Type 1: null kernel ker = span(e1), T col1 = 0 =="];
p1 = {t[1,1] -> 0, t[2,1] -> 0, t[3,1] -> 0};
MyCheck[p1, "null"];

Print["== Type 2: spacelike kernel ker = span(e2), T col2 = 0 =="];
p2 = {t[1,2] -> 0, t[2,2] -> 0, t[3,2] -> 0};
MyCheck[p2, "spacelike"];

Print["== Type 3: timelike kernel ker = span(e1 - e3), T col1 = col3 =="];
p3 = {t[1,1] -> t[1,3], t[2,1] -> t[2,3], t[3,1] -> t[3,3]};
MyCheck[p3, "timelike"];

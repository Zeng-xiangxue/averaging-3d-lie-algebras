ClearAll["Global`*"];
(* structure constants C[k,i,j] for [e_i,e_j] = sum_k C[[k,i,j]] e_k *)
brackets = {
  {"a3        ", Table[0, {3}, {3}, {3}]},
  {"h1        ", SparseArray[{{3, 1, 2} -> 1}, {3, 3, 3}]},
  {"r3        ", SparseArray[{{2, 1, 2} -> 1, {3, 1, 3} -> 1}, {3, 3, 3}]},
  {"r3,lam    ", SparseArray[{{2, 1, 2} -> 1, {3, 1, 3} -> la}, {3, 3, 3}]},
  {"sl(2,R)   ", SparseArray[{{1, 1, 2} -> 1, {2, 1, 3} -> -2, {3, 2, 3} -> 1}, {3, 3, 3}]},
  {"so(3)     ", SparseArray[{{3, 1, 2} -> 1, {2, 1, 3} -> -1, {1, 2, 3} -> 1}, {3, 3, 3}]}};

T = Array[t, {3, 3}]; vars = Flatten[T];
br[u_, v_] := Sum[u[[i]] v[[j]] brackets[[bk, 2, k, i, j]], {i, 3}, {j, 3}, {k, 3}] & /@ {1, 2, 3} /.
   {} -> {};
lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k, i, j]], {i, 3}, {j, 3}], {k, 3}];
avg[cf_, i_, j_] := lie[cf, T[[All, i]], T[[All, j]]] - T . lie[cf, T[[All, i]], UnitVector[3, j]];
fs = {t[1, 2] - t[2, 1], t[1, 3] - t[3, 1], t[2, 3] - t[3, 2]};

Do[
  cf = brackets[[bk, 2]] - Transpose[brackets[[bk, 2]], {1, 3, 2}];
  eq = Select[DeleteDuplicates[Flatten[Table[avg[cf, i, j], {i, 3}, {j, 3}]]], # =!= 0 &];
  res = Table[
    g = TimeConstrained[GroebnerBasis[Join[eq, {fs[[m]] - 1}], vars], 60, "TO"];
    If[g === "TO", "TO", g === {1}], {m, 3}];
  Print[brackets[[bk, 1]], " #eq=", Length[eq],
   "   (f1-1,f2-1,f3-1) inconsistent? ", res,
   "   => all solutions symmetric? ", And @@ res],
  {bk, Length[brackets]}];

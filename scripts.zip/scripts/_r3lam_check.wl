(* Independent check of r3,lambda setup (lambda = 2): beta=0, E1/E2/E3, e2e3^T vs e3e2^T, a!=0 branch, gamma classes *)
ClearAll["Global`*"];
lam = 2;
sc = SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->lam, {3,3,1}->-lam}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== 1. e2 e3^T vs e3 e2^T (lambda=2) =="];
T23 = {{0,0,0},{0,0,1},{0,0,0}};  (* T(e3)=e2 *)
T32 = {{0,0,0},{0,0,0},{0,1,0}};  (* T(e2)=e3 *)
Print["  e2 e3^T resid = ", resid[T23]];
Print["  e3 e2^T resid = ", resid[T32], "   <-- user claims 1 (nonzero)"];
Do[
  g = RandomReal[{-2,2}, 2];
  T = {{0,0,0},{g[[1]],0,0},{g[[2]],1,0}};
  Print["  e3 e2^T + (", g[[1]], ",", g[[2]], ")e1^T resid = ", resid[T]],
  {2}];

Print["== 2. reduced system E1,E2,E3 vs direct residual =="];
ad = DiagonalMatrix[{1, lam}];
Do[
  a0 = RandomReal[{-3,3}, 1][[1]];
  Dm = RandomReal[{-2,2}, {2,2}];
  g = RandomReal[{-2,2}, 2];
  T = {{a0,0,0},{g[[1]],Dm[[1,1]],Dm[[1,2]]},{g[[2]],Dm[[2,1]],Dm[[2,2]]}};
  r = resid[T];
  sys = Max[Abs[Flatten[{a0 (Dm . ad - ad . Dm), Dm . ad . g, Dm . ad . Dm - a0 ad . Dm}]]];
  Print["  a=", a0, " resid=", r, "  sys=", sys, "  agree? ", Abs[r - sys] < 10^-9],
  {5}];

Print["== 3. a != 0 branch: four families + counterexample =="];
Print["  a e1 e1^T (D=0) resid = ", resid[{{3,0,0},{0,0,0},{0,0,0}}]];
Print["  diag(a,a,0)  resid = ", resid[{{3,0,0},{0,3,0},{0,0,0}}]];
Print["  diag(a,0,a)  resid = ", resid[{{3,0,0},{0,0,0},{0,0,3}}]];
Print["  a Id3        resid = ", resid[{{3,0,0},{0,3,0},{0,0,3}}]];
Print["  diag(1,2), a=5 resid = ", resid[{{5,0,0},{0,1,0},{0,0,2}}], "  (expect nonzero)"];

Print["== 4. a=0, D=0: gamma classes under diagonal Aut =="];
Do[
  g = {g1, g2}; If[g1 == 0 && g2 == 0, g1 = 0.7]; If[g1 == 0, g2 = 1.3]; If[g2 == 0, g1 = 1.1];
  T = {{0,0,0},{g1,0,0},{g2,0,0}};
  Print["  gamma=(", g1, ",", g2, "): resid = ", resid[T]],
  {4}];
Print["  action: gamma' = diag(b,c) gamma;  (1,0)->(0,1) impossible; 4 classes confirmed"];

Print["== 5. lambda=1 reduces to r3 =="];
Print["  ad - I = ", DiagonalMatrix[{1,1}] - IdentityMatrix[2], " (zero) -> E1 vanishes"];

Print["== 6. D diag(d1,d2), di in {0,a}: verify =="];
Do[
  a0 = RandomReal[{0.5,3}, 1][[1]];
  d1 = RandomChoice[{0, a0}]; d2 = RandomChoice[{0, a0}];
  T = {{a0,0,0},{0,d1,0},{0,0,d2}};
  Print["  a=", a0, " D=diag(", d1, ",", d2, "): resid = ", resid[T]],
  {3}];
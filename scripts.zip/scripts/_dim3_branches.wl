#!/usr/bin/env wolframscript
(* print every branch of the three classes that Solve handles, and mark
   for each branch whether it contains a non-symmetric member *)
ClearAll["Global`*"];
B = {
  {"h1     ", SparseArray[{{3, 1, 2} -> 1}, {3, 3, 3}]},
  {"r3     ", SparseArray[{{2, 1, 2} -> 1, {3, 1, 3} -> 1}, {3, 3, 3}]},
  {"r3,lam ", SparseArray[{{2, 1, 2} -> 1, {3, 1, 3} -> la}, {3, 3, 3}]}};
T = Array[t, {3, 3}]; vars = Flatten[T];
lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k, i, j]], {i, 3}, {j, 3}], {k, 3}];
avg[cf_, i_, j_] := lie[cf, T[[All, i]], T[[All, j]]] - T . lie[cf, T[[All, i]], UnitVector[3, j]];

Do[
  cf = B[[k, 2]] - Transpose[B[[k, 2]], {1, 3, 2}];
  eq = Select[DeleteDuplicates[Flatten[Table[avg[cf, i, j], {i, 3}, {j, 3}]]], # =!= 0 &];
  sol = Solve[eq == 0, vars, Reals];
  Print["===== ", B[[k, 1]], " : ", Length[sol], " branches ====="];
  Do[
   br = sol[[n]];
   (* does this branch force symmetry? *)
   sym = Simplify[(t[1, 2] - t[2, 1] /. br) == 0 && (t[1, 3] - t[3, 1] /. br) == 0 &&
       (t[2, 3] - t[3, 2] /. br) == 0];
   Print["  [", n, "] ", If[sym === True, "SYMMETRIC  ", "*** NON-SYM *** "],
    Column[Simplify[{t[1, 1], t[1, 2], t[1, 3], t[2, 1], t[2, 2], t[2, 3],
        t[3, 1], t[3, 2], t[3, 3]} /. br]]];
   , {n, Length[sol]}];
  Print[],
  {k, Length[B]}];

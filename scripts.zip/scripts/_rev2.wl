(* c = 0 : pairwise non-conjugacy of the four classes of r(c) under the FULL automorphism group *)
(* Aut_0 : a = 1, B = p{{1,-t},{t,1}}                      *)
(* mirror: a = -1, B = {{p,q},{q,-p}}                      *)
phi0 = {{1, 0, 0}, {w1, p, -p*t}, {w2, p*t, p}};
phim = {{-1, 0, 0}, {w1, p, q}, {w2, q, -p}};

conjQ[T1_, T2_] := Module[{eqs0, eqsm, gb0, gbm, vars},
  vars = {p, t, q, w1, w2, z};
  eqs0 = Numerator /@ Together /@ Flatten[phi0.T1.Inverse[phi0] - T2];
  gb0 = GroebnerBasis[Join[eqs0, {1 - z*(p*(p^2 + p^2*t^2))}], vars,
        MonomialOrder -> DegreeReverseLexicographic];
  eqsm = Numerator /@ Together /@ Flatten[phim.T1.Inverse[phim] - T2];
  gbm = GroebnerBasis[Join[eqsm, {1 - z*(-p^2 - q^2)}], vars,
        MonomialOrder -> DegreeReverseLexicographic];
  {gb0, gbm}
  ];

forms = {
  {{0,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{0,0,0}},
  {{1,0,0},{0,1,0},{0,0,1}},
  {{1,0,0},{0,0,0},{0,0,0}}
  };

Print["components that admit a conjugating element (empty = none):"];
Do[
  If[i != j,
    r = conjQ[forms[[i]], forms[[j]]];
    Print[{i, j}, " -> Aut0: ", r[[1]] =!= {1}, ", mirror: ", r[[2]] =!= {1}]];
  ,
  {i, 4}, {j, 4}];

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
okv[R_] := AllTrue[Flatten[avgDef[R]], (Chop[Simplify[N[#]]] === 0) &];
TAB[A_, Bb_, Cc_, Dm_] := ArrayFlatten[{{A, Bb}, {Cc, Dm}}];
E1 = {1, 0, 0};

(* rotate the e1 description to a general direction u *)
SeedRandom[4];
Q = Orthogonalize[RandomReal[{-1, 1}, {3, 3}]];
If[Det[Q] < 0, Q[[3]] = -Q[[3]]];
U[q_] := q . # . Transpose[q] &;
u = Q . E1;
C0[p_, q_] := {{0, 0, 0}, {0, p, q}, {0, -q, p}};
D0[lam_] := lam (e3 - Outer[Times, E1, E1]);
A0[lam_] := lam Outer[Times, E1, E1];

Print["=== branch (c) with a GENERAL direction u = Q e1 (lam = 5) ==="];
Do[Print["  (c22,c23) = ", v, " : ", okv[TAB[U[Q][A0[5]], Z3,
    U[Q][C0 @@ v], U[Q][D0[5]]]]], {v, {{0, 0}, {1, 0}, {0, 1}, {2, -3}}}];
Print["  negatives (rotated):"];
Print["    C = diag(1,2,3) rotated      : ",
  okv[TAB[U[Q][A0[5]], Z3, U[Q][DiagonalMatrix[{1, 2, 3}]], U[Q][D0[5]]]]];
Print["    D = 5 I (not 5(I-uu^T))      : ", okv[TAB[U[Q][A0[5]], Z3, U[Q][C0[1, 0]], 5 e3]]];
Print[""];
Print["=== branch (d) four collinear blocks, general u, random scalars ==="];
SeedRandom[7];
Do[s = RandomInteger[{-4, 4}, 4]; Ut = Outer[Times, u, u];
  Print["  (lam,al,ga,de) = ", s, " : ",
   okv[TAB[s[[1]] Ut, s[[2]] Ut, s[[3]] Ut, s[[4]] Ut]]], {4}];
Print[""];
Print["=== branch (a) scalar+ nilpotent, general lam and c ==="];
Do[Print["  lam = ", s[[1]], ", c = ", s[[2]], " : ",
   okv[TAB[s[[1]] e3, Z3, s[[2]] e3, s[[1]] e3]]],
  {s, {{3, 1}, {-2, 5}, {1, -4}}}];
Print[""];
Print["=== branch (b) B=0, D=beta uu^T, C the 3-param family, general u ==="];
Do[s = RandomInteger[{-3, 3}, 3]; Ut = Outer[Times, u, u];
  Cf = (s[[2]] Outer[Times, u, u] + (s[[3]]/2) (Outer[Times, u, #] - Outer[Times, #, u]) &);
  Print["  c11,c12,c13 = ", s, " : ",
   okv[TAB[3 Ut, Z3, Outer[Times, u, {1, 0, 0}] s[[1]] + s[[2]] Outer[Times, u, {0, 1, 0}] +
     s[[3]] Outer[Times, u, {0, 0, 1}], 5 Ut]]], {1}];
Print["  (spot check of the e1-form of the C family, rotated) : ",
  okv[TAB[3 Outer[Times, u, u], Z3,
    U[Q][{{1, 2, 3}, {3 2/5, 0, 0}, {3 3/5, 0, 0}}], 5 Outer[Times, u, u]]]];

(* fix: user's example (N,0) ~ (N,(0,1)) via w=(1,0), M=Id *)
ClearAll["Global`*"];
sc = SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
phiE = {{1,0,0},{0,1,0},{1,0,1}};
TN0 = {{0,1,0},{0,0,0},{0,0,0}};
TN01 = phiE . TN0 . Inverse[phiE];
Print["phi (N,0) phi^-1 = ", MatrixForm[TN01], "   (expect Z'=(0,1))"];
Print["resid of image = ", resid[TN01]];
(* converse: (N,(1,0)) NOT ~ (N,0): z1-nullity invariant. *)
TN10 = {{0,1,0},{0,0,0},{1,0,0}};
(* generic phi in stabilizer of N: M={{a,b},{0,a}}, check z'1 = a*z1 for z=(1,0) *)
Mst = {{a,b},{0,a}}; dst = Det[Mst]; wst = {w1,w2};
phist = {{Mst[[1,1]],Mst[[1,2]],0},{Mst[[2,1]],Mst[[2,2]],0},{wst[[1]],wst[[2]],dst}};
T10 = {{0,1,0},{0,0,0},{1,0,0}};
T10p = Simplify[phist . T10 . Inverse[phist]];
Print["generic image of (N,(1,0)): Z' block = ", {T10p[[3,1]],T10p[[3,2]]}];
Print["  -> z'1 = ", Simplify[T10p[[3,1]]], "  (nonzero multiple of z1=1, so z1-nullity invariant)"];
(* and (N,0): z'1 stays 0 *)
T0p = Simplify[phist . TN0 . Inverse[phist]];
Print["generic image of (N,0): Z' block = ", {T0p[[3,1]],T0p[[3,2]]}, "  (z'1 = 0 always)"];

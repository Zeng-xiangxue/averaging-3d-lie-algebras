cf2 = Normal[SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->2, {3,3,1}->-2}, {3,3,3}]];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
unit = IdentityMatrix[3];
resid2[MT_] := Max[Abs[Flatten[Table[lie[cf2, MT[[All,i]], MT[[All,j]]] - MT . lie[cf2, MT[[All,i]], unit[[j]]], {i,3},{j,3}]]]];
phi = {{1,0,0},{1,1,0},{0,0,1}};
T2p = {{0,0,0},{0,0,0},{1,1,0}}; T2 = {{0,0,0},{0,0,0},{0,1,0}};
Print["phi T2' phi^-1 = ", MatrixForm[phi . T2p . Inverse[phi]], "  equals e3e2^T? ",
  phi . T2p . Inverse[phi] == T2, "  resid = ", resid2[phi . T2p . Inverse[phi]]];

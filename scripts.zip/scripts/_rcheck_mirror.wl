ClearAll["Global`*"];
A0 = {{0, -1}, {1, 0}};
br[x_, y_] := Join[{0}, x[[1]] A0 . y[[2 ;; 3]] - y[[1]] A0 . x[[2 ;; 3]]];
e = IdentityMatrix[3];
phi = {{-1, 0, 0}, {w1, p, q}, {w2, q, -p}};
T = {{a1, b1, b2}, {g1, m11, m12}, {g2, m21, m22}};
Tc = Simplify[phi . T . Inverse[phi]];
B = {{p, q}, {q, -p}}; Bi = Inverse[B];
ap = a1 - {b1, b2} . Bi . {w1, w2};
bp = -Transpose[Bi] . {b1, b2};
Mp = B . {{m11, m12}, {m21, m22}} . Bi - Outer[Times, {w1, w2}, bp];
gp = -B . {g1, g2} - ap {w1, w2} + B . {{m11, m12}, {m21, m22}} . Bi . {w1, w2};
Print["a  match : ", Simplify[Tc[[1,1]] - ap] === 0];
Print["beta match : ", Simplify[{Tc[[1,2]], Tc[[1,3]]} - bp] === {0, 0}];
Print["M  match : ", Simplify[{{Tc[[2,2]], Tc[[2,3]]}, {Tc[[3,2]], Tc[[3,3]]}} - Mp] === {{0,0},{0,0}}];
Print["gamma match : ", Simplify[{Tc[[2,1]], Tc[[3,1]]} - gp] === {0, 0}];
(* and on the solution set beta = 0 *)
Print["on beta=0 : a'=a ? ", Simplify[(ap /. {b1->0,b2->0}) - a1] === 0];
Print["on beta=0 : M'=BMB^{-1} ? ", Simplify[(Mp /. {b1->0,b2->0}) - B . {{m11,m12},{m21,m22}} . Bi] === {{0,0},{0,0}}];

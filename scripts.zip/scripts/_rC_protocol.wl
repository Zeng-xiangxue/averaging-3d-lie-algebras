(* (1) verify your B-computation : is there B in C(C_c) with B M B^{-1} = - M ? *)
ClearAll["Global`*"];
M = {{-lam, cc lam}, {0, 0}};
B = {{a, b}, {-b, a}};
Print["BM + MB  = ", Simplify[B . M + M . B]];
sol = Solve[{Flatten[B . M + M . B] == 0, a^2 + b^2 == 1}, {a, b}, Reals];
Print["solutions of B M = - M B  with det B = 1 : ", sol];
Print["  (so lam and -lam are NOT conjugate)"];

(* (2) r(c) : full-group pairwise test of the 5 corrected classes + generic branch solutions *)
A = {{1, -1}, {1, 1}};                       (* c = 1 ; same for general c *)
e = IdentityMatrix[3];
br[x_, y_] := Join[{0}, x[[1]] A . y[[2 ;; 3]] - y[[1]] A . x[[2 ;; 3]]];
res[T_] := Max[Abs[Flatten[Table[br[T.e[[i]], T.e[[j]]] - T.br[T.e[[i]], e[[j]]], {i, 3}, {j, 3}]]]];
phi = {{1, 0, 0}, {w1, a, b}, {w2, -b, a}};
conj[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi . T1 . Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z (a^2 + b^2)}], {a, b, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
five = {{"0", {{0,0,0},{0,0,0},{0,0,0}}},
        {"e2e1'", {{0,0,0},{1,0,0},{0,0,0}}},
        {"a Id", 2 IdentityMatrix[3]},
        {"a e1e1'", {{2,0,0},{0,0,0},{0,0,0}}},
        {"lam e2(-e2+c e3)'", {{0,0,0},{0,-1,1},{0,0,0}}}};
Print["residuals of the five classes: ", Table[res[five[[k,2]]], {k, 5}]];
Print["all C(5,2) = 10 pairs under the FULL group (all must be False = non-conjugate):"];
bad = 0;
Do[If[i < j, Module[{q = conj[five[[i,2]], five[[j,2]]]},
    If[q, bad++]; Print["   ", five[[i,1]], " ~ ", five[[j,1]], " ? ", q]]], {i, 5}, {j, 5}];
Print["conjugacies found: ", bad];

(* generic solutions of the a = 0 branch, and their predicted class *)
genTest[n_] := Module[{cnt = 0, fails = 0},
  Do[Module[{u, Au, v, s, rho, Mm, T, lam, target},
     u = RandomReal[{-2, 2}, 2];
     If[Norm[u] < 0.1, Continue[]];
     Au = A . u;
     v = {-Au[[2]], Au[[1]]};
     s = RandomReal[{-2, 2}]; rho = RandomReal[{-2, 2}];
     Mm = s Outer[Times, u, v];
     T = Join[{Join[{0, 0}, {0}]}, {{rho u[[1]], Mm[[1,1]], Mm[[1,2]]}, {rho u[[2]], Mm[[2,1]], Mm[[2,2]]}}];
     If[res[T] > 10^-9, Continue[]];
     cnt++;
     lam = -Tr[Mm];
     target = {{0,0,0},{0,-lam, lam},{0,0,0}};
     If[!conj[T, target], fails++];
     ], {k, n}];
  {cnt, fails}];
Print[""];
Print["generic a=0 branch solutions : {tested, failures of 'conjugate to listed class'} = ", genTest[12]];

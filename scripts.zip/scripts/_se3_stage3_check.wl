(* Independent verification of se3_stage3.wl + solve the A=diag(lam,0,0) case *)
ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
eh = e6[[1 ;; 3]]; ef = e6[[4 ;; 6]];
blk[A_, B_, Cc_, Dm_] := ArrayFlatten[{{A, B}, {Cc, Dm}}];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
ok[R_] := avgRes[R] < 10.^-10;
avgRes[R_] := Max[Abs[Flatten[Table[
     br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]],
     {i, 6}, {j, 6}]]]];

Print["=== 1.  four groups reproduce the system ==="];
AA = Array[aa, {3, 3}]; BB = Array[bb, {3, 3}];
Ah[i_] := AA . eh[[i]][[1 ;; 3]]; Bv[j_] := BB . ef[[j]][[4 ;; 6]];
g1 = Flatten[Table[Cross[Ah[i], Ah[j]] - AA . Cross[Ah[i], eh[[j]][[1 ;; 3]]], {i, 3}, {j, 3}]];
g2 = Flatten[Table[Cross[Ah[i], Bv[j]] - BB . Cross[Ah[i], ef[[j]][[4 ;; 6]]], {i, 3}, {j, 3}]];
g3 = Flatten[Table[Cross[Bv[i], Ah[j]] - AA . Cross[Bv[i], eh[[j]][[1 ;; 3]]], {i, 3}, {j, 3}]];
g4 = Flatten[Table[Cross[Bv[i], Bv[j]] - BB . Cross[Bv[i], ef[[j]][[4 ;; 6]]], {i, 3}, {j, 3}]];
T2 = blk[AA, BB, Z3, Z3];
conds = Select[DeleteDuplicates[Expand[avgDef[T2]]], # =!= 0 &];
allg = Select[DeleteDuplicates[Flatten[{g1, g2, g3, g4}]], # =!= 0 &];
Print["  nonzero equations = ", Length[conds], " ;  split reproduces system? ",
  Sort[Expand[allg]] === Sort[Expand[conds]]];

Print["=== 2.  A = 0 :  B-self condition (B = mu l l^T or mu Id or 0) ==="];
chk[n_, M_] := Print["  ", n, " : ", ok[blk[Z3, M, Z3, Z3]]];
chk["B = 0              ", Z3];
chk["B = 3 Id           ", 3 e3];
chk["B = 3 e1 e1^T      ", 3 Outer[Times, {1, 0, 0}, {1, 0, 0}]];
chk["B = u u^T          ", Outer[Times, {2, -3, 5}, {2, -3, 5}]];
chk["B = skew           ", {{0, 3, -2}, {-3, 0, 1}, {2, -1, 0}}];
chk["B = diag(1,1,0)    ", DiagonalMatrix[{1, 1, 0}]];
chk["B = diag(1,2,3)    ", DiagonalMatrix[{1, 2, 3}]];
Print["  rank-2 impossibility: im B is a subalgebra of h = so(3) (since",
  " [Bv1,Bv2] = B((Bv1)x v2) in im B), and so(3) has no 2-dim subalgebra."];
Print["  => rank B in {0,1,3}:  rank 1 forces B = mu l l^T (psi || l);",
  "  rank 3 forces B = mu Id (centraliser of so(3))."];

Print["=== 3.  A = lam Id  (solve symbolically) ==="];
gA = Select[DeleteDuplicates[Expand[Flatten[{g2, g3, g4}] /.
     Thread[Flatten[AA] -> Flatten[lam e3]]]], # =!= 0 &];
Print["  distinct conditions: ", Length[gA]];
solA = TimeConstrained[Solve[gA == 0, Flatten[BB]], 120, "TO"];
Print["  Solve: ", Head[solA]];
If[Head[solA] === List, Print["  solutions: ", Simplify[solA]]];

Print["=== 4.  A = diag(lam,0,0)  (solve symbolically) ==="];
gD = Select[DeleteDuplicates[Expand[Flatten[{g2, g3, g4}] /.
     Thread[Flatten[AA] -> Flatten[DiagonalMatrix[{lam, 0, 0}]]]], # =!= 0 &];
Print["  distinct conditions: ", Length[gD]];
Print["  factored conditions (first 8):"];
Do[Print["    ", Factor[gD[[k]]] == 0], {k, Min[8, Length[gD]]}];
solD = TimeConstrained[Solve[gD == 0, Flatten[BB]], 120, "TO"];
Print["  Solve: ", Head[solD]];
If[Head[solD] === List, Print["  solutions: ", Simplify[solD]]];
(* numeric spot checks for the A=diag case *)
chk2[n_, M_] := Print["  ", n, " : ", ok[blk[DiagonalMatrix[{2, 0, 0}], M, Z3, Z3]]];
chk2["B = 3 e1 e1^T      ", 3 Outer[Times, {1, 0, 0}, {1, 0, 0}]];
chk2["B = 0              ", Z3];
chk2["B = 3 Id           ", 3 e3];
chk2["B = e1 e2^T (off)  ", Outer[Times, {1, 0, 0}, {0, 1, 0}]];
chk2["B = e2 e2^T (off)  ", Outer[Times, {0, 1, 0}, {0, 1, 0}]];
chk2["B = e1(e1+e2)^T    ", Outer[Times, {1, 0, 0}, {1, 1, 0}]];

Print["=== 5.  Remark consistency check (so(3) averaging vs RBO) ==="];
Av = Array[aa, {3, 3}];
eqA = DeleteCases[Expand[Flatten[Table[
     Cross[Av . eh[[i]][[1 ;; 3]], Av . eh[[j]][[1 ;; 3]]] -
      Av . Cross[Av . eh[[i]][[1 ;; 3]], eh[[j]][[1 ;; 3]]],
     {i, 3}, {j, 3}]]], 0];
eqR = DeleteCases[Expand[Flatten[Table[
     Cross[Av . eh[[i]][[1 ;; 3]], Av . eh[[j]][[1 ;; 3]]] -
      Av . (Cross[Av . eh[[i]][[1 ;; 3]], eh[[j]][[1 ;; 3]]] +
        Cross[eh[[i]][[1 ;; 3]], Av . eh[[j]][[1 ;; 3]]]),
     {i, 3}, {j, 3}]]], 0];
f = aa[1, 2] - aa[2, 1];
chkI[tag_, eqs_] := Module[{gb, r1, r2, r3},
  gb = GroebnerBasis[eqs, Flatten[Av]];
  r1 = PolynomialReduce[f, gb, Flatten[Av]];
  r2 = PolynomialReduce[f^2, gb, Flatten[Av]];
  r3 = GroebnerBasis[Append[eqs, f - 1], Flatten[Av]];
  Print["  ", tag, ": GB size ", Length[gb], " ; f in ideal? ", r1[[2]] === 0,
   " ; f^2 in ideal? ", r2[[2]] === 0,
   " ; eqs+(f-1) -> {1}? ", r3 === {1}]];
chkI["averaging", eqA];
chkI["Rota-Baxter", eqR];
Print["Done."];

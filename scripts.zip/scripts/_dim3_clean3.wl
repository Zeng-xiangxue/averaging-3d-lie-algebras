(* Clean verification v3: averaging operators on the six 3-dim real Lie algebras *)
(* one-term averaging: [T(x),T(y)] = T([T(x),y]); FULL antisymmetrised structure constants *)

ClearAll["Global`*"];

sc = Association[
  "a3"   -> Table[0, {3}, {3}, {3}],
  "h1"   -> SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}],
  "r3"   -> SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}],
  "r3lam"-> SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->la, {3,3,1}->-la}, {3,3,3}],
  "sl2"  -> SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}],
  "so3"  -> SparseArray[{{3,1,2}->1, {3,2,1}->-1, {2,1,3}->-1, {2,3,1}->1, {1,2,3}->1, {1,3,2}->-1}, {3,3,3}]
];

T = Array[t, {3, 3}]; vars = Flatten[T];
fs = {t[1,2]-t[2,1], t[1,3]-t[3,1], t[2,3]-t[3,2]};
unit = Table[UnitVector[3, i], {i, 3}];

lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
Tv[v_] := Table[Sum[t[i,j] v[[j]], {j,3}], {i,3}];
avg[cf_, i_, j_] := lie[cf, Tv[unit[[i]]], Tv[unit[[j]]]] - Tv[lie[cf, Tv[unit[[i]]], unit[[j]]]];
allEqs[cf_] := DeleteDuplicates[Flatten[Table[avg[cf, i, j], {i,3}, {j,3}]]];

Print["== symmetry test =="];
Do[
  cf = sc[al];
  eq = Select[allEqs[cf], # =!= 0 &];
  If[Length[eq] == 0,
    Print[al, "  : equations identically zero -> EVERY linear map is averaging (abelian)"],
    res = Table[
      g = TimeConstrained[GroebnerBasis[Join[eq, {fs[[m]] - 1}], vars, MonomialOrder -> DegreeReverseLexicographic], 90, "TO"];
      If[g === "TO", "TO", g === {1}], {m, 3}];
    sym = And @@ (res === True);
    Print[al, "  : #eq=", Length[eq], "  (f1-1,f2-1,f3-1)->{1}? ", res, "  all symmetric? ", sym];
    If[Not[sym],
      sol = TimeConstrained[FindInstance[Join[Thread[eq == 0], {fs[[1]] - 1 == 0}], vars, Reals, 1], 120, "TO"];
      If[sol === "TO", Print[al, "    (explicit solution not found in 120s)"],
        M = Table[t[i,j] /. sol[[1]], {i,3}, {j,3}];
        Print[al, "    explicit non-symmetric solution T = ", M, "   (as rows)  antisym part (t12-t21,t13-t31,t23-t32) = ", {M[[1,2]]-M[[2,1]], M[[1,3]]-M[[3,1]], M[[2,3]]-M[[3,2]]}]]]
  ],
  {al, {"a3","h1","r3","r3lam","sl2","so3"}}];

Print["== explicit hand-made counterexamples (numeric verification) =="];
verifyT[al_, M_] := Module[{cf = sc[al], u, v, res},
  u = Table[UnitVector[3, i], {i, 3}];
  res = Table[lie[cf, M.u[[i]], M.u[[j]]] - M.(lie[cf, M.u[[i]], u[[j]]]), {i, 3}, {j, 3}];
  Print[al, "  T rows=", M, "  max |residual| = ", Max[Abs[Flatten[res]]], "  => averaging? ", Max[Abs[Flatten[res]]] == 0]];
verifyT["h1", {{1,1,0},{0,0,0},{0,0,0}}];
verifyT["r3", {{0,0,0},{1,0,0},{0,0,0}}];

Print["== dim Der(g) (Aut(g) proper in GL(3) iff < 9) =="];
Do[
  cf = sc[al];
  dd = Table[ddm[i, j], {i, 3}, {j, 3}];
  derPoly = Flatten[Table[
    Sum[dd[[p,i]] cf[[k,p,j]] + dd[[p,j]] cf[[k,i,p]] - cf[[p,i,j]] dd[[k,p]], {p,3}],
    {k,3}, {i,3}, {j,3}]];
  coef = Table[Coefficient[derPoly[[r]], dd[[a,b]]], {r, Length[derPoly]}, {a,3}, {b,3}];
  Print[al, " : dim Der = ", 9 - MatrixRank[coef]],
  {al, {"a3","h1","r3","r3lam","sl2","so3"}}];

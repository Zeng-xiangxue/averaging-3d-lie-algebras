(* debug: why did _rev7 flag everything as conjugate? *)
B = {{p, 0}, {0, s}};
phi = {{1,0,0},{w1,B[[1,1]],B[[1,2]]},{w2,B[[2,1]],B[[2,2]]}};

T1 = {{0,0,0},{0,0,0},{0,0,0}};
T2 = {{1,0,0},{0,1,0},{0,0,1}};
eqs = Numerator /@ Together /@ Flatten[phi.T1.Inverse[phi] - T2];
Print["equations (0 ~ Id): ", eqs];
gb = GroebnerBasis[Join[eqs, {1 - z*p*s}], {p, s, w1, w2, z},
      MonomialOrder -> DegreeReverseLexicographic];
Print["GroebnerBasis = ", gb];
Print["gb === {1} ? ", gb === {1}];

(* working pattern from the earlier scripts *)
gb2 = GroebnerBasis[Join[eqs, {1 - z*p*s}], {p, s, w1, w2, z}];
Print["default order basis = ", gb2];
Print["gb2 === {1} ? ", gb2 === {1}];

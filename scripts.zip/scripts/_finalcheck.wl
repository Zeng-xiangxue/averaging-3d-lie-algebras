(* final checks on the missing r(c) family *)
ClearAll["Global`*"];
e = IdentityMatrix[3];
A = {{1,-1},{1,1}};                       (* c = 1 *)
brC[x_,y_] := Join[{0}, x[[1]] A . y[[2;;3]] - y[[1]] A . x[[2;;3]]];
resC[T_] := Max[Abs[Flatten[Table[brC[T.e[[i]],T.e[[j]]] - T.brC[T.e[[i]],e[[j]]],{i,3},{j,3}]]]];
Tc[lam_] := {{0,0,0},{0,-lam,lam},{0,0,0}};     (* the missing family, c = 1 *)
Talt    := {{0,0,0},{0,0,0},{0,1,1}};           (* u = e3 , v = (c,1) *)
Print["residual family lam=5 : ", resC[Tc[5]]];
Print["residual alternative   : ", resC[Talt]];
phi = {{1,0,0},{w1,p,-p t},{w2,p t,p}};
conj[T1_,T2_] := Module[{eqs,gb},
  eqs = Numerator /@ Together /@ Flatten[phi . T1 . Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p}], {p,t,w1,w2,z}, MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
Print["alternative ~ family(lam=-1) (same trace 1) ? ", conj[Talt, Tc[-1]]];
Print["family lam=1 ~ lam=-1 ? ", conj[Tc[1], Tc[-1]]];
Print["family lam=1 ~ 2Id ? ", conj[Tc[1], 2 IdentityMatrix[3]]];
Print["family lam=1 ~ 2e1e1' ? ", conj[Tc[1], {{2,0,0},{0,0,0},{0,0,0}}]];
Print["family lam=1 ~ e2e1' ? ", conj[Tc[1], {{0,0,0},{1,0,0},{0,0,0}}]];
(* is it also a 0-weight RBO ?  criterion [g, im T] subset ker T *)
rboQ[T_] := Simplify[Union[Flatten[Table[T.brC[e[[i]], T.e[[j]]], {i,3},{j,3}]]]] === {0};
Print["family lam=1 is 0-weight RBO ? ", rboQ[Tc[1]]];
Print["e2e1' is 0-weight RBO ? ", rboQ[{{0,0,0},{1,0,0},{0,0,0}}]];
Print["2Id  is 0-weight RBO ? ", rboQ[2 IdentityMatrix[3]]];

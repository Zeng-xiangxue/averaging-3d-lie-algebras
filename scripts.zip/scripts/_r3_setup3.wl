(* ============================================================
   r3 setup, part 3: structural facts + numeric sanity checks.
   ============================================================ *)
ClearAll["Global`*"];
sc = SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}];
avg[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
resid[MT_] := Max[Abs[Flatten[Table[
   lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]],
   {i,3},{j,3}]]]];

Print["== 1. the diagonal pairs force beta = 0 =="];
Print["   (2,2) component : ", Simplify[avg[2,2]],
      "   first entry = -t12^2, so over R t12 = 0"];
Print["   (3,3) component : ", Simplify[avg[3,3]],
      "   first entry = -t13^2, so over R t13 = 0"];
Print["   => T(n) subset n for every averaging operator on r3 (beta = 0 forced)"];

Print[""];
Print["== 2. numeric sanity: solutions vs. the full 27 equations =="];
tests = {
  {"scalar 3 Id3", {{3,0,0},{0,3,0},{0,0,3}}},
  {"case II: a=3, D={{1,1},{2,2}}, gamma=0", {{3,0,0},{0,1,1},{0,2,2}}},
  {"case I (mu=1,t21=1,t23=2): a=2, D={{1,2},{1/2,1}}, gamma=(1,-1/2)",
     {{2,0,0},{1,1,2},{-1/2,1/2,1}}},
  {"case I (mu=1,t21=0,t23=2): a=2, D={{1,2},{1/2,1}}, gamma=0",
     {{2,0,0},{0,1,2},{0,1/2,1}}},
  {"case I degenerate mu=0, D=0, gamma=(1,0), a=0", {{0,0,0},{1,0,0},{0,0,0}}},
  {"NEGATIVE (beta != 0): t12=1", {{0,1,0},{0,0,0},{0,0,0}}},
  {"NEGATIVE: t13=1", {{0,0,1},{0,0,0},{0,0,0}}},
  {"NEGATIVE: a=1,D=Id,gamma=(1,0)", {{1,0,0},{1,1,0},{0,0,1}}}
};
Do[Print["   ", tests[[k,1]], "   resid = ", resid[tests[[k,2]]]], {k, Length[tests]}];

Print[""];
Print["== 3. summary of the reduced problem =="];
Print["   T = [[a, 0],[gamma, D]]  (beta = 0),  residual group action:"];
Print["      a' = a,   D' = B D B^-1,   gamma' = B gamma + a v - D' v,   v free, B in GL(2)"];
Print["   invariants to normalise:  (a, conjugacy class of D, gamma mod im(D - a I))"];
Print["   case I  (t22 = t33 = mu) : a = 2 mu  or  a = mu (degenerate), det(D - aI) = ... "];
Print["   case II (a = t22+t33, t22!=t33) : 3 equations, det D = t23 t32 - t22 t33 = 0"];
Print[""];
Print["   check det D in case II:  ", 
  Simplify[(t[2,2] t[3,3] - t[2,3] t[3,2]) /. {t[2,3] t[3,2] -> 0}], "  (with eq t23 t32 = t22 t33)"];
Print["   In case II  D - aI = [[-t33, t23],[t32, -t22]] has det = ", 
  Simplify[Det[{{-t[3,3], t[2,3]}, {t[3,2], -t[2,2]}}]], " = det D = 0, so rank(D-aI) = 1."];

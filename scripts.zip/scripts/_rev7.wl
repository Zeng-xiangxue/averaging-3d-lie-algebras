(* corrected list for r(1,0): residual + pairwise non-conjugacy *)
basis = {{1,0,0},{0,1,0},{0,0,1}};
A = {{1,0},{0,0}};
br[x_, y_] := Join[{0}, x[[1]] A.y[[2 ;; 3]] - y[[1]] A.x[[2 ;; 3]]];
resid[T_] := Simplify[Union[Flatten[Table[
     br[T.basis[[i]], T.basis[[j]]] - T.br[T.basis[[i]], basis[[j]]], {i,3},{j,3}]]]];

forms = {
  {{0,0,0},{0,0,0},{0,0,0}},              (* 1  0 *)
  {{0,0,0},{0,0,0},{1,0,0}},              (* 2  e3e1' *)
  {{0,0,0},{1,0,0},{0,0,0}},              (* 3  e2e1' *)
  {{0,0,0},{1,0,0},{1,0,0}},              (* 4  e2e1'+e3e1' *)
  {{0,0,0},{0,0,0},{0,0,2}},              (* 5  mu e3e3' *)
  {{0,0,0},{0,0,1},{0,0,2}},              (* 6  e2e3'+mu e3e3'   (nu=0 slice) *)
  {{0,0,0},{0,0,0},{0,1,2}},              (* 7  e3e2'+mu e3e3' *)
  {{0,0,0},{0,0,1},{1,0,2}},              (* 8  e2e3'+e3e1'+mu e3e3' *)
  {{0,0,0},{1,0,0},{0,0,2}},              (* 9  e2e1'+mu e3e3' *)
  {{1,0,0},{0,1,0},{0,0,1}},              (* 10 aId *)
  {{1,0,0},{0,1,0},{1,0,1}},              (* 11 aId+e3e1' *)
  {{1,0,0},{0,0,0},{0,0,0}},              (* 12 a e1e1' *)
  {{1,0,0},{0,0,0},{0,0,1}},              (* 13 diag(a,0,a)+e3e1' *)
  {{1,0,0},{0,0,0},{0,0,2}},              (* 14 diag(a,0,mu) *)
  {{1,0,0},{0,1,0},{0,0,2}},              (* 15 diag(a,a,mu) *)
  {{1,0,0},{0,0,0},{2,0,3}}               (* 16 new: e2e3'+nu e3e1'+mu e3e3' *)
  };

B = {{p, 0}, {0, s}};
phi = {{1,0,0},{w1,B[[1,1]],B[[1,2]]},{w2,B[[2,1]],B[[2,2]]}};
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi.T1.Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z*p*s}], {p, s, w1, w2, z},
        MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];

sol = Select[Range[Length[forms]], resid[forms[[#]]] === {0} &];
Print["solutions among candidates: ", sol];
bad = {};
Do[If[MemberQ[sol,i] && MemberQ[sol,j] && !conjQ[forms[[i]], forms[[j]]], AppendTo[bad, {i,j}]],
  {i, Length[forms]}, {j, i+1, Length[forms]}];
Print["conjugate pairs: ", bad];

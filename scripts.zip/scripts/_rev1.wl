(* A5: check BD = a D B for D = C_c ; and verify the mirror component for c = 0 *)
B = {{b11, b12}, {b21, b22}};
vars = {b11, b12, b21, b22, a};

Do[
  D0 = {{cc, -1}, {1, cc}};
  Print["--- D = C_", cc, " : solutions of B.D = a D.B (det B != 0) ---"];
  sol = Reduce[Flatten[B.D0 - a D0.B] == 0 && Det[B] != 0, vars, Reals];
  Print[sol];
  ,
  {cc, {0, 1, 2}}
  ];

Print[""];
Print["--- c = 0 : is phi = (-1, {{1,0},{0,-1}}) an automorphism of e(2)? ---"];
A0 = {{0, -1}, {1, 0}};
basis = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
br[x_, y_] := Join[{0}, x[[1]] A0.y[[2 ;; 3]] - y[[1]] A0.x[[2 ;; 3]]];
phi = {{-1, 0, 0}, {0, 1, 0}, {0, 0, -1}};
Print["automorphism residual = ",
  Simplify[Union[Flatten[Table[phi.br[basis[[i]], basis[[j]]] -
        br[phi.basis[[i]], phi.basis[[j]]], {i, 3}, {j, 3}]]]]];

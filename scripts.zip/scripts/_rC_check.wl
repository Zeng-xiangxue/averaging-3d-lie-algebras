(* Is the paper's r(c) classification complete?  Check the a = 0, rank M = 1 case. *)
ClearAll["Global`*"];
cc = 1;
A = {{cc, -1}, {1, cc}};
br[x_, y_] := Join[{0}, x[[1]] A . y[[2 ;; 3]] - y[[1]] A . x[[2 ;; 3]]];
e = IdentityMatrix[3];
resid[T_] := Max[Abs[Flatten[Table[
   br[T.e[[i]], T.e[[j]]] - T.br[T.e[[i]], e[[j]]], {i, 3}, {j, 3}]]]];
(* candidate:  a = 0, gamma = e2-direction, M = rank 1  *)
Tnew = {{0, 0, 0}, {1, 1, -1}, {0, 0, 0}};
Print["residual of Tnew  = ", resid[Tnew]];
Print["  (rank T, trace T) = ", {MatrixRank[Tnew], Tr[Tnew]}];
(* its image and kernel *)
Print["  im  = ", NullSpace[Transpose[Tnew]]];
Print["  ker = ", NullSpace[Tnew]];

(* conjugacy test inside Aut(r(c)) :  B = p {{1,-t},{t,1}} *)
phi = {{1, 0, 0}, {w1, p, -p t}, {w2, p t, p}};
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi . T1 . Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p}], {p, t, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
targets = {{"0", {{0,0,0},{0,0,0},{0,0,0}}},
           {"e2e1'", {{0,0,0},{1,0,0},{0,0,0}}},
           {"2 Id", 2 IdentityMatrix[3]},
           {"2 e1e1'", {{2,0,0},{0,0,0},{0,0,0}}}};
Do[Print["  Tnew ~ ", targets[[k,1]], " ?  ", conjQ[Tnew, targets[[k,2]]]], {k, 4}];

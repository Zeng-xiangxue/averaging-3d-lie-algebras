(* ============================================================
   r3 verification pass:
   (1) the beta=0 ideal equals < D gamma , D^2 - a D >;
   (2) the six predicted classes: residual 0 and pairwise inequivalent;
   (3) im(aI - D) = ker D for D^2 = a D  (the gamma-killing mechanism).
   ============================================================ *)
ClearAll["Global`*"];
sc = SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}]; vars = Flatten[T];
avg[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
eqs0 = Select[DeleteDuplicates[Simplify[
     Flatten[Table[avg[i,j], {i,3},{j,3}]] /. {t[1,2] -> 0, t[1,3] -> 0}]], # =!= 0 &];
vars0 = DeleteCases[vars, t[1,2] | t[1,3]];
Dm = {{t[2,2], t[2,3]}, {t[3,2], t[3,3]}}; gam = {t[2,1], t[3,1]}; aa = t[1,1];
newEqs = Select[DeleteDuplicates[Flatten[{Dm . gam, Flatten[Dm . Dm - aa Dm]}]], # =!= 0 &];
Print["== 1. ideal comparison =="];
Print["   beta=0 system : ", Length[eqs0], " equations"];
Print["   D gamma = 0, D^2 = a D : ", Length[newEqs], " equations  -> ", newEqs];
gb0 = GroebnerBasis[eqs0, vars0, MonomialOrder -> DegreeReverseLexicographic];
gbN = GroebnerBasis[newEqs, vars0, MonomialOrder -> DegreeReverseLexicographic];
mem[g_, gb_] := PolynomialReduce[g, gb, vars0, MonomialOrder -> DegreeReverseLexicographic][[2]] === 0 ||
   Simplify[PolynomialReduce[g, gb, vars0, MonomialOrder -> DegreeReverseLexicographic][[2]]] === 0;
Print["   every eq of beta=0 lies in <D gamma, D^2 - aD> ?  ", And @@ (mem[#, gbN] & /@ eqs0)];
Print["   every eq of <D gamma, D^2-aD> lies in beta=0 ideal ? ", And @@ (mem[#, gb0] & /@ newEqs)];

Print[""];
Print["== 2. the six predicted classes =="];
forms = <|
  "1  T=0"                  -> {{0,0,0},{0,0,0},{0,0,0}},
  "2  e2 e1^T"              -> {{0,0,0},{1,0,0},{0,0,0}},
  "3  e2 e3^T"              -> {{0,0,0},{0,0,1},{0,0,0}},
  "4  a e1 e1^T (a=2)"      -> {{2,0,0},{0,0,0},{0,0,0}},
  "5  diag(a,a,0) (a=3)"    -> {{3,0,0},{0,3,0},{0,0,0}},
  "6  a Id3 (a=5)"          -> {{5,0,0},{0,5,0},{0,0,5}}
|>;
resid[MT_] := Max[Abs[Flatten[Table[
   lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]],
   {i,3},{j,3}]]]];
Do[Print["   ", k, "   resid = ", resid[forms[k]]], {k, Keys[forms]}];

Print[""];
Print["== 3. pairwise inequivalence (phi T_i = T_j phi, det B != 0 -> unit ideal) =="];
Bm = {{b11,b12},{b21,b22}}; vv = {v1,v2};
phi = {{1,0,0},{vv[[1]], Bm[[1,1]], Bm[[1,2]]},{vv[[2]], Bm[[2,1]], Bm[[2,2]]}};
noConj[Ti_, Tj_] := Module[{sys, gb},
  sys = Flatten[phi . Ti - Tj . phi];
  gb = DeleteCases[GroebnerBasis[Join[sys, {Det[Bm] ss - 1}],
        {b11,b12,b21,b22,v1,v2,ss}, MonomialOrder -> DegreeReverseLexicographic], 0];
  gb === {1}];
keys = Keys[forms];
Do[If[i < j,
   Print["   ", keys[[i]], "  vs  ", keys[[j]], "   inequivalent: ",
     noConj[forms[keys[[i]]], forms[keys[[j]]]]]],
  {i, 6}, {j, 6}];
Print["   control (same class, must be conjugate): ", noConj[forms[keys[[3]]], forms[keys[[3]]]]];

Print[""];
Print["== 4. gamma-killing mechanism: im(aI - D) = ker D when D^2 = a D =="];
Do[
  aa0 = RandomReal[{-2,2}];
  Dd = RandomReal[{-2,2},{2,2}];
  (* force D^2 = a D by taking  D = rank-1  or  scalar *)
  If[k == 1, Dd = aa0 IdentityMatrix[2]];
  If[k == 2, Dd = Outer[Times, RandomReal[{-2,2},2], RandomReal[{-2,2},2]]; aa0 = Tr[Dd]];
  If[k == 3, Dd = {{0,1},{0,0}}; aa0 = 0];
  chk = Simplify[Dd . Dd - aa0 Dd];
  rankA = MatrixRank[Dd - aa0 IdentityMatrix[2]];
  nullD = 2 - MatrixRank[Dd];
  Print["   k=", k, "  ||D^2-aD|| = ", Max[Abs[Flatten[chk]]],
        "   rank(aI-D) = ", rankA, "   dim ker D = ", nullD,
        "   equal? ", rankA == nullD],
  {k, 3}];

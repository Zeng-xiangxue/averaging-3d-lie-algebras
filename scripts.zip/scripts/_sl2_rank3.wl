(* ============================================================
   sl(2,R): (a) rank<=1 forced: for each K-type of ker T, the ideal
       <eqs, T u = 0> forces all nine 2x2 minors to vanish (Rabinowitsch);
   (b) the six classes: residuals and invariants.
   ============================================================ *)
ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
admat[u_] := Table[lie[sc, u, unit[[j]]][[i]], {i,3},{j,3}];
KK = Table[Tr[admat[unit[[i]]] . admat[unit[[j]]]], {i,3}, {j,3}];
T = Array[t,{3,3}]; vars = Flatten[T];
comp[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
eqs = Select[DeleteDuplicates[Flatten[Table[comp[i,j], {i,3},{j,3}]]], # =!= 0 &];
resid[MT_] := Max[Abs[Flatten[Table[lie[sc, MT[[All,i]], MT[[All,j]]] -
    MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
minor = Flatten[Table[Det[T[[{i1,i2}, {j1,j2}]]],
   {i1,1,2}, {i2,i1+1,3}, {j1,1,2}, {j2,j1+1,3}]];

Print["== (a) rank 2 is excluded =="];
kers = {{"null   u=e1       ", {1,0,0}}, {"spacelike u=e2   ", {0,1,0}},
        {"timelike u=e1-e3", {1,0,-1}}};
Do[
  u0 = kers[[k,2]];
  Iu = Join[eqs, Flatten[T . u0]];
  gb = TimeConstrained[GroebnerBasis[Iu, vars, MonomialOrder -> DegreeReverseLexicographic],
       180, "TO"];
  If[gb === "TO", Print["   ", kers[[k,1]], ": TIMEOUT"],
   res = Table[Module[{g2},
      g2 = TimeConstrained[GroebnerBasis[Join[Iu, {minor[[m]] zz - 1}], Append[vars, zz],
            MonomialOrder -> DegreeReverseLexicographic], 180, "TO"];
      If[g2 === "TO", "TO", DeleteCases[g2, 0] === {1}]], {m, Length[minor]}];
   Print["   ", kers[[k,1]], ": #minors = ", Length[minor],
         "   all forced to vanish? ", And @@ (res /. "TO" -> False),
         "   (", Count[res, True], "/", Length[res], " True)"]],
  {k, Length[kers]}];

Print[""];
Print["== (b) the six classes =="];
vSp = {0,1,0}; vTi = {1,0,-1}; vNu = {1,0,0};
mk[v_] := Outer[Times, v, KK . v];
cands = {
  {"1  0", ConstantArray[0,{3,3}]},
  {"2  Id (lambda=1)", unit},
  {"3  e2 e2^T", mk[{0,1,0}]/2},
  {"4  (e1-e3)(e1-e3)^T", mk[{1,0,-1}]/4},
  {"5  +e1 e3^T", mk[{1,0,0}]/4},
  {"6  -e1 e3^T", -mk[{1,0,0}]/4}
};
Do[M0 = cands[[k,2]];
   Print["   ", cands[[k,1]], "   resid = ", resid[M0],
     "   rank = ", MatrixRank[M0], "   tr = ", Tr[M0],
     "   K-type of im T (if rank 1): ",
     If[MatrixRank[M0] == 1,
       With[{w = First[Select[Transpose[M0], Norm[#] > 10^-9 &]]},
         Sign[Chop[w . KK . w]]], "-"]],
  {k, Length[cands]}];
Print[""];
Print["   invariant table (rank, tr, K-type, sign for null):"];
Print["   the four available invariants separate the six representatives: ",
  Length[DeleteDuplicates[Table[
    With[{M0 = cands[[k,2]], r = MatrixRank[cands[[k,2]]]},
     {r, Tr[M0], If[r == 1, Sign[Chop[First[Select[Transpose[M0], Norm[#] > 10^-9 &]] .
        KK . First[Select[Transpose[M0], Norm[#] > 10^-9 &]]]], 0],
      If[r == 1 && Abs[Tr[M0]] < 10^-9, Sign[Total[Select[Flatten[M0], Abs[#] > 10^-9 &]]], 0]}],
    {k, Length[cands]}]]] == Length[cands]];

(* referee pre-check : (i) mirror action on the D_t family ; (ii) second component on r(c)=e(2) *)
ClearAll["Global`*"];
R = {{0, q}, {r, 0}};
Dt = {{t, u}, {v, t}};
Print["(i) R D_t R^{-1} = ", Simplify[R . Dt . Inverse[R]]];
Print["    equals D_t ?  ", Simplify[R . Dt . Inverse[R] - Dt] === {{0,0},{0,0}}];
Print["    numeric t=1,u=1/2,v=2,q=r=1 : ", R . Dt . Inverse[R] /. {t->1,u->1/2,v->2,q->1,r->1}];

(* (ii) e(2) : [e1,e2]=e3, [e1,e3]=-e2 *)
A0 = {{0, -1}, {1, 0}};
br[x_, y_] := Join[{0}, x[[1]] A0 . y[[2 ;; 3]] - y[[1]] A0 . x[[2 ;; 3]]];
e = IdentityMatrix[3];
resid[T_] := Simplify[Union[Flatten[Table[br[T.e[[i]], T.e[[j]]] - T.br[T.e[[i]], e[[j]]], {i,3},{j,3}]]]];
phim[p_, q_, w1_, w2_] := {{-1, 0, 0}, {w1, p, q}, {w2, q, -p}};
Print[""];
Print["(ii) mirror phi is an automorphism?  max |[phi x, phi y] - phi[x,y]| = ",
  Max[Abs[Flatten[Table[br[phim[p,q,w1,w2] . e[[i]], phim[p,q,w1,w2] . e[[j]]] -
      phim[p,q,w1,w2] . br[e[[i]], e[[j]]], {i,3},{j,3}]]]]];
E11 = {{1,0,0},{0,0,0},{0,0,0}}; E21r = {{0,0,0},{1,0,0},{0,0,0}};
forms = {0 E11, E21r, 2 IdentityMatrix[3], 2 E11};
lab = {"0", "e21", "2 Id", "2 e11"};
ph = {{1,0,0},{w1,p,0},{w2,0,s}};
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[ph.T1.Inverse[ph] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p s}], {p, s, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
Do[Module[{Timg},
   Timg = Simplify[phim[p0, q0, w10, w20] . forms[[k]] . Inverse[phim[p0, q0, w10, w20]] /. {p0->1, q0->1, w10->0, w20->0}];
   Print["    mirror image of ", lab[[k]], " = ", Timg, "   conjugate back (Aut0)? ",
     conjQ[Timg, forms[[k]]]]], {k, 4}];

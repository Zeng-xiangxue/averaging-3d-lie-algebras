(* ============================================================
   sl(2,R): check the two suggestions.
   (a) defect(T + c Id) = defect(T) + c ( [x,Ty] - T[x,y] )   -- no c^2 term
       and the theorem "s = tr T / 3 != 0  =>  T = s Id".
   (b) invariants of the traceless self-adjoint part S:
       sigma2 = -tr(S^2)/2,  det S,  discriminant of  l^3 + sigma2 l - det.
   ============================================================ *)
ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
defect[MT_, u_, v_] := lie[sc, MT . u, MT . v] - MT . lie[sc, MT . u, v];
resid[MT_] := Max[Abs[Flatten[Table[defect[MT, unit[[i]], unit[[j]]], {i,3},{j,3}]]]];

Print["== (a1) the translation formula =="];
T0 = Array[u, {3,3}]; xv = {x1,x2,x3}; yv = {y1,y2,y3};
lhs = lie[sc, (T0 + cc IdentityMatrix[3]) . xv, (T0 + cc IdentityMatrix[3]) . yv];
rhs = (T0 + cc IdentityMatrix[3]) . lie[sc, (T0 + cc IdentityMatrix[3]) . xv, yv];
diff = Simplify[lhs - rhs];
claimed = Simplify[defect[T0, xv, yv] + cc (lie[sc, xv, T0 . yv] + lie[sc, T0 . xv, yv]
     - T0 . lie[sc, xv, yv]) + cc^2 lie[sc, xv, yv]];
correct = Simplify[defect[T0, xv, yv] + cc (lie[sc, xv, T0 . yv] - T0 . lie[sc, xv, yv])];
Print["   their formula (with c^2[x,y] and [Tx,y] term) matches? ", Simplify[diff - claimed] === {0,0,0}];
Print["   correct formula  defect(T+cI) = defect(T) + c([x,Ty]-T[x,y]) matches? ",
  Simplify[diff - correct] === {0,0,0}];
Print["   sanity: T = 0 -> cI is a solution; their formula would give ", 
  Simplify[claimed /. Thread[Flatten[T0] -> 0]]];

Print[""];
Print["== (a2) is 'tr T != 0 => T scalar' true? =="];
T = Array[t,{3,3}]; vars = Flatten[T];
eqs = Select[DeleteDuplicates[Flatten[Table[defect[T, unit[[i]], unit[[j]]], {i,3},{j,3}]]], # =!= 0 &];
trT = Sum[t[i,i], {i,3}];
(* "tr T != 0 forces q = 0" is tested as: <eqs, trT*ss-1, q*zz-1> is the unit ideal *)
forces[qq_] := Module[{gb},
  gb = TimeConstrained[GroebnerBasis[Join[eqs, {trT ss - 1, qq zz - 1}], Join[vars, {ss, zz}],
        MonomialOrder -> DegreeReverseLexicographic], 180, "TO"];
  If[gb === "TO", "TIMEOUT", DeleteCases[gb, 0] === {1}]];
offdiag = {{1,2},{1,3},{2,1},{2,3},{3,1},{3,2}};
Do[Print["   tr T != 0 forces t", offdiag[[k]], " = 0 ?  ",
    forces[t[offdiag[[k,1]], offdiag[[k,2]]]]], {k, Length[offdiag]}];
Print["   tr T != 0 forces t11 = t22 ? ", forces[t[1,1] - t[2,2]]];
Print["   tr T != 0 forces t11 = t33 ? ", forces[t[1,1] - t[3,3]]];
Print["   control (no trace condition): is t12 != 0 possible? ",
  Module[{gb}, gb = TimeConstrained[GroebnerBasis[Join[eqs, {t[1,2] zz - 1,
        t[1,1] z3 - 1}], Join[vars, {zz, z3}], MonomialOrder -> DegreeReverseLexicographic],
      180, "TO"];
   If[gb === "TO", "TIMEOUT", DeleteCases[gb, 0] === {1}]]];

Print[""];
Print["== (a3) non-scalar solutions with s = 0 exist =="];
Print["   e3e1^T : resid = ", resid[{{0,0,0},{0,0,0},{1,0,0}}],
      ",  tr = ", Tr[{{0,0,0},{0,0,0},{1,0,0}}]];
Print["   e3e1^T + 2 Id : resid = ", resid[{{0,0,0},{0,0,0},{1,0,0}} + 2 IdentityMatrix[3]],
      "   (s != 0, expected non-zero)"];

Print[""];
Print["== (b) invariants of the traceless self-adjoint part =="];
admat[u_] := Table[lie[sc, u, unit[[j]]][[i]], {i,3},{j,3}];
KK = Table[Tr[admat[unit[[i]]] . admat[unit[[j]]]], {i,3},{j,3}];
Ki = Inverse[KK];
star[M_] := Ki . Transpose[M] . KK;
Do[
  M0 = RandomReal[{-2,2},{3,3}];
  S = (M0 + star[M0])/2; S = S - Tr[S]/3 IdentityMatrix[3];
  sig2 = -Tr[S . S]/2; detS = Det[S];
  disc = -4 sig2^3 - 27 detS^2;
  ev = Eigenvalues[S // N];
  nreal = Length[Select[ev, Abs[Im[#]] < 10^-8 &]];
  Print["   trS = ", Round[Tr[S],10^-10], "  sigma2 = ", Round[sig2,0.01],
        "  det = ", Round[detS,0.01], "  disc = ", Round[disc,0.01],
        "  #real ev = ", nreal, "   type = ",
        Which[disc < -10^-9, "elliptic", disc > 10^-9, "hyperbolic", True, "parabolic"]],
  {4}];

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
okv[R_] := AllTrue[Flatten[avgDef[R]], (Simplify[#] === 0) &];
TAB[A_, Bb_, Cc_, Dm_] := ArrayFlatten[{{A, Bb}, {Cc, Dm}}];
E1 = {1, 0, 0}; Av = 3 Outer[Times, E1, E1]; Bv = 5 Outer[Times, E1, E1];
P[a_, b_] := Outer[Times, {E1, {0, 1, 0}, {0, 0, 1}}[[a]], {E1, {0, 1, 0}, {0, 0, 1}}[[b]]];
Print["Step 2b claim: with A = lam e1e1^T and B != 0, rank C >= 2 is impossible."];
Do[Print["  C = diag(1,1,0) (rank 2), D = ", d, " : ",
   okv[TAB[Av, Bv, DiagonalMatrix[{1, 1, 0}], d]]],
  {d, {Z3, 3 Outer[Times, E1, E1], DiagonalMatrix[{0, 3, 3}], 4 e3}}];
Print["  C = diag(1,2,3) (rank 3), D = 3 e1e1^T : ",
  okv[TAB[Av, Bv, DiagonalMatrix[{1, 2, 3}], 3 Outer[Times, E1, E1]]]];
Print["  C = e1e1^T (rank 1), D = 3 e1e1^T    : ",
  okv[TAB[Av, Bv, Outer[Times, E1, E1], 3 Outer[Times, E1, E1]]]];
Print["  C = e1e2^T (rank 1, not symmetric)   : ",
  okv[TAB[Av, Bv, P[1, 2], 3 Outer[Times, E1, E1]]]];

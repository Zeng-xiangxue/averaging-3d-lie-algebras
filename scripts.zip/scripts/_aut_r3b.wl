(* ============================================================
   Explicit Aut(r3), Aut(r3,lam).   r3,lam: [e1,e2]=e2, [e1,e3]=lam e3.
   Other agent's claim: Aut(r3) = {phi(e1)=e1+v, phi|_n in GL(2)}  (dim 6,
   no det coupling); Aut(r3,lam) for lam != 1 = diagonal subgroup (dim 4).
   Test both, and check the special value lam = -1.
   ============================================================ *)
ClearAll["Global`*"];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
mkCF[lv_] := Module[{B = SparseArray[{{2,1,2} -> 1, {3,1,3} -> lv}, {3,3,3}]},
   Normal[B - Transpose[B, {1,3,2}]]];

autoSys[lv_] := Module[{cf, A, cols, vars, sys},
  cf = mkCF[lv];
  A = Array[ap, {3,3}]; cols = Table[A[[All,i]], {i,3}]; vars = Flatten[A];
  sys = Select[Flatten[Table[
     lie[cf, cols[[i]], cols[[j]]] - Sum[cf[[k,i,j]] cols[[k]], {k,3}],
     {i,3}, {j,3}]], # =!= 0 &];
  {vars, sys, A}];

Print["== structural facts forced by the automorphism equations =="];
Do[
  {vars, sys, A} = autoSys[lv];
  radQ[q_] := Module[{gb},
    gb = DeleteCases[GroebnerBasis[Join[sys, {1 - yv q}], Join[vars, {yv}],
         MonomialOrder -> DegreeReverseLexicographic], 0];
    gb === {1}];
  Print["lam = ", lv, " :  #eq = ", Length[sys]];
  Print["    A[[1,2]] = 0 forced? ", radQ[A[[1,2]]],
        "    A[[1,3]] = 0 forced? ", radQ[A[[1,3]]]];
  Print["    (A[[1,1]]-1) = 0 forced? ", radQ[A[[1,1]] - 1],
        "    (A[[1,1]]-1)(A[[1,1]]+1) = 0 forced? ", radQ[(A[[1,1]]-1)(A[[1,1]]+1)]],
  {lv, {1, 2, -1, 3}}];

Print[""];
Print["== explicit automorphism group (det M != 0 included) =="];
Do[
  {vars, sys, A} = autoSys[lv];
  sol = Solve[Join[Thread[sys == 0], {Det[A] tt - 1 == 0}], Join[vars, {tt}]];
  Print["lam = ", lv, " : #branches = ", Length[sol]];
  Do[Print["   branch ", i, " : ", Simplify[sol[[i]]]], {i, Length[sol]}],
  {lv, {2, -1, 1}}];

Print[""];
Print["== check: phi(e1) = e1 + v, phi|_n = B really are automorphisms =="];
Do[
  cf = mkCF[lv]; v = {v2, v3}; B = {{b22, b23},{b32, b33}};
  A = {{1, 0, 0}, {v[[1]], B[[1,1]], B[[1,2]]}, {v[[2]], B[[2,1]], B[[2,2]]}};
  cols = Table[A[[All,i]], {i,3}];
  chk = Simplify[Table[lie[cf, cols[[i]], cols[[j]]] -
        Sum[cf[[k,i,j]] cols[[k]], {k,3}], {i,3}, {j,3}]];
  Print["lam = ", lv, " : all automorphism identities vanish? ", chk == 0*chk],
  {lv, {1, 2, -1, 3}}];

Print[""];
Print["== lam = -1, extra component: phi(e1) = -e1 + v, phi(e2)=q e3, phi(e3)=r e2 =="];
cf = mkCF[-1];
A = {{-1, 0, 0}, {v2, 0, r}, {v3, q, 0}};
cols = Table[A[[All,i]], {i,3}];
chk = Simplify[Table[lie[cf, cols[[i]], cols[[j]]] -
      Sum[cf[[k,i,j]] cols[[k]], {k,3}], {i,3}, {j,3}]];
Print["   identities vanish? ", chk == 0*chk, "   Det = ", Simplify[Det[A]]];

(* Clean verification: averaging operators on the six 3-dim real Lie algebras *)
(* one-term averaging: [T(x),T(y)] = T([T(x),y]) *)
(* structure constants C[[k,i,j]] : [e_i,e_j] = sum_k C[[k,i,j]] e_k, FULL antisymmetrised *)

ClearAll["Global`*"];

(* --- structure constants, full (antisymmetry included) --- *)
sc = Association[
  "a3"   -> Table[0, {3}, {3}, {3}],
  "h1"   -> SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}],
  "r3"   -> SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}],
  "r3lam"-> SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->la, {3,3,1}->-la}, {3,3,3}],
  "sl2"  -> SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}],
  "so3"  -> SparseArray[{{3,1,2}->1, {3,2,1}->-1, {2,1,3}->-1, {2,3,1}->1, {1,2,3}->1, {1,3,2}->-1}, {3,3,3}]
];

T = Array[t, {3, 3}]; vars = Flatten[T];
fs = {t[1,2]-t[2,1], t[1,3]-t[3,1], t[2,3]-t[3,2]};
unit = Table[UnitVector[3, i], {i, 3}];

lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
Tv[v_] := Table[Sum[t[i,j] v[[j]], {j,3}], {i,3}];
avg[cf_, i_, j_] := lie[cf, Tv[unit[[i]]], Tv[unit[[j]]]] - Tv[lie[cf, Tv[unit[[i]]], unit[[j]]]];

Do[
  cf = sc[al];
  eq = Select[DeleteDuplicates[Flatten[Table[avg[cf, i, j], {i,3}, {j,3}]]], # =!= 0 &];
  If[Length[eq] == 0,
    Print[al, "  : equations identically zero -> EVERY linear map is averaging (abelian case)"],
    (* consistency test: non-symmetric solution exists iff eqs + {f_m - 1} consistent *)
    res = Table[
      g = TimeConstrained[GroebnerBasis[Join[eq, {fs[[m]] - 1}], vars, MonomialOrder -> DegreeReverseLexicographic], 90, "TO"];
      If[g === "TO", "TO", g === {1}], {m, 3}];
    Print[al, "  : #eq=", Length[eq],
      "   (f1-1,f2-1,f3-1) -> {1}? ", res,
      "   => all real/complex solutions symmetric? ", And @@ (res === True)];
  ],
  {al, {"a3","h1","r3","r3lam","sl2","so3"}}];

(* --- dimensions of derivation algebras (Aut is a proper subgroup of GL(3) iff dim Der < 9) --- *)
Print["--- dim Der(g) ---"];
Do[
  cf = sc[al];
  dd = Array[ddm, {3, 3}];
  derEqs = Flatten[Table[
    Sum[ddm[[p,i]] cf[[k,p,j]] + ddm[[p,j]] cf[[k,i,p]] - cf[[p,i,j]] ddm[[k,p]], {p,3}] == 0,
    {k,3}, {i,3}, {j,3}]];
  Print[al, " : dim Der = ", 9 - MatrixRank[Table[Coefficient[derEqs[[r]], ddm[a,b]], {r,Length[derEqs]}, {a,3}, {b,3}]]],
  {al, {"a3","h1","r3","r3lam","sl2","so3"}}];

(* completeness probe for r(1,0): are random solutions conjugate to one of the listed forms? *)
basis = {{1,0,0},{0,1,0},{0,0,1}};
A = {{1,0},{0,0}};
br[x_, y_] := Join[{0}, x[[1]] A.y[[2 ;; 3]] - y[[1]] A.x[[2 ;; 3]]];
residV[T_] := Flatten[Table[br[T.basis[[i]], T.basis[[j]]] - T.br[T.basis[[i]], basis[[j]]], {i,3},{j,3}]];

forms = {
  {{0,0,0},{0,0,0},{0,0,0}}, {{0,0,0},{0,0,0},{1,0,0}}, {{0,0,0},{1,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{1,0,0}}, {{0,0,0},{0,0,0},{0,0,2}}, {{0,0,0},{0,0,1},{0,0,2}},
  {{0,0,0},{0,0,0},{0,1,2}}, {{0,0,0},{0,0,1},{1,0,2}}, {{0,0,0},{1,0,0},{0,0,2}},
  {{1,0,0},{0,1,0},{0,0,1}}, {{1,0,0},{0,1,0},{1,0,1}}, {{1,0,0},{0,0,0},{0,0,0}},
  {{1,0,0},{0,0,0},{0,0,2}}, {{1,0,0},{0,1,0},{0,0,2}}, {{1,0,1},{0,0,0},{0,0,1}},
  {{1,0,0},{0,0,0},{1,0,1}}
  };

mkphiz[p_, s_, w1_, w2_] := {{1, 0, 0}, {w1, p, 0}, {w2, 0, s}};
cost[T_, N_, pars_] := Module[{ph, M},
  ph = mkphi[pars[[1]], pars[[2]], pars[[3]], pars[[4]]];
  M = ph.T.Inverse[ph] - N;
  Total[Flatten[M]^2]];

dist[T_, N_] := Module[{best = Infinity, r, seed},
  SeedRandom[7];
  Do[seed = {RandomReal[{-3,3}], RandomReal[{0.2,3}](-1)^RandomInteger[], RandomReal[{-3,3}], RandomReal[{-3,3}]};
    r = Quiet@FindMinimum[cost[T, N, {p, s, w1, w2}], {{p, seed[[1]]}, {s, seed[[2]]}, {w1, seed[[3]]}, {w2, seed[[4]]}}];
    best = Min[best, r[[1]]], {6}];
  Sqrt[best]];

(* random solutions from branch  beta2 != 0, a = M11 = 0, gamma1 = M21 = 0 *)
SeedRandom[11];
Do[
  b2 = 1; M12 = RandomReal[{-2,2}]; M22 = RandomReal[{-2,2}]; g2 = RandomReal[{-2,2}];
  T = {{0, 0, b2}, {0, 0, M12}, {g2, 0, M22}};
  If[Max[Abs[residV[T]]] > 10^-12, Print["NOT A SOLUTION: ", T]; Continue[]];
  d = Table[dist[T, forms[[k]]], {k, Length[forms]}];
  Print["T = ", MatrixForm[T], "  minimal distances = ", Round[d, 4]];
  Print["     closest form : ", Position[d, Min[d]][[1, 1]], "  (0 = conjugate)"];
  ,
  {6}];

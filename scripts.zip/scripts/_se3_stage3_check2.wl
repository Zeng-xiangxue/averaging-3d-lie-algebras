(* Part 2: A = diag(lam,0,0) case + remark consistency (run after part 1) *)
ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
eh = e6[[1 ;; 3]]; ef = e6[[4 ;; 6]];
blk[A_, B_, Cc_, Dm_] := ArrayFlatten[{{A, B}, {Cc, Dm}}];
avgRes[R_] := Max[Abs[Flatten[Table[
     br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]],
     {i, 6}, {j, 6}]]]];
ok[R_] := avgRes[R] < 10.^-10;

Print["=== 4.  A = diag(lam,0,0) : solve symbolically ==="];
AA = Array[aa, {3, 3}]; BB = Array[bb, {3, 3}];
Ah[i_] := AA . eh[[i]][[1 ;; 3]]; Bv[j_] := BB . ef[[j]][[4 ;; 6]];
g2 = Flatten[Table[Cross[Ah[i], Bv[j]] - BB . Cross[Ah[i], ef[[j]][[4 ;; 6]]], {i, 3}, {j, 3}]];
g3 = Flatten[Table[Cross[Bv[i], Ah[j]] - AA . Cross[Bv[i], eh[[j]][[1 ;; 3]]], {i, 3}, {j, 3}]];
g4 = Flatten[Table[Cross[Bv[i], Bv[j]] - BB . Cross[Bv[i], ef[[j]][[4 ;; 6]]], {i, 3}, {j, 3}]];
gD = Select[DeleteDuplicates[Expand[Flatten[{g2, g3, g4}] /.
     Thread[Flatten[AA] -> Flatten[DiagonalMatrix[{lam, 0, 0}]]]]], # =!= 0 &];
Print["  distinct conditions: ", Length[gD]];
solD = TimeConstrained[Solve[gD == 0, Flatten[BB]], 180, "TO"];
Print["  Solve head: ", Head[solD]];
If[Head[solD] === List, Do[Print["  branch ", k, ": ", Simplify[solD[[k]]]], {k, Length[solD]}]];

Print["  numeric spot checks with A = diag(2,0,0):"];
chk2[n_, M_] := Print["    ", n, " : ", ok[blk[DiagonalMatrix[{2, 0, 0}], M, Z3, Z3]]];
chk2["B = 3 e1 e1^T      ", 3 Outer[Times, {1, 0, 0}, {1, 0, 0}]];
chk2["B = 0              ", Z3];
chk2["B = 3 Id           ", 3 e3];
chk2["B = e1 e2^T        ", Outer[Times, {1, 0, 0}, {0, 1, 0}]];
chk2["B = e2 e2^T        ", Outer[Times, {0, 1, 0}, {0, 1, 0}]];
chk2["B = e1(e1+e2)^T    ", Outer[Times, {1, 0, 0}, {1, 1, 0}]];

Print["=== 5.  remark consistency: so(3) averaging vs Rota-Baxter ==="];
Av = Array[aa, {3, 3}];
eqA = DeleteCases[Expand[Flatten[Table[
     Cross[Av . eh[[i]][[1 ;; 3]], Av . eh[[j]][[1 ;; 3]]] -
      Av . Cross[Av . eh[[i]][[1 ;; 3]], eh[[j]][[1 ;; 3]]],
     {i, 3}, {j, 3}]]], 0];
eqR = DeleteCases[Expand[Flatten[Table[
     Cross[Av . eh[[i]][[1 ;; 3]], Av . eh[[j]][[1 ;; 3]]] -
      Av . (Cross[Av . eh[[i]][[1 ;; 3]], eh[[j]][[1 ;; 3]]] +
        Cross[eh[[i]][[1 ;; 3]], Av . eh[[j]][[1 ;; 3]]]),
     {i, 3}, {j, 3}]]], 0];
f = aa[1, 2] - aa[2, 1];
chkI[tag_, eqs_] := Module[{gb, r1, r2, r3},
  gb = GroebnerBasis[eqs, Flatten[Av]];
  r1 = PolynomialReduce[f, gb, Flatten[Av]];
  r2 = PolynomialReduce[f^2, gb, Flatten[Av]];
  r3 = GroebnerBasis[Append[eqs, f - 1], Flatten[Av]];
  Print["  ", tag, ": GB size ", Length[gb], " ; f in ideal? ", r1[[2]] === 0,
   " ; f^2 in ideal? ", r2[[2]] === 0,
   " ; eqs+(f-1) -> {1}? ", r3 === {1}]];
chkI["averaging   ", eqA];
chkI["Rota-Baxter ", eqR];
Print["Done."];

(* r(J):  how many classes sit in the a = 0 , M != 0  branch ? *)
ClearAll["Global`*"];
AJ = {{1, 1}, {0, 1}};
brJ[x_, y_] := Join[{0}, x[[1]] AJ . y[[2 ;; 3]] - y[[1]] AJ . x[[2 ;; 3]]];
e = IdentityMatrix[3];
resJ[T_] := Max[Abs[Flatten[Table[brJ[T.e[[i]], T.e[[j]]] - T.brJ[T.e[[i]], e[[j]]], {i,3},{j,3}]]]];
cands = {
  {"u=e3        (M = lam e3(e2-e3)^T)", {{0,0,0},{0,0,0},{0,1,-1}}},
  {"u=e2-e3     (M = c (e2-e3)e2^T)",  {{0,0,0},{0,1,0},{0,-1,0}}},
  {"u=(1,1)     (M = (1,1)(1,-2)^T)",  {{0,0,0},{0,1,-2},{0,1,-2}}},
  {"u=e2        (M = c e2e3^T)",       {{0,0,0},{0,0,1},{0,0,0}}},
  {"u=(1,2)     (M = (1,2)(2,-3)^T)",  {{0,0,0},{0,2,-3},{0,4,-6}}}
  };
Do[Print["residual of ", cands[[k,1]], " = ", resJ[cands[[k,2]]]], {k, Length[cands]}];
phiJ = {{1,0,0},{w1,p,qJ},{w2,0,p}};
conjQJ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phiJ . T1 . Inverse[phiJ] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p}], {p, qJ, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
Print[""];
Do[If[i < j, Print["  ", cands[[i,1]], "  ~  ", cands[[j,1]], " ? ", conjQJ[cands[[i,2]], cands[[j,2]]]]],
  {i, Length[cands]}, {j, Length[cands]}];
Print[""];
Print["trace/rank table: "];
Do[Print["  ", cands[[k,1]], "  rank=", MatrixRank[cands[[k,2]]], "  trace=", Tr[cands[[k,2]]],
   "  im=", NullSpace[Transpose[cands[[k,2]]]], "  ker=", NullSpace[cands[[k,2]]]], {k, Length[cands]}];

(* a3: abelian - all 27 components vanish; every invertible map is an automorphism.
   so(3): T - T^T forced to vanish 9/9 (Rabinowitsch); diagonal reduction (eq:diag);
   negative controls diag(1,1,0), diag(1,0,1), e1 e2^T *)
ClearAll["Global`*"];

Print["== a3 (abelian, all brackets zero) =="];
sc0 = SparseArray[{}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
TT = Table[t[i,j], {i,3}, {j,3}];
eqs0 = Flatten[Table[lie[sc0, TT[[All,i]], TT[[All,j]]] - TT . lie[sc0, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]];
Print["  all 27 components identically zero? ", Union[eqs0] === {0}];
M0 = {{2,1,0},{0,-3,1},{1,0,4}};
Print["  det random M = ", Det[M0], ";  M preserves zero bracket trivially (automorphism), M[a,b]=0 = [Ma,Mb]"];
Tns = KroneckerProduct[{1,0,0},{0,1,0}];
Print["  e1 e2^T nonsymmetric? ", Tns =!= Transpose[Tns], " ; is a solution on a3 (trivially)"];

Print["== so(3): symmetric forced 9/9 =="];
sc = SparseArray[{{1,2,3}->1, {2,3,1}->1, {3,1,2}->1, {2,1,3}->-1, {3,2,1}->-1, {1,3,2}->-1}, {3,3,3}];
eqsAll = DeleteCases[Flatten[Table[
  lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]], 0];
vars = Flatten[TT];
diff = TT - Transpose[TT];
allok = True;
Do[
  dk = diff[[Ceiling[k/3], Mod[k-1,3]+1]];
  gb = GroebnerBasis[Join[eqsAll, {dk s - 1}], Join[{s}, vars], MonomialOrder -> Lexicographic];
  zeroideal = (Length[gb] == 1 && Variables[gb[[1]]] === {});
  Print["  d", k, " in sqrt(I)? ", zeroideal];
  If[!zeroideal, allok = False], {k,9}];
Print["  all 9 components of T-T^T vanish on solution set: ", allok];

Print["== so(3): diagonal reduction (eq:diag) and negatives =="];
Td = DiagonalMatrix[{q1,q2,q3}];
eqd = Simplify[Flatten[Table[
  lie[sc, Td[[All,i]], Td[[All,j]]] - Td . lie[sc, Td[[All,i]], unit[[j]]], {i,3}, {j,3}]]];
Print["  diag equations: ", Union[DeleteCases[eqd, 0]]];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
Print["  diag(1,1,0) resid = ", resid[DiagonalMatrix[{1,1,0}]], "  (not a solution)"];
Print["  diag(1,0,1) resid = ", resid[DiagonalMatrix[{1,0,1}]], "  (not a solution)"];
Print["  e1 e2^T resid = ", resid[KroneckerProduct[{1,0,0},{0,1,0}]], "  (nonsymmetric, not a solution)"];
Print["  e1 e1^T resid = ", resid[KroneckerProduct[{1,0,0},{1,0,0}]], "  (solution)  tr = 1"];
Print["  Id resid = ", resid[IdentityMatrix[3]]];

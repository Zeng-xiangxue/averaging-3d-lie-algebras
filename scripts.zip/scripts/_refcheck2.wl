ClearAll["Global`*"];
(* (i) mirror action on the family D_t  (lambda = -1) *)
Rm = {{0, q2}, {r2, 0}};
Dmat = {{t2, u2}, {v2, t2}};
Print["(i) R D R^{-1} = ", Simplify[Rm . Dmat . Inverse[Rm]], "   (u'v' = uv = t^2)  "];
Print["    equals D ? ", Simplify[Rm . Dmat . Inverse[Rm] - Dmat] === {{0, 0}, {0, 0}},
      "     numeric (t=1,u=1/2,v=2,q=r=1): ", Simplify[Rm . Dmat . Inverse[Rm] /. {t2->1, u2->1/2, v2->2, q2->1, r2->1}]];
(* (ii) r(c), c = 0 : mirror component and the four standard forms, Aut_0 = rotations *)
A0 = {{0, -1}, {1, 0}};
br[x_, y_] := Join[{0}, x[[1]] A0 . y[[2 ;; 3]] - y[[1]] A0 . x[[2 ;; 3]]];
e = IdentityMatrix[3];
mirror[p_, q_, w1_, w2_] := {{-1, 0, 0}, {w1, p, q}, {w2, q, -p}};
Print[""];
Print["(ii) mirror automorphism residual = ", Max[Abs[Flatten[Table[
   br[mirror[p,q,w1,w2] . e[[i]], mirror[p,q,w1,w2] . e[[j]]] -
   mirror[p,q,w1,w2] . br[e[[i]], e[[j]]], {i,3},{j,3}]]]]];
E11 = {{1,0,0},{0,0,0},{0,0,0}}; E21r = {{0,0,0},{1,0,0},{0,0,0}};
forms = {0 E11, E21r, 2 IdentityMatrix[3], 2 E11}; lab = {"0", "e21", "2 Id", "2 e11"};
phi0 = {{1,0,0},{w1,p,-q1},{w2,q1,p}};   (* Aut_0 of r(c) : B = p[[1,-t],[t,1]] *)
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi0.T1.Inverse[phi0] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z (p^2 + q1^2)}], {p, q1, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
Do[Module[{img},
  img = Simplify[mirror[1, 1, 0, 0] . forms[[k]] . Inverse[mirror[1, 1, 0, 0]]];
  Print["    ", lab[[k]], " -> ", img, "   Aut0-conjugate back? ", conjQ[img, forms[[k]]]]], {k, 4}];
Print[""];
Print["control: e21 ~ e21 (must be True) : ", conjQ[E21r, E21r]];
Print["control: gamma=(1,0) with M=0 vs gamma=(1,1) with M=0 : ", conjQ[E21r, {{0,0,0},{1,0,0},{1,0,0}}]];

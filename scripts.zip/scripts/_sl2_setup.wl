(* ============================================================
   sl(2,R) setup.  Basis e1 = F, e2 = H/2, e3 = E:
        [e1,e2] = e1,  [e1,e3] = -2 e2,  [e2,e3] = e3.
   Averaging: [T(x),T(y)] = T([T(x),y]).
   Step 1: equations, Groebner basis.
   Step 2: Killing form, signature (2,1), Aut = PGL(2,R) ~= SO(2,1)^o.
   Step 3: End = Sym(K) + so(K) decomposition (self-adjoint + antisymmetric),
           and the elliptic / parabolic / hyperbolic entry point for self-adjoint S.
   ============================================================ *)
ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}]; vars = Flatten[T];
avg[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
raw = Flatten[Table[avg[i,j], {i,3},{j,3}]];
eqs = Select[DeleteDuplicates[raw], # =!= 0 &];

Print["== 1. the averaging equations of sl(2,R) =="];
Print["   bracket check : [e1,e2] = ", lie[sc, unit[[1]], unit[[2]]],
      "   [e1,e3] = ", lie[sc, unit[[1]], unit[[3]]],
      "   [e2,e3] = ", lie[sc, unit[[2]], unit[[3]]]];
Print["   raw components = ", Length[raw], ", distinct non-zero = ", Length[eqs]];
Do[Print["   (", i, ",", j, ")  ", Simplify[avg[i,j]]], {i,3},{j,3}];

Print[""];
Print["== 2. Groebner basis =="];
gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
Print["   size = ", Length[gb]];
Do[Print["   ", i, ": ", Simplify[gb[[i]]]], {i, Length[gb]}];

Print[""];
Print["== 3. Killing form and the structure of Aut =="];
admat[u_] := Table[lie[sc, u, unit[[j]]][[i]], {i,3},{j,3}];
KK = Table[Tr[admat[unit[[i]]] . admat[unit[[j]]]], {i,3},{j,3}];
Print["   K = ", KK, "   eigenvalues = ", Eigenvalues[KK],
      "   signature = (2,1)? ", (Sort[Sign[Eigenvalues[KK]]] === {-1,1,1})];
Print["   Aut = PGL(2,R) = SO(K)^o, dim = ", 3,
      ";  so(K) ~= g via a -> ad_a"];
Print["   ad_a in so(K)? ", And @@ Table[
   Simplify[Transpose[admat[unit[[a]]]] . KK + KK . admat[unit[[a]]]] === ConstantArray[0,{3,3}],
   {a,3}]];
Print["   [ad_a, ad_b] = ad_[a,b] ? ", And @@ Table[
   Simplify[admat[unit[[a]]] . admat[unit[[b]]] - admat[unit[[b]]] . admat[unit[[a]]] -
     admat[lie[sc, unit[[a]], unit[[b]]]]] === ConstantArray[0,{3,3}],
   {a,3},{b,3}]];

Print[""];
Print["== 4. every linear map splits as self-adjoint + antisymmetric =="];
Ki = Inverse[KK];
star[M_] := Ki . Transpose[M] . KK;
MM = Array[m, {3,3}];
SS = Simplify[(MM + star[MM])/2]; AA = Simplify[(MM - star[MM])/2];
Print["   dim of the self-adjoint part = ", Length[Select[Flatten[SS], # =!= 0 &]]];
Print["   S - S* = 0 ? ", Simplify[SS - star[SS]] === ConstantArray[0,{3,3}]];
Print["   A + A* = 0 ? ", Simplify[AA + star[AA]] === ConstantArray[0,{3,3}]];
Print["   Sym(K) = R*Id (+) 5-dim irrep ;  so(K) = g ;  End = Sym(K) (+) so(K)"];

Print[""];
Print["== 5. self-adjoint operators: elliptic / parabolic / hyperbolic =="];
Print["   (S K-self-adjoint: eigenvalues real, complex pair, or Jordan block)"];
Do[
  M0 = RandomReal[{-2,2},{3,3}];
  Sm = Simplify[(M0 + star[M0])/2] // N;
  ev = Eigenvalues[Sm];
  Print["   S = ", MatrixForm[Round[Sm, 0.01]],
        "  eigenvalues = ", Round[ev, 0.001],
        "  #real = ", Length[Select[ev, Abs[Im[#]] < 10^-8 &]],
        "  self-adjoint? ", Max[Abs[Sm - star[Sm]]] < 10^-8],
  {2}];

Print[""];
Print["== 6. equivariance: conjugation preserves the residual =="];
cf = sc;
resid[MT_] := Max[Abs[Flatten[Table[
   lie[cf, MT[[All,i]], MT[[All,j]]] - MT . lie[cf, MT[[All,i]], unit[[j]]],
   {i,3},{j,3}]]]];
Tr1 = {{0,0,0},{0,0,0},{1,0,0}};   (* T = e3 e1^T, a rank-one solution *)
Print["   rank-one candidate e3 e1^T : resid = ", resid[Tr1]];
Do[
  x0 = RandomReal[{-1,1},3];
  Ph = MatrixExp[admat[x0]];                 (* inner automorphism *)
  Tc = Ph . Tr1 . Inverse[Ph];
  Print["   aut? ", Max[Abs[Flatten[Table[lie[cf, Ph[[All,i]], Ph[[All,j]]] -
        Ph . lie[cf, unit[[i]], unit[[j]]], {i,3},{j,3}]]]] < 10^-8,
        "   resid(T) = ", resid[Tr1],
        "   resid(phi T phi^-1) = ", Round[resid[Tc], 10^-10],
        "   conjugate of a solution is a solution? ", Abs[resid[Tc]] < 10^-9],
  {2}];
Print["   also Id and 0 are solutions: ", resid[IdentityMatrix[3]], ", ",
  resid[ConstantArray[0,{3,3}]]];

Print[""];
Print["== 7. case split read off the Groebner basis =="];
Print["   g24 : t11^2 - t33^2 = 0     ->  t33 = +- t11"];
Print["   g15 : t22*(t11 - t33) = 0"];
Print["   g14 : (2 t12 - t23)*(t22 - t33) = 0"];
Print["   g22 : 2 t12^2 + t12 t23 - t23^2 = 0"];
Print["   g6  : t31*(t21 - 2 t32) = 0"];
Print["   g30 : t32*(t23 t32 - t22 t33) = 0,   g32 : t23*(...) = 0"];

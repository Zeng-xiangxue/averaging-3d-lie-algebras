(* ============================================================
   r3, -1 : [e1,e2] = e2, [e1,e3] = -e3.   ad = diag(1,-1).
   Aut = two components:
     (diag) phi = {{1,0},{v,B}},  B = diag(pb,pc)
     (swap) phi = {{-1,0},{v,R}}, R = {{0,qs},{rs,0}}
   Conjugation law for the swap component (alpha = -1, R = R):
     a' = a - bt^T R^-1 v
     b' = -R^-T bt
     D' = R D R^-1 + v bt^T R^-1
     g' = -a v + v (bt^T R^-1 v) - R g + R D R^-1 v
   On the solution set bt = 0, hence D' = R D R^-1.
   ============================================================ *)
ClearAll["Global`*"];
sc = Normal[SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->-1, {3,3,1}->1}, {3,3,3}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
   lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]],
   {i,3},{j,3}]]]];
autResid[M_] := Max[Abs[Flatten[Table[
   lie[sc, M[[All,i]], M[[All,j]]] - M . lie[sc, unit[[i]], unit[[j]]],
   {i,3},{j,3}]]]];

Print["== 1. both components are automorphisms (random numerical test) =="];
Do[
  pb0 = RandomReal[{-2,2}]; pc0 = RandomReal[{-2,2}];
  If[Abs[pb0] < 0.2, pb0 = 1.5]; If[Abs[pc0] < 0.2, pc0 = -1.2];
  v0 = RandomReal[{-2,2},2];
  Print["   diag : autResid = ", autResid[{{1,0,0},{v0[[1]], pb0, 0},{v0[[2]], 0, pc0}}]], {2}];
Do[
  qs0 = RandomReal[{-2,2}]; rs0 = RandomReal[{-2,2}];
  If[Abs[qs0] < 0.2, qs0 = 1.3]; If[Abs[rs0] < 0.2, rs0 = -0.7];
  v0 = RandomReal[{-2,2},2];
  Print["   swap : autResid = ", autResid[{{-1,0,0},{v0[[1]], 0, qs0},{v0[[2]], rs0, 0}}],
        "   det = ", -qs0 rs0], {2}];

Print[""];
Print["== 2. conjugation law of the swap component (symbolic) =="];
Rm = {{0, qs},{rs, 0}}; vv = {v1, v2}; aa = syma; bb = {bt1, bt2};
gm = {g1, g2}; Dm = {{d11, d12},{d21, d22}};
Tg = {{aa, bb[[1]], bb[[2]]}, {gm[[1]], Dm[[1,1]], Dm[[1,2]]}, {gm[[2]], Dm[[2,1]], Dm[[2,2]]}};
Phi = {{-1, 0, 0},{vv[[1]], 0, qs},{vv[[2]], rs, 0}};
Tp = Simplify[Phi . Tg . Inverse[Phi]];
Print["   a' law : ", Simplify[Tp[[1,1]] - (aa - bb . Inverse[Rm] . vv)] === 0];
Print["   b' law : ", Simplify[{Tp[[1,2]], Tp[[1,3]]} + Transpose[Inverse[Rm]] . bb] === {0,0}];
Print["   D' law (with the extra term v bt^T R^-1) : ",
  Simplify[Tp[[2;;3,2;;3]] - (Rm . Dm . Inverse[Rm] + Outer[Times, vv, bb . Inverse[Rm]])] === {{0,0},{0,0}}];
Print["   g' law : ", Simplify[{Tp[[2,1]], Tp[[3,1]]} -
   (-aa vv + vv (bb . Inverse[Rm] . vv) - Rm . gm + Rm . Dm . Inverse[Rm] . vv)] === {0,0}];

Print[""];
Print["== 3. the eight candidates at lam = -1 : residuals =="];
cands = {
  {"1  0", {{0,0,0},{0,0,0},{0,0,0}}},
  {"2  e2 e1^T (one nonzero gamma)", {{0,0,0},{1,0,0},{0,0,0}}},
  {"3  (e2+e3) e1^T", {{0,0,0},{1,0,0},{1,0,0}}},
  {"4  e2 e3^T (D nilpotent)", {{0,0,0},{0,0,1},{0,0,0}}},
  {"5  a e1 e1^T (a=3)", {{3,0,0},{0,0,0},{0,0,0}}},
  {"6  diag(a,a,0) (a=3)", {{3,0,0},{0,3,0},{0,0,0}}},
  {"7  a Id3 (a=4)", {{4,0,0},{0,4,0},{0,0,4}}},
  {"8  D_t (t=1): D={{1,1},{1,1}}", {{0,0,0},{0,1,1},{0,1,1}}}
};
Do[Print["   ", cands[[k,1]], "   resid = ", resid[cands[[k,2]]]], {k, Length[cands]}];

Print[""];
Print["== 4. explicit merges caused by the swap component (phi with q=r=1, v=(0,1)) =="];
Ph = {{-1,0,0},{0,0,1},{1,1,0}};
Do[Print["   ", nm, "  ->  ", MatrixForm[Ph . MM . Inverse[Ph]]],
  {{nm, MM}, {{"diag(a,a,0), a=3", {{3,0,0},{0,3,0},{0,0,0}}},
              {"e2 e3^T", {{0,0,0},{0,0,1},{0,0,0}}},
              {"e2 e1^T", {{0,0,0},{1,0,0},{0,0,0}}}}}];

Print[""];
Print["== 5. pairwise inequivalence under the FULL Aut (both components) =="];
varsAB = {pb, pc, qs, rs, w1, w2, ss};
phiA = {{1,0,0},{w1, pb, 0},{w2, 0, pc}};
phiB = {{-1,0,0},{w1, 0, qs},{w2, rs, 0}};
unitQ[Phi_, detE_, Ti_, Tj_] := Module[{sys, gb},
  sys = Flatten[Phi . Ti - Tj . Phi];
  gb = DeleteCases[GroebnerBasis[Join[sys, {detE ss - 1}], varsAB,
        MonomialOrder -> DegreeReverseLexicographic], 0];
  gb === {1}];
noConj[Ti_, Tj_] := unitQ[phiA, pb pc, Ti, Tj] && unitQ[phiB, -qs rs, Ti, Tj];
Do[If[i < j,
   Print["   ", cands[[i,1]], "  vs  ", cands[[j,1]], "   inequivalent: ",
     noConj[cands[[i,2]], cands[[j,2]]]]],
  {i, Length[cands]}, {j, Length[cands]}];
Print["   control same class (must be conjugate -> False): ", noConj[cands[[5,2]], cands[[5,2]]]];
Print["   merged pairs, expected 'conjugate' (False): "];
Print["     diag(a,a,0) vs diag(a,0,a) : ",
  noConj[{{3,0,0},{0,3,0},{0,0,0}}, {{3,0,0},{0,0,0},{0,0,3}}]];
Print["     e2e3^T vs e3e2^T         : ",
  noConj[{{0,0,0},{0,0,1},{0,0,0}}, {{0,0,0},{0,0,0},{0,1,0}}]];
Print["     e2e1^T vs e3e1^T         : ",
  noConj[{{0,0,0},{1,0,0},{0,0,0}}, {{0,0,0},{0,0,0},{1,0,0}}]];

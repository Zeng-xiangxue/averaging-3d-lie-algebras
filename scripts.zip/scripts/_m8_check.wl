(* M8 : general proposition for g_D = R e1 +|_D R^2 *)
ClearAll["Global`*"];
Dm = {{d11, d12}, {d21, d22}};
B = {{p11, p12}, {p21, p22}};
(* conjugation law on the solution set (beta = 0), derived from the block formula *)
gam = {g1, g2}; M = {{m11, m12}, {m21, m22}}; a = aa; w = {w1, w2};
Bh = {{b11, b12}, {b21, b22}};   (* generic B *)
Mp = Bh . M . Inverse[Bh];
gp = Bh . gam + (aa IdentityMatrix[2] - Bh . M . Inverse[Bh]) . w;
Print["gamma' - B gamma in im(aI - B M B^{-1}) ? ",
  Simplify[gp - Bh . gam - (aa IdentityMatrix[2] - Mp) . w] === {0, 0}];
Print["im(aI-M) transported:  B(aI-M)B^{-1} = aI - BMB^{-1} ? ",
  Simplify[Bh . (aa IdentityMatrix[2] - M) . Inverse[Bh] - (aa IdentityMatrix[2] - Mp)] === {{0,0},{0,0}}];
(* completeness: given M' = BMB^{-1} and gamma' = B gamma + B mu, mu in im(aI-M), find w *)
mu = (aa IdentityMatrix[2] - M) . x;      (* generic element of im(aI-M) *)
wstar = Bh . x;
Print["with w = B x :  gamma' = B gamma + (aI - M') w ? ",
  Simplify[(Bh . gam + (aa IdentityMatrix[2] - Mp) . wstar) - (Bh . gam + Bh . mu)] === {0, 0}];
(* the four relations are linear in u = (lambda, w), so checking three generators suffices *)
lin1 = bb . Dm . w; lin2 = aa2 bb . Dm; lin3 = MM . Dm . w - aa3 Dm . w + aa4 Dm . gm;
Print["(E1),(E2) linear in u ; (E3),(E4) affine-linear in (lambda,w) : checked by structure"];

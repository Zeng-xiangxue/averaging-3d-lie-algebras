(* 验证引理3.14在 c=0 时的谱论证 *)
(* 结构常数：r(c): [e1,e2]=c e2+e3, [e1,e3]=-e2+c e3, [e2,e3]=0 *)
LC[c_][x_, y_] := Module[{coef, r},
  (* x,y 是坐标向量 (x1,x2,x3) 即 x1 e1 + x2 e2 + x3 e3 *)
  coef = {0, 0, 0};
  coef += x[[1]] y[[2]] {0, c, 1};          (* [e1,e2] *)
  coef += x[[1]] y[[3]] {0, -1, c};         (* [e1,e3] *)
  coef += x[[2]] y[[1]] {0, -c, -1};        (* [e2,e1] *)
  coef += x[[3]] y[[1]] {0, 1, -c};         (* [e3,e1] *)
  coef];

Print["--- 1. c=0 时 a=-1 分量是否给出自同构 ---"];
phi = DiagonalMatrix[{-1, 1, -1}];  (* phi(e1)=-e1, phi(e2)=e2, phi(e3)=-e3 *)
ok = True;
Do[Do[
   lhs = LC[0][phi.x, phi.y];
   rhs = phi.LC[0][x, y];
   If[! (lhs == rhs), ok = False; Print["FAIL at x=", x, " y=", y]];
   , {y, IdentityMatrix[3]}], {x, IdentityMatrix[3]}];
Print["phi 是 r(0)=e(2) 的自同构: ", ok];

Print["--- 2. 解 BD = aDB（D=C0）看 a 的取值 ---"];
D0 = {{0, -1}, {1, 0}};
B = {{b11, b12}, {b21, b22}};
sol = Reduce[Flatten[B.D0 == a D0.B] && b11 b22 - b12 b21 != 0, {a, b11, b12, b21, b22}];
Print["BD=aDB, B 可逆 的解: ", sol];

Print["--- 3. 引理3.14 的 B 中心化子公式对 c 一般（c 符号）: B Cc = Cc B ---"];
(* 对一般 c: B 与 Cc 交换 ⟺ B = p[[1,-t],[t,1]] *)
Cc = {{c, -1}, {1, c}};
solB = Solve[Flatten[B.Cc == Cc B], {b11, b12, b21, b22}];
Print["中心化子: ", solB];

Print["--- 4. 三个新分类的标准型残差抽查 ---"];
(* Averaging 恒等式: [Tx,Ty] = T[Tx,y] *)
avg[c_][T_, x_, y_] := LC[c][T.x, T.y] - T.LC[c][T.x, y];

(* r(1,0): c 无效但用 diag(1,0) 需单独定义；用 LC 无法表达，改用手动括号 *)
LC10[x_, y_] := Module[{coef},
  coef = {0, 0, 0};
  coef += x[[1]] y[[2]] {0, 1, 0};   (* [e1,e2]=e2 *)
  coef += x[[2]] y[[1]] {0, -1, 0};
  coef];
avg10[T_, x_, y_] := LC10[T.x, T.y] - T.LC10[T.x, y];

(* r(J): [e1,e2]=e2, [e1,e3]=e2+e3 *)
LCJ[x_, y_] := Module[{coef},
  coef = {0, 0, 0};
  coef += x[[1]] y[[2]] {0, 1, 0};
  coef += x[[1]] y[[3]] {0, 1, 1};
  coef += x[[2]] y[[1]] {0, -1, 0};
  coef += x[[3]] y[[1]] {0, -1, -1};
  coef];
avgJ[T_, x_, y_] := LCJ[T.x, T.y] - T.LCJ[T.x, y];

check[avg_, T_, label_] := Module[{res, allzero = True},
  Do[Do[
    res = avg[T, x, y];
    If[! (res == {0, 0, 0}), allzero = False; Print[label, " FAIL x=", x, " y=", y, " res=", res]],
    {y, IdentityMatrix[3]}], {x, IdentityMatrix[3]}];
  Print[label, " 残差全零: ", allzero]];

(* r(1,0) 15 类标准型（定理3.15） *)
std10 = {
  {0,0,0,0,0,0,0,0,0},          (* 1: 0 *)
  {0,0,0,0,0,0,1,0,0},          (* 2: e3 e1^T *)
  {0,0,0,1,0,0,0,0,0},          (* 3: e2 e1^T *)
  {0,0,0,1,0,0,1,0,0},          (* 4: e2e1^T+e3e1^T *)
  {0,0,0,0,0,0,0,0,m},          (* 5: m e3e3^T *)
  {0,0,0,1,0,0,0,0,m},          (* 6: e2e1^T+m e3e3^T *)
  {0,0,0,0,0,0,1,0,m},          (* 7: e3e1^T+m e3e3^T *)
  {0,0,0,1,0,0,1,0,m},          (* 8: e2e1^T+e3e1^T+m e3e3^T *)
  {0,0,0,1,0,0,0,0,0},          (* 9: 与3同形? 见下 *)
  {a,0,0,0,a,0,0,0,a},          (* 10: a Id *)
  {a,0,0,0,a,0,1,0,a},          (* 11: a Id + e3e1^T *)
  {a,0,0,0,0,0,0,0,0},          (* 12: a e1e1^T *)
  {a,0,0,0,0,0,0,0,m},          (* 13: diag(a,0,m) *)
  {a,0,0,0,a,0,0,0,m},          (* 14: diag(a,a,m) *)
  {a,0,1,0,0,0,0,0,s}           (* 15: (a 0 1;0 0 0;0 0 s) *)
};
(* 逐类标注名 *)
names10 = {"1:0","2:e3e1^T","3:e2e1^T","4:e2e1^T+e3e1^T","5:m e3e3^T","6:e2e1^T+m e3e3^T",
  "7:e3e1^T+m e3e3^T","8:e2e1^T+e3e1^T+m e3e3^T","9:(=3?)","10:a Id","11:a Id+e3e1^T",
  "12:a e1e1^T","13:diag(a,0,m)","14:diag(a,a,m)","15:(a,0,1;0,0,0;0,0,s)"};
Print["--- r(1,0) 标准型残差（用符号 a,m,s 代入数值抽样） ---"];
Do[
  M = Partition[std10[[k]] /. {a -> 3, m -> 2, s -> 4}, 3];
  check[avg10, M, names10[[k]]],
  {k, {1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15}}];

(* r(J) 7 类 *)
stdJ = {
  {0,0,0,0,0,0,0,0,0},   (* 0 *)
  {0,0,0,1,0,0,0,0,0},   (* e2 e1^T *)
  {0,0,0,0,0,0,1,0,0},   (* e3 e1^T *)
  {a,0,0,0,a,0,0,0,a},   (* a Id *)
  {a,0,0,0,0,0,0,0,0},   (* a e1e1^T *)
  {0,0,0,0,0,0,-1,1,0}*c, (* c(e2-e3)e2^T: (2,1)元=-c,(3,1)元=c *)
  {0,0,0,0,0,c,0,0,0}    (* c e2 e3^T *)
};
namesJ = {"0","e2e1^T","e3e1^T","a Id","a e1e1^T","c(e2-e3)e2^T","c e2e3^T"};
Print["--- r(J) 标准型残差 ---"];
Do[
  M = Partition[stdJ[[k]] /. {a -> 3, c -> 2}, 3];
  check[avgJ, M, namesJ[[k]]],
  {k, 1, 7}];

(* r(c) 4 类（用 LC[c]） *)
stdC = {
  {0,0,0,0,0,0,0,0,0},   (* 0 *)
  {0,0,0,1,0,0,0,0,0},   (* e2 e1^T *)
  {a,0,0,0,a,0,0,0,a},   (* a Id *)
  {a,0,0,0,0,0,0,0,0}    (* a e1e1^T *)
};
Print["--- r(c) 标准型残差（c=2 与 c=0） ---"];
Do[
  M = Partition[stdC[[k]] /. {a -> 3}, 3];
  check[Function[{T, x, y}, avg[c][T, x, y]] /. c -> 2, M, "c=2, 类" <> ToString[k]];
  check[Function[{T, x, y}, avg[c][T, x, y]] /. c -> 0, M, "c=0, 类" <> ToString[k]],
  {k, 1, 4}];

Print["--- 5. 定理3.14 的 (24)(25) 抽样反查（随机满足条件的 T 应是解） ---"];
(* D=diag(1,0): 手动验证几个随机满足(24)(25)的矩阵 *)
random10[a0_, M110_, g10_, b20_, M120_, M210_, M220_] := Module[{T},
  T = {{a0, 0, b20}, {g10, M110, M120}, {0, M210, M220}};
  (* 这里 (2,3)=M12=t23, (3,2)=M21=t32; γ2=t31=0 取零 *)
  T];
Do[
  T = random10[RandomInteger[{-3, 3}], RandomInteger[{-3, 3}], RandomInteger[{-3, 3}], RandomInteger[{-3, 3}], RandomInteger[{-3, 3}], 0, RandomInteger[{-3, 3}]];
  (* 仅当满足约束才测试 *)
  If[T[[2, 2]] (T[[2, 2]] - T[[1, 1]]) == 0 && T[[2, 2]] T[[2, 1]] == 0 && T[[2, 2]] T[[1, 3]] == 0 && T[[2, 2]] T[[2, 3]] == 0 && T[[1, 3]] T[[2, 1]] == T[[1, 1]] T[[2, 3]] && T[[3, 2]] T[[1, 1]] == 0 && T[[3, 2]] T[[2, 1]] == 0 && T[[3, 2]] T[[1, 3]] == 0 && T[[3, 2]] T[[2, 3]] == 0,
    check[avg10, T, "随机(24)(25)解"]],
  {12}];
Print["done"];

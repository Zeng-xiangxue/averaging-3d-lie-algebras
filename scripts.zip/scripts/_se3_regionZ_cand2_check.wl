#!/usr/bin/env wolframscript
(* ==================================================================
   _se3_regionZ_cand2_check.wl -- verify the NEW family found by the
   global Solve 1, branch 7 (B = 0 block, Region Z):
     A = lam e1e1^T, B = 0,
     D = diag(0, lam, lam),   C = e1^perp-block  [[0,0,0],[0,c22,c23],[0,-c23,c22]]
   plus negatives (a' != 0, broken C shapes).
   ASCII-only source on purpose.
   ================================================================== *)

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6]; e3 = IdentityMatrix[3]; Z3 = ConstantArray[0, {3, 3}];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
ok[R_] := AllTrue[Flatten[avgDef[R]], (Simplify[#] === 0) &];
P[u_] := Outer[Times, u, u];
e1 = {1, 0, 0};
Cperp[c22_, c23_] := {{0, 0, 0}, {0, c22, c23}, {0, -c23, c22}};

Print["=== NEW family: A = 3 e1e1^T, B = 0, D = diag(0,3,3), C = Cperp(c22,c23) ==="];
Print["  c22=2,  c23=5  : ", ok[ArrayFlatten[{{3 P[e1], Z3}, {Cperp[2, 5], DiagonalMatrix[{0, 3, 3}]}}]]];
Print["  c22=0,  c23=7  : ", ok[ArrayFlatten[{{3 P[e1], Z3}, {Cperp[0, 7], DiagonalMatrix[{0, 3, 3}]}}]]];
Print["  c22=4,  c23=0  : ", ok[ArrayFlatten[{{3 P[e1], Z3}, {Cperp[4, 0], DiagonalMatrix[{0, 3, 3}]}}]]];
Print["  c22=-1, c23=2  : ", ok[ArrayFlatten[{{3 P[e1], Z3}, {Cperp[-1, 2], DiagonalMatrix[{0, 3, 3}]}}]]];
Print[""];
Print["=== negatives ==="];
Print["  a' != 0: D = diag(2,3,3), same C      : ",
  ok[ArrayFlatten[{{3 P[e1], Z3}, {Cperp[2, 5], DiagonalMatrix[{2, 3, 3}]}}]]];
Print["  broken C: diag(1,2,3), D = diag(0,3,3) : ",
  ok[ArrayFlatten[{{3 P[e1], Z3}, {DiagonalMatrix[{1, 2, 3}], DiagonalMatrix[{0, 3, 3}]}}]]];
Print["  broken C: e1 e1^T, D = diag(0,3,3)     : ",
  ok[ArrayFlatten[{{3 P[e1], Z3}, {P[e1], DiagonalMatrix[{0, 3, 3}]}}]]];
Print["  cross: cand-1 C-family shape with D = diag(0,3,3) : ",
  ok[ArrayFlatten[{{3 P[e1], Z3}, {{{2, 3, 4}, {9, 0, 0}, {12, 0, 0}}, DiagonalMatrix[{0, 3, 3}]}}]]];
Print["  C = 0 with D = diag(0,3,3) (C=0 excluded in Z)     : ",
  ok[ArrayFlatten[{{3 P[e1], Z3}, {Z3, DiagonalMatrix[{0, 3, 3}]}}]]];
Print[""];
Print["Done."];

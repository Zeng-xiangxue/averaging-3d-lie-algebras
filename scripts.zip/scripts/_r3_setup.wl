(* ============================================================
   r3 : [e1,e2] = e2,  [e1,e3] = e3,  [e2,e3] = 0.
   Averaging: [T(x),T(y)] = T([T(x),y]) for all x,y.
   Block form wrt g = R e1 (+) n,  n = [g,g] = span(e2,e3):
        T = [[a, beta^T],[gamma, D]],   a = t11,
        beta^T = (t12,t13),  gamma = (t21,t31),  D = {{t22,t23},{t32,t33}}.
   Aut(r3) = { phi = [[1,0],[v,B]] : v in n, B in GL(2) },  acting by
        a' = a - beta^T B^-1 v,  beta' = B^-T beta,
        D' = B D B^-1 + v beta'^T,  gamma' = B gamma + a' v - B D B^-1 v.
   Step 1: list equations, full Groebner basis.
   Step 2: branch beta = 0   (t12 = t13 = 0).
   Step 3: branch beta != 0, normalised to a = 0, beta = e1.
   ============================================================ *)
ClearAll["Global`*"];
sc = SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}]; vars = Flatten[T];
avg[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
raw = Flatten[Table[avg[i,j], {i,3},{j,3}]];
eqs = Select[DeleteDuplicates[raw], # =!= 0 &];
Print["raw components = ", Length[raw], ", distinct = ", Length[DeleteDuplicates[raw]],
      ", distinct non-zero = ", Length[eqs]];
Print[""];
Print["== component equations (i,j) =="];
Do[Print["  (", i, ",", j, ")  ", Simplify[avg[i,j]]], {i,3},{j,3}];

Print[""];
Print["== full Groebner basis (9 variables) =="];
gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
Print["  size = ", Length[gb]];
Do[Print["   ", i, ":  ", gb[[i]]], {i, Length[gb]}];

Print[""];
Print["== branch beta = 0 : t12 = t13 = 0 =="];
eqs0 = Select[DeleteDuplicates[Simplify[eqs /. {t[1,2] -> 0, t[1,3] -> 0}]], # =!= 0 &];
vars0 = DeleteCases[vars, t[1,2] | t[1,3]];
Print["  #eq = ", Length[eqs0], "   eqs = ", eqs0];
gb0 = GroebnerBasis[eqs0, vars0, MonomialOrder -> DegreeReverseLexicographic];
Print["  GB size = ", Length[gb0]];
Do[Print["   ", i, ":  ", Simplify[gb0[[i]]]], {i, Length[gb0]}];

Print[""];
Print["== branch beta != 0 : normalised a = 0, beta = e1 =="];
eqs1 = Select[DeleteDuplicates[Simplify[eqs /. {t[1,1] -> 0, t[1,2] -> 1, t[1,3] -> 0}]],
   # =!= 0 &];
vars1 = {t[2,1], t[3,1], t[2,2], t[2,3], t[3,2], t[3,3]};
Print["  #eq = ", Length[eqs1], "   eqs = ", eqs1];
gb1 = GroebnerBasis[eqs1, vars1, MonomialOrder -> DegreeReverseLexicographic];
Print["  GB size = ", Length[gb1]];
Do[Print["   ", i, ":  ", Simplify[gb1[[i]]]], {i, Length[gb1]}];

Print[""];
Print["== residual automorphism freedom (for the next step) =="];
Print["  beta = 0 branch : Phi = full Aut = {(v,B)}  (6 parameters)"];
Print["  beta = e1 branch: B = {{1,0},{m1,m2}} (m2 != 0), v with e1^T B^-1 v = 0"];

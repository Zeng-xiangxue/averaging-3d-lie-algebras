(* back-up checks for the four fixes in h1_averaging.tex *)
ClearAll["Global`*"];
Print["-- 1. stabilizer of diag(s,0) in GL(2) --"];
M = {{p,q},{r,s2}}; X = {{ss,0},{0,0}};
sol = Solve[Thread[Flatten[M.X - X.M] == 0], {p,q,r,s2}];
Print["  MX = XM  =>  ", Simplify[sol]];
Print["  numeric control (lower triangular M={{1,0},{1,1}}): X' = ",
  MatrixForm[{{1,0},{1,1}}.{{1,0},{0,0}}.Inverse[{{1,0},{1,1}}]], "  (not X)"];
Print["-- 2. equation count for h1 --"];
sc = SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}];
avg[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
raw = Flatten[Table[avg[i,j], {i,3},{j,3}]];
Print["  raw components: ", Length[raw],
      "   distinct: ", Length[DeleteDuplicates[raw]],
      "   distinct non-zero: ", Length[Select[DeleteDuplicates[raw], # =!= 0 &]]];
Print["-- 3. class 5/6 and 3/4 recursion check (numeric) --"];
Print["  (N,(1,0)) under M={{a,b},{0,a}}, w=0: z' = ", 
  Simplify[({0,0}+Det[{{a,b},{0,a}}] {1,0}).Inverse[{{a,b},{0,a}}]]];
Print["  diag(s,0) piece: z' = ", Simplify[({ss*w1,0} + Det[{{a,0},{0,c}}] {z1,z2}).Inverse[{{a,0},{0,c}}]]];

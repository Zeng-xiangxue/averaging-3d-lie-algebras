(* M6: [g_D,im T] 的显式形状与 RBO 判据（随机 T，无需是解） *)
ClearAll["Global`*"]; SeedRandom[20260926];
brD[As_, x_, y_] := Join[{0}, x[[1]] As . y[[2 ;; 3]] - y[[1]] As . x[[2 ;; 3]]];
genR[As_, T_] := Module[{a, bb, gam, MM, S, zs, direct, form},
  a = T[[1, 1]]; bb = {T[[1, 2]], T[[1, 3]]}; gam = {T[[2, 1]], T[[3, 1]]};
  MM = {{T[[2, 2]], T[[2, 3]]}, {T[[3, 2]], T[[3, 3]]}};
  S = {a, bb[[1]], bb[[2]]};
  direct = Max[Abs[Flatten[Table[T . brD[As, UnitVector[3, i], T . UnitVector[3, j]],
       {i, 3}, {j, 3}]]]];
  zs = {As . gam, As . MM . {1, 0}, As . MM . {0, 1}};
  Do[AppendTo[zs, S[[k]] As . {1, 0}]; AppendTo[zs, S[[k]] As . {0, 1}], {k, 3}];
  form = Max[Abs[Flatten[Table[{MM . z, bb . z}, {z, zs}]]]];
  {direct, form}];
names = {"r(J) [A=J]", "r(c) [A=C_1]", "r(1,0) [A=diag(1,0)]", "r_3 [A=I]"};
Do[
  As = Which[k == 1, {{1, 1}, {0, 1}}, k == 2, {{1, -1}, {1, 1}},
    k == 3, {{1, 0}, {0, 0}}, True, IdentityMatrix[2]];
  bad = 0;
  Do[T = RandomReal[{-3, 3}, {3, 3}];
    {d1, f1} = genR[As, T];
    If[(d1 < 10^-8) =!= (f1 < 10^-8), bad++], {60}];
  Print[names[[k]], " : 60 个随机 T 上直接判定与公式判定不一致数 = ", bad];
  , {k, 4}];
Print["说明：direct = max|T.[e_i,T e_j]|（即 [g,im T] 是否含于 ker T）；",
  " form = max|M z| 与 |beta^T z|（z 遍历 D gamma + D M n + span{a,b1,b2} D n 的生成元）。"];

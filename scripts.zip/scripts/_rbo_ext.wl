(* =====================================================================
   _rbo_ext.wl --- which standard forms of r(1,0), r(J), r(c) are also
   0-weight Rota-Baxter operators ?
   criterion (Proposition 4.2):  T is averaging and 0-weight RBO
   <=>  [g, im T] subset ker T  <=>  T([e_i , T e_j]) = 0 for all i,j
   ===================================================================== *)
ClearAll["Global`*"];
e = IdentityMatrix[3];
mk[D2_] := Function[{x, y}, Join[{0}, x[[1]] D2 . y[[2 ;; 3]] - y[[1]] D2 . x[[2 ;; 3]]]];
br10 = mk[{{1, 0}, {0, 0}}];                 (* r(1,0)  *)
brJ  = mk[{{1, 1}, {0, 1}}];                 (* r(J)    *)
brC  = mk[{{c, -1}, {1, c}}];                (* r(c)    *)
rbo[br_, T_] := Simplify[Union[Flatten[Table[T . br[e[[i]], T . e[[j]]], {i, 3}, {j, 3}]]]];
chk[br_, name_, T_] := Module[{d = rbo[br, T]},
  Print["   ", name, "   RBO : ", d === {0}, If[d === {0}, "", {"   residual ", d}]]];

E11={{1,0,0},{0,0,0},{0,0,0}}; E22={{0,0,0},{0,1,0},{0,0,0}}; E33={{0,0,0},{0,0,0},{0,0,1}};
E13={{0,0,1},{0,0,0},{0,0,0}}; E21={{0,0,0},{1,0,0},{0,0,0}}; E23={{0,0,0},{0,0,1},{0,0,0}};
E31={{0,0,0},{0,0,0},{1,0,0}}; E32={{0,0,0},{0,0,0},{0,1,0}};

Print["== r(1,0) : 16 classes =="];
chk[br10, "1  0", 0 E11];
chk[br10, "2  e21", E21];
chk[br10, "3  e31", E31];
chk[br10, "4  e21+e31", E21 + E31];
chk[br10, "5  a Id3 (a=2)", 2 IdentityMatrix[3]];
chk[br10, "6  a Id3+e31 (a=2)", 2 IdentityMatrix[3] + E31];
chk[br10, "7  diag(a,0,a) (symbolic a)", a1 E11 + a1 E33];
chk[br10, "8  diag(a,0,a)+e31 (symbolic a)", a1 E11 + a1 E33 + E31];
chk[br10, "9  mu e33 (symbolic mu)", mu E33];
chk[br10, "10 e21+mu e33 (mu=3)", E21 + 3 E33];
chk[br10, "11 e32+mu e33 (mu=3)", E32 + 3 E33];
chk[br10, "12 e23+mu e33 (mu=3)", E23 + 3 E33];
chk[br10, "13 e23+e31+mu e33 (mu=3)", E23 + E31 + 3 E33];
chk[br10, "14 diag(a,0,mu) (2,5)", 2 E11 + 5 E33];
chk[br10, "15 diag(a,a,mu) (2,5)", 2 E11 + 2 E22 + 5 E33];
chk[br10, "15' diag(a,a,0) (2,0)", 2 E11 + 2 E22];
chk[br10, "16 e13+g e31+mu e33 (2,3)", E13 + 2 E31 + 3 E33];

Print[""];
Print["== r(J) : 7 classes =="];
chk[brJ, "1 0", 0 E11];
chk[brJ, "2 e21", E21];
chk[brJ, "3 e31", E31];
chk[brJ, "4 a Id3 (a=2)", 2 IdentityMatrix[3]];
chk[brJ, "5 a e11 (a=2)", 2 E11];
chk[brJ, "6 c(e2-e3)e2^T (c=2)", 2 (E22 - E32)];
chk[brJ, "7 c e2e3^T (c=2)", 2 E23];

Print[""];
Print["== r(c) : 4 classes =="];
chk[brC, "1 0", 0 E11];
chk[brC, "2 e21", E21];
chk[brC, "3 a Id3 (a=2)", 2 IdentityMatrix[3]];
chk[brC, "4 a e11 (a=2)", 2 E11];

Print[""];
Print["== c-dependence for r(c) : e21 and a e11 with symbolic c =="];
chk[brC, "e21 (symbolic c)", E21];
chk[brC, "a e11 (symbolic c)", a1 E11];
Print["== lambda-dependence for r(1,0) : nothing depends on the parameter =="];
Print["   diag(a,0,a) with symbolic a : see class 7 above"];

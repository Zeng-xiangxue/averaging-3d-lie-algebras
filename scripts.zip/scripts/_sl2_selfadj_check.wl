(* independent check of Lemma (All solutions are self-adjoint):
   the 9 components of T - T*  (T* = K^{-1} T^T K) vanish on the solution set.
   Rabinowitsch: eqs + (d_k * s - 1) has GB = {1}  <=>  d_k in sqrt(I) *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
K = {{0,0,4},{0,2,0},{4,0,0}};
TT = Table[t[i,j], {i,3}, {j,3}];
vars = Flatten[TT];
eqsAll = DeleteCases[Flatten[Table[
  lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]], 0];
Tstar = Simplify[Inverse[K] . Transpose[TT] . K];
diff = Simplify[TT - Tstar];
Print["symbolic components of T - T*:"];
Do[Print["  d", k, " = ", diff[[Ceiling[k/3], Mod[k-1,3]+1]]], {k,9}];

Print["== Rabinowitsch: each d_k in sqrt(I)? =="];
allok = True;
Do[
  dk = diff[[Ceiling[k/3], Mod[k-1,3]+1]];
  gb = GroebnerBasis[Join[eqsAll, {dk s - 1}], Join[{s}, vars], MonomialOrder -> Lexicographic];
  zeroideal = (Length[gb] == 1 && Variables[gb[[1]]] === {});
  Print["  d", k, " in sqrt(I) (Rabinowitsch {1})? ", zeroideal];
  If[!zeroideal, allok = False],
  {k,9}];
Print["== ALL 9 components forced to vanish  =>  every solution is K-self-adjoint: ", allok];

Print["== also: (v(Kv)^T)^* = v(Kv)^T (symbolic) =="];
vv = {v1,v2,v3};
M = KroneckerProduct[vv, K . vv];
Print["  M* - M = ", Simplify[Inverse[K] . Transpose[M] . K - M], "  (should be zero matrix)"];
Print["  tr(v(Kv)^T) = ", Simplify[Tr[M]], "  = K(v,v) = ", Simplify[vv . K . vv]];

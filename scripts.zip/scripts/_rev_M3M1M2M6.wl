(* =========================================================================
   独立核验（对应本轮修改）
   M3 : so(3) 由 O(3) 对角化吸收反射，特征值本身不变号
   M1 : r_D (D 可逆) 解集逆命题 —— 四条关系在三个生成元上等价于 eq:sol
   M2 : h1 约化系统 (sys) 的来源（(e3,e2) 配对给出 -t13^2）
   M6 : [g_D, im T] = D gamma + D M n + span{a,b1,b2} D n 与 RBO 判据
   ========================================================================= *)
ClearAll["Global`*"]; SeedRandom[20260926];

Print["===== M3: O(3) -> SO(3)，反射吸收后特征值不变号 ====="];
n3 = 0; flipped = 0; fire = 0; sample = None;
Do[
  A0 = RandomReal[{-4, 4}, {3, 3}]; S = (A0 + Transpose[A0])/2;
  {ev, V} = Eigensystem[S]; Q = Transpose[V];
  If[Det[Q] < 0, fire++; Q = Q . DiagonalMatrix[{-1, 1, 1}];];
  d = Transpose[Q] . S . Q;
  If[Abs[Det[Q] - 1] > 10^-9, n3++];
  If[Max[Abs[Flatten[d - DiagonalMatrix[ev]]]] > 10^-7, n3++];
  If[ev[[1]] < 0 == False && d[[1, 1]] < 0, flipped++];
  If[sample === None && fire > 0, sample = {Q, ev, d}];
  , {40}];
Print["  随机对称矩阵 40 个：反射分支被修正的次数 = ", fire,
  "；失败次数（det<>1 或 Q^T S Q <> diag(原特征值)）= ", n3];
Print["  例：修正后 diag 对角元 = ", Chop[sample[[3]][[1, 1]]],
  "，原特征值(首) = ", Chop[sample[[2]][[1]]],
  "（说明反射只是换基，不改变对角化后的谱）"];

Print["===== M2: h1 约化系统来源，(e3,e2) 配对的 e1 分量 = -t13^2 ====="];
brH1[x_, y_] := {0, 0, x[[1]] y[[2]] - x[[2]] y[[1]]};
n2 = 0; nu = 0;
Do[
  T = RandomReal[{-3, 3}, {3, 3}];
  v = brH1[T . UnitVector[3, 3], T . UnitVector[3, 2]] - T . brH1[T . UnitVector[3, 3], UnitVector[3, 2]];
  If[Abs[v[[1]] + T[[1, 3]]^2] > 10^-8, n2++];
  (* 一般 u 的矩阵比较: (T ad_u - ad_u T)[[3,2]] = u1(t33-t22)+u2 t12 *)
  u = RandomReal[{-3, 3}, 3];
  Adu = {{0, 0, 0}, {0, 0, 0}, {-u[[2]], u[[1]], 0}};
  If[Abs[(T . Adu - Adu . T)[[3, 2]] - (u[[1]] (T[[3, 3]] - T[[2, 2]]) + u[[2]] T[[1, 2]])] > 10^-8, nu++];
  , {20}];
Print["  [T e3,T e2]-T[T e3,e2] 的 e1 分量 + t13^2 = 0 的失败数 = ", n2];
Print["  (T ad_u - ad_u T)[[3,2]] 公式的失败数 = ", nu];

Print["===== M1: r_D 逆命题（四个关系在三个生成元上 <=> eq:sol），D=J ====="];
e = IdentityMatrix[3]; T = Array[t, {3, 3}]; vars = Flatten[T];
lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k, i, j]], {i, 3}, {j, 3}], {k, 3}];
resid[cf_] := Select[DeleteDuplicates[Simplify[Flatten[Table[
     lie[cf, T[[All, i]], T[[All, j]]] - T . lie[cf, T[[All, i]], e[[j]]], {i, 3}, {j, 3}]]]], # =!= 0 &];
scJ = SparseArray[{{2, 1, 2} -> 1, {2, 2, 1} -> -1, {2, 1, 3} -> 1, {2, 3, 1} -> -1,
    {3, 1, 3} -> 1, {3, 3, 1} -> -1}, {3, 3, 3}];
rawJ = resid[scJ];
a = t[1, 1]; bb = {t[1, 2], t[1, 3]}; gam = {t[2, 1], t[3, 1]};
M = {{t[2, 2], t[2, 3]}, {t[3, 2], t[3, 3]}}; AJ = {{1, 1}, {0, 1}};
redJ = Flatten[{bb, Flatten[M . AJ . M - a AJ . M], M . AJ . gam, a (M . AJ - AJ . M)}];
Print["  raw ==> reduced : ", Reduce[Implies[And @@ Thread[rawJ == 0], And @@ Thread[redJ == 0]], vars, Reals] === True];
Print["  reduced ==> raw : ", Reduce[Implies[And @@ Thread[redJ == 0], And @@ Thread[rawJ == 0]], vars, Reals] === True];

Print["===== M6: [g_D,im T] = D gamma + D M n + span{a,b1,b2} D n（随机 T，无需是解） ====="];
brD[As_, x_, y_] := {0, x[[1]] As . y[[2 ;; 3]] - y[[1]] As . x[[2 ;; 3]]};
rowR[As_, T_, x_, y_] := T . brD[As, x, y];   (* 直接计算 [g,im T] 中的向量 *)
genR[As_, T_] := Module[{a, bb, gam, MM, S, cols},
  a = T[[1, 1]]; bb = {T[[1, 2]], T[[1, 3]]}; gam = {T[[2, 1]], T[[3, 1]]};
  MM = {{T[[2, 2]], T[[2, 3]]}, {T[[3, 2]], T[[3, 3]]}};
  S = {a, bb[[1]], bb[[2]]};
  (* 直接: 所有 [e_i, T e_j] 是否落在 ker T *)
  direct = Max[Abs[Flatten[Table[rowR[As, T, UnitVector[3, i], T . UnitVector[3, j]], {i, 3}, {j, 3}]]]];
  (* 公式: z in D gam + D M n + S D n 上要求 M z = 0, bb^T z = 0 *)
  zs = {As . gam, As . MM . {1, 0}, As . MM . {0, 1}, S[[1]] As . {1, 0}, S[[1]] As . {0, 1},
    S[[2]] As . {1, 0}, S[[2]] As . {0, 1}, S[[3]] As . {1, 0}, S[[3]] As . {0, 1}};
  form = Max[Abs[Flatten[Table[{MM . z, bb . z}, {z, zs}]]]];
  {direct, form}];
Do[
  As = Which[k == 1, {{1, 1}, {0, 1}}, k == 2, {{1, -1}, {1, 1}}, k == 3, {{1, 0}, {0, 0}}, True, IdentityMatrix[2]];
  bad = 0;
  Do[T = RandomReal[{-3, 3}, {3, 3}];
    {d1, f1} = genR[As, T];
    If[(d1 < 10^-8) =!= (f1 < 10^-8), bad++], {40}];
  Print["  ", {"r(J)", "r(c)", "r(1,0)", "r_3"}[[k]], " : 40 个随机 T 上，直接判定与公式判定不一致数 = ", bad];
  , {k, 4}];

Print["===== 完成 ====="];

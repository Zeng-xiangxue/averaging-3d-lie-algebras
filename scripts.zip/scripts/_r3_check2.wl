(* fix B: mu=0 nilpotent-D family, gamma in ker D (column-vector direction). 
   D = {{0,t},{0,0}} : ker D = span(e1).  gamma = (r, 0).  a = 0. *)
ClearAll["Global`*"];
sc = SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== mu=0: D nilpotent nonzero, a=0, gamma in ker D = span(e1) =="];
Do[
  t0 = RandomReal[{-3,3}, 1][[1]]; If[Abs[t0] < 0.1, t0 = 1];
  r = RandomReal[{-2,2}, 1][[1]];
  (* T: e1->(0, r, 0), e2->0, e3->(0, t0, 0):  T = {{0,0,0},{r,0,t0},{0,0,0}} *)
  T = {{0,0,0},{r,0,t0},{0,0,0}};
  Print["  t=", t0, " gamma=(", r, ",0): resid = ", resid[T]],
  {4}];
(* other nilpotent: D = {{0,0},{t,0}}, ker D = span(e2), gamma = (0, r) *)
Print["== mu=0, D={{0,0},{t,0}}, ker D = span(e2), gamma=(0,r) =="];
Do[
  t0 = RandomReal[{-3,3}, 1][[1]]; If[Abs[t0] < 0.1, t0 = 1];
  r = RandomReal[{-2,2}, 1][[1]];
  T = {{0,0,0},{0,0,0},{r,t0,0}};
  Print["  t=", t0, " gamma=(0,", r, "): resid = ", resid[T]],
  {2}];
(* sanity: gamma NOT in ker D must fail *)
Print["== negative: gamma=(0,1) not in ker D =="];
Print["  resid = ", resid[{{0,0,0},{0,0,2},{1,0,0}}]];

(* a3 + so(3) essentials (fast): 
   a3: 27 components identically zero, Aut = GL(3) via random M, e1 e2^T nonsymmetric solution.
   so(3): diagonal reduction (eq:diag), positive/negative residuals. *)
ClearAll["Global`*"];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
TT = Table[t[i,j], {i,3}, {j,3}];

Print["== a3 (abelian) =="];
sc0 = SparseArray[{}, {3,3,3}];
eqs0 = Flatten[Table[lie[sc0, TT[[All,i]], TT[[All,j]]] - TT . lie[sc0, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]];
Print["  all 27 components identically zero? ", Union[eqs0] === {0}];
M0 = {{2,1,0},{0,-3,1},{1,0,4}};
Print["  det random M = ", Det[M0], ";  trivially an automorphism (no brackets to preserve)"];
Tns = KroneckerProduct[{1,0,0},{0,1,0}];
Print["  e1 e2^T nonsymmetric? ", Tns =!= Transpose[Tns], ";  solution on a3 (trivially)"];

Print["== so(3): diagonal reduction and residuals =="];
sc = SparseArray[{{1,2,3}->1, {2,3,1}->1, {3,1,2}->1, {2,1,3}->-1, {3,2,1}->-1, {1,3,2}->-1}, {3,3,3}];
Td = DiagonalMatrix[{q1,q2,q3}];
eqd = Simplify[Flatten[Table[
  lie[sc, Td[[All,i]], Td[[All,j]]] - Td . lie[sc, Td[[All,i]], unit[[j]]], {i,3}, {j,3}]]];
Print["  diag equations (should be q1(q2-q3), q2(q3-q1), q3(q1-q2)-type): "];
Print["  ", Union[DeleteCases[eqd, 0]]];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
Print["  diag(1,1,0) resid = ", resid[DiagonalMatrix[{1,1,0}]]];
Print["  diag(1,0,1) resid = ", resid[DiagonalMatrix[{1,0,1}]]];
Print["  e1 e2^T    resid = ", resid[KroneckerProduct[{1,0,0},{0,1,0}]]];
Print["  e1 e1^T    resid = ", resid[KroneckerProduct[{1,0,0},{1,0,0}]], "  (solution)  tr=1"];
Print["  Id         resid = ", resid[IdentityMatrix[3]]];
Print["  diag(2,2,2) resid = ", resid[DiagonalMatrix[{2,2,2}]], "  (2 Id, solution)"];

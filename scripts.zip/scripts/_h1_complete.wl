(* h1 averaging: complete solution set, derived by merging the 8 Solve branches.
   Claim:  T is averaging  <=>  T in A ∪ B ∪ D, where
     A: Te3 = 0 and (Te1)_1 (Te2)_2 = (Te1)_2 (Te2)_1      (5 params)
     B: im T subset span(e3): T = {{0,0,0},{0,0,0},{a,b,c}}  (3 params)
     D: T = {{a,0,0},{0,a,0},{u,v,a}}, a != 0                (3 params)
   (My earlier claimed family with w || e2 is NOT a solution: [w,e1] forces w=0.)
   Verification: numeric residual checks + symbolic classification of the 8 Solve branches. *)
ClearAll["Global`*"];
sc = SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
T = Array[t, {3,3}];
avg[cf_,i_,j_] := lie[cf, T[[All,i]], T[[All,j]]] - T . lie[cf, T[[All,i]], unit[[j]]];
eqs = DeleteDuplicates[Flatten[Table[avg[sc,i,j], {i,3}, {j,3}]]];
Print["#eq (h1) = ", Length[eqs]];

resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== Family A (Te3=0, u1 v2 = u2 v1), 50 random samples =="];
badA = 0;
Do[
  {u1,u2,u3,v1,v2,v3} = RandomReal[{-3,3}, 6];
  (* force u1 v2 = u2 v1: parametrize by s, and v2 = s u1/u2 style; simpler: u2 v1 = u1 v2 *)
  MT = {{u1, v1, 0}, {u2, v2, 0}, {u3, v3, 0}} /. {v2 -> (u2 v1)/u1};
  r = resid[MT];
  If[r > 1*^-9, badA++; Print["  FAIL: ", MT, " resid ", r]], {50}];
Print["  A: bad = ", badA];

Print["== Family B (im T in span e3) =="];
Do[
  MT = {{0,0,0},{0,0,0}, RandomReal[{-3,3}, 3]};
  Print["  B sample resid = ", resid[MT]], {3}];

Print["== Family D (T = {{a,0,0},{0,a,0},{u,v,a}}, a != 0) =="];
Do[
  a = RandomReal[{-3,3}, 1][[1]]; If[a == 0, a = 1];
  MT = {{a,0,0},{0,a,0}, RandomReal[{-3,3}, 2] ~Join~ {a}};
  Print["  D sample resid = ", resid[MT]], {3}];

Print["== Negative control: my earlier (wrong) family w || e2 =="];
Do[
  w2 = RandomReal[{-3,3}, 1][[1]]; If[w2 == 0, w2 = 1];
  MT = {{0,0,0},{0,0,w2}, RandomReal[{-3,3}, 2] ~Join~ {0}};
  Print["  w=(0,", w2, ",0): resid = ", resid[MT]], {3}];

Print["== Cross-check: the 8 Solve branches all fall into A / B / D =="];
(* branch conditions re-encoded as membership tests *)
inA[MT_] := Norm[MT[[All,3]]] == 0 && MT[[1,1]]*MT[[2,2]] - MT[[1,2]]*MT[[2,1]] == 0;
inB[MT_] := Norm[MT[[1 ;; 2, All]]] == 0;
inD[MT_] := MT[[1,2]] == 0 && MT[[1,3]] == 0 && MT[[2,1]] == 0 && MT[[2,3]] == 0 &&
            MT[[1,1]] == MT[[2,2]] && MT[[1,1]] == MT[[3,3]] && MT[[1,1]] != 0;
(* 8 branches as matrices with free params; test generic representatives *)
branches = {
  {{t11, t12, 0}, {t21, (t12*t21)/t11, 0}, {t31, t32, 0}},               (* [1]: u1,v1 != 0 *)
  {{0, 0, 0}, {t21, t22, 0}, {t31, t32, 0}},                             (* [2] *)
  {{0, t12, 0}, {0, t22, 0}, {t31, t32, 0}},                             (* [3] *)
  {{t11, t12, 0}, {0, 0, 0}, {t31, t32, 0}},                             (* [4] *)
  {{0, 0, 0}, {0, t22, 0}, {t31, t32, 0}},                               (* [5] *)
  {{t11, 0, 0}, {0, 0, 0}, {t31, t32, 0}},                               (* [6] *)
  {{t11, 0, 0}, {0, t11, 0}, {t31, t32, t11}},                           (* [7]: D *)
  {{0, 0, 0}, {0, 0, 0}, {0, 0, t33}}                                    (* [8]: B *)
};
Do[
  M = branches[[k]];
  Print["  branch ", k, ": in A? ", Simplify[inA[M]], "  in B? ", Simplify[inB[M]], "  in D? ", Simplify[inD[M] && t11 != 0]],
  {k, 8}];

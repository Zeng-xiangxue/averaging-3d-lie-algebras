ClearAll["Global`*"];
sc0 = SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}];
sc = Normal[sc0 - Transpose[sc0, {1,3,2}]];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}]; vars = Flatten[T];
comp[i_,j_] := lie[sc, T[[All,i]], T[[All,j]]] - T . lie[sc, T[[All,i]], unit[[j]]];
eqs = Select[DeleteDuplicates[Flatten[Table[comp[i,j], {i,3},{j,3}]]], # =!= 0 &];
trT = Sum[t[i,i], {i,3}];
resid[MT_] := Max[Abs[Flatten[Table[lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
show[tag_, extra_] := Module[{sol, M0},
  sol = TimeConstrained[FindInstance[Join[Thread[eqs == 0], extra], vars, Reals, 1], 120, "TO"];
  If[sol === "TO", Print["  ", tag, " : TIMEOUT"],
   If[sol === {}, Print["  ", tag, " : no real solution"],
    M0 = Round[Partition[Flatten[vars /. sol[[1]]], 3], 0.001];
    Print["  ", tag, " : T = ", MatrixForm[M0], "  tr = ", Round[Tr[M0], 10^-8],
      "  resid = ", Round[resid[M0], 10^-8],
      "  scalar? ", Max[Abs[M0 - Tr[M0]/3 IdentityMatrix[3]]] < 10^-6]]]];
Print["== search for real solutions =="];
show["tr T = 3, t12 = 1", {trT == 3, t[1,2] == 1}];
show["tr T = 3, t12 = 2", {trT == 3, t[1,2] == 2}];
show["t12 = 1 (any trace)", {t[1,2] == 1}];
show["t13 = 1 (any trace)", {t[1,3] == 1}];
show["tr T = 3, t13 = 1", {trT == 3, t[1,3] == 1}];
show["tr T = 0, t12 = 1", {trT == 0, t[1,2] == 1}];
show["tr T = 3, t11 - t22 = 1", {trT == 3, t[1,1] - t[2,2] == 1}];

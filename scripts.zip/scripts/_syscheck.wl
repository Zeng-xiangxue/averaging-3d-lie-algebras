(* _syscheck.wl :  double implication (raw 27 equations  <=>  reduced system) for h1 and r(c) *)
ClearAll["Global`*"];
e = IdentityMatrix[3]; T = Array[t, {3, 3}]; vars = Flatten[T];
resid[cf_] := Select[DeleteDuplicates[Simplify[Flatten[Table[
   lie[cf, T[[All, i]], T[[All, j]]] - T . lie[cf, T[[All, i]], e[[j]]], {i, 3}, {j, 3}]]]], # =!= 0 &];
lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k, i, j]], {i, 3}, {j, 3}], {k, 3}];

(* h1 *)
scH = SparseArray[{{3, 1, 2} -> 1, {3, 2, 1} -> -1}, {3, 3, 3}];
rawH = resid[scH];
redH = {t[1, 3], t[2, 3],                                   (* b = 0 *)
        t[1, 1] t[2, 2] - t[1, 2] t[2, 1],                  (* det X = 0 *)
        t[3, 3] t[1, 1], t[3, 3] t[2, 2]};                  (* lambda t11 = lambda t22 = 0 *)
Print["h1 : #raw = ", Length[rawH]];
Print["h1 : raw ==> reduced  : ", Reduce[Implies[And @@ Thread[rawH == 0], And @@ Thread[redH == 0]], vars, Reals] === True];
Print["h1 : reduced ==> raw  : ", Reduce[Implies[And @@ Thread[redH == 0], And @@ Thread[rawH == 0]], vars, Reals] === True];

(* r(c), c = 1 *)
scC = SparseArray[{{2, 1, 2} -> 1, {2, 2, 1} -> -1, {3, 1, 2} -> 1, {3, 2, 1} -> 1,
                  {2, 1, 3} -> -1, {2, 3, 1} -> 1, {3, 1, 3} -> 1, {3, 3, 1} -> -1}, {3, 3, 3}];
rawC = resid[scC];
M = {{t[2, 2], t[2, 3]}, {t[3, 2], t[3, 3]}}; gam = {t[2, 1], t[3, 1]}; A = {{1, -1}, {1, 1}}; a = t[1, 1];
redC = Flatten[{t[1, 2], t[1, 3], Flatten[M . A . M - a A . M], M . A . gam, a (M . A - A . M)}];
Print["r(c): #raw = ", Length[rawC]];
Print["r(c): raw ==> reduced : ", Reduce[Implies[And @@ Thread[rawC == 0], And @@ Thread[redC == 0]], vars, Reals] === True];
Print["r(c): reduced ==> raw : ", Reduce[Implies[And @@ Thread[redC == 0], And @@ Thread[rawC == 0]], vars, Reals] === True];

(* Independent check of the r3 setup and branch structure.
   Key derivations: beta=0 system is D gamma = 0 and D^2 = a D.
   Verify: (A) branch I parameterization of gamma; (B) mu=0 nilpotent-D family;
   (C) the six preview classes are averaging; (D) beta != 0 impossible. *)
ClearAll["Global`*"];
sc = SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== A. branch I: gamma parameterization =="];
(* D = {{mu, t23},{t32, mu}}, t23 t32 = mu^2, a = 2 mu.  D gamma = 0: *)
Dm = {{mu, t23}, {t32, mu}};
gI = {t21, t31};
eqsI = Simplify[Dm . gI];
Print["  D gamma = ", eqsI];
Print["  component 1: t31 = ", Simplify[Solve[eqsI[[1]] == 0, t31][[1,1,2]]], "  (=-mu t21/t23)  component 2: t31 = ", 
  Simplify[Solve[eqsI[[2]] == 0, t31][[1,1,2]]], "  (=-t32 t21/mu)"];
Print["  user's formula t31 = -mu t21/t32 : both agree only if t23=t32; correct formulas: -mu t21/t23  (t23!=0)  or  -t32 t21/mu  (t32!=0, mu!=0)"];

Print["== B. mu = 0: D nilpotent (nonzero allowed), a = 0, gamma in ker D =="];
(* D = {{0, t},{0,0}} : nilpotent, check it solves D^2 = aD with a=0 and T is averaging *)
Do[
  t0 = RandomReal[{-3,3}, 1][[1]]; If[Abs[t0] < 0.1, t0 = 1];
  g0 = RandomReal[{-1,1}, 2] . {{0,1},{0,0}}; (* gamma in ker D = span(e2) *)
  T = {{0,0,0},{g0[[1]],0,t0},{g0[[2]],0,0}};
  Print["  D={{0,", t0, "},{0,0}}, gamma=( ", g0[[1]], ", ", g0[[2]], "): resid = ", resid[T]],
  {3}];
Print["  canonical: T = e2 e3^T (D={{0,1},{0,0}}, gamma=0): resid = ", resid[{{0,0,0},{0,0,1},{0,0,0}}]];

Print["== C. the six preview classes are averaging =="];
forms6 = <|
  "1  T=0"              -> {{0,0,0},{0,0,0},{0,0,0}},
  "2  e2e1^T"           -> {{0,0,0},{1,0,0},{0,0,0}},
  "3  e2e3^T"           -> {{0,0,0},{0,0,1},{0,0,0}},
  "4  a e1e1^T"         -> {{3,0,0},{0,0,0},{0,0,0}},
  "5  a(e1e1^T+e2e2^T)" -> {{3,0,0},{0,3,0},{0,0,0}},
  "6  a Id3"            -> {{3,0,0},{0,3,0},{0,0,3}}|>;
Do[r = resid[forms6[k]]; Print["  ", k, ": resid = ", r, "  averaging? ", r == 0], {k, Keys[forms6]}];

Print["== D. beta != 0 impossible (numerical probe + normalized GB) =="];
(* random beta != 0 matrices should all have nonzero residual *)
Do[
  Tb = {{0, bt1, bt2}, {g1, d11, d12}, {g2, d21, d22}};
  Tb[[1,2]] = 1; Tb[[1,3]] = 0.5; (* beta = (1, 0.5) != 0, a=0 *)
  Do[Tb[[i,j]] = RandomReal[{-2,2}], {i,2,3}, {j,1,3}];
  Print["  beta=(1,0.5), random rest: resid = ", resid[Tb]],
  {3}];

Print["== E. gamma normalization: D=a=0 keeps gamma; otherwise gamma -> 0 =="];
(* check im(aI-D) = ker D for rank-1 D with tr D = a: *)
Do[
  a0 = RandomReal[{0.5,3}, 1][[1]];
  M0 = RandomReal[{-1,1}, {2,2}];
  D1 = M0 . {{a0,0},{0,0}} . Inverse[M0];
  rkAD = MatrixRank[a0 IdentityMatrix[2] - D1];
  Print["  a=", a0, " rank(aI-D) = ", rkAD, " (expect 1), rank D = ", MatrixRank[D1], " (expect 1), im subset ker D: ", 
    Max[Abs[(a0 IdentityMatrix[2] - D1) . D1]] < 10^-12],
  {3}];
(* D=0, a!=0: im(aI) = R^2, gamma fully erasable *)
Print["  D=0, a!=0: rank(aI-0) = ", MatrixRank[3 IdentityMatrix[2]], " (expect 2, gamma erasable)"];

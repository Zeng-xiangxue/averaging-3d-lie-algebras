(* h1 Aut-normalization: verify all canonical forms (A and B families), 
   complete the nilpotent X-branch, check pairwise inequivalence. *)
ClearAll["Global`*"];
sc = SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

Print["== 1. all canonical forms are averaging operators =="];
forms = <|
  "T=0"          -> {{0,0,0},{0,0,0},{0,0,0}},
  "e3 e1^T"      -> {{0,0,0},{0,0,0},{1,0,0}},
  "r e3 e3^T"    -> {{0,0,0},{0,0,0},{0,0,3}},
  "s e1 e1^T"    -> {{2,0,0},{0,0,0},{0,0,0}},
  "diag(s,0)+Z(0,1)" -> {{2,0,0},{0,0,0},{0,1,0}},
  "N + Z(1,0)"   -> {{0,1,0},{0,0,0},{1,0,0}},
  "N + Z(0,0)"   -> {{0,1,0},{0,0,0},{0,0,0}}|>;
Do[
  r = resid[forms[k]];
  Print["  ", k, ": resid = ", r, "  averaging? ", r == 0],
  {k, Keys[forms]}];

Print["== 2. nilpotent branch: orbit normalization via stabilizer {aI+bN} =="];
(* T = (N, Z), N={{0,1},{0,0}}.  M = {{a,b},{0,a}} stabilizes N, w=(w1,w2) free.
   Claim: Z1 != 0  ->  orbit hits Z=(1,0);  Z1 = 0  ->  orbit hits Z=(0,0). *)
Do[
  {z1, z2} = RandomReal[{-3,3}, 2]; If[z1 == 0, z1 = 1];
  (* target Z'=(1,0): choose a' = z1 (so Z'1 = z1/a' = 1), b'=0, w1 solves Z'2 = 0 *)
  (* inverse relation: M = {{1/a', -b'/a'^2},{0,1/a'}} with a'=z1, b'=0 -> M = {{1/z1,0},{0,1/z1}} *)
  M = {{1/z1, 0}, {0, 1/z1}};  d = Det[M];
  (* Z' = (w^T N + d Z) M^-1 ; w^T N = (0,w1). Solve Z'2 = 0 for w1 *)
  (* Z'2 = (d z2 + w1)/z1  (since M^-1 = {{z1,0},{0,z1}}, row2 col2 entry = z1) *)
  w1 = -d z2; w = {w1, 0};
  phi = {{M[[1,1]], M[[1,2]], 0}, {M[[2,1]], M[[2,2]], 0}, {w[[1]], w[[2]], d}};
  T = {{0,1,0},{0,0,0},{z1,z2,0}};
  Tp = phi . T . Inverse[phi];
  Print["  Z=( ", z1, ", ", z2, ")  ->  T' = ", Tp, "   (expect Z block (1,0))"];
  If[z2 == 0, z2 = 0.5]; (* test Z1=0 branch separately below *)
  ,
  {2}];
Do[
  z2 = RandomReal[{-3,3}, 1][[1]];
  (* Z1=0: target Z'=(0,0); take M=Id, w1 = -d z2 *)
  M = IdentityMatrix[2]; d = Det[M]; w = {-d z2, 0};
  phi = {{M[[1,1]], M[[1,2]], 0}, {M[[2,1]], M[[2,2]], 0}, {w[[1]], w[[2]], d}};
  T = {{0,1,0},{0,0,0},{0,z2,0}};
  Tp = phi . T . Inverse[phi];
  Print["  Z=( 0, ", z2, ")  ->  T' = ", Tp, "   (expect Z block (0,0))"],
  {2}];

Print["== 3. pairwise inequivalence invariants (tr X, rank T, Te3 nullity, Z-flag) =="];
Do[
  T0 = forms[k];
  X = T0[[1;;2, 1;;2]]; 
  Print["  ", k, ": tr X = ", Tr[X], "  rank T = ", MatrixRank[T0], "  Te3 = ", T0[[All,3]], "  Z = (", T0[[3,1]], ",", T0[[3,2]], ")"],
  {k, Keys[forms]}];

Print["== 4. B-family check: r is Aut-invariant (x3 coefficient fixed) =="];
(* phi T phi^-1 has x3 coefficient exactly r *)
Do[
  r0 = RandomReal[{-3,3}, 1][[1]]; If[r0 == 0, r0 = 1];
  M = RandomReal[{-1,1}, {2,2}] + 2 IdentityMatrix[2]; d = Det[M];
  w = RandomReal[{-1,1}, 2];
  phi = {{M[[1,1]], M[[1,2]], 0}, {M[[2,1]], M[[2,2]], 0}, {w[[1]], w[[2]], d}};
  T = {{0,0,0},{0,0,0},{1,2,r0}};
  Tp = phi . T . Inverse[phi];
  Print["  r = ", r0, ": x3 coeff of T' = ", Tp[[3,3]], "  (invariant = r)  resid(T') = ", resid[Tp]],
  {3}];

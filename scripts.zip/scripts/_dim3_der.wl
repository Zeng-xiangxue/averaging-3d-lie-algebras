(* dim Der(g) for the six 3-dim real Lie algebras; Aut(g) is proper in GL(3) iff this is < 9 *)
ClearAll["Global`*"];
sc = Association[
  "a3"   -> Table[0, {3}, {3}, {3}],
  "h1"   -> SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}],
  "r3"   -> SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->1, {3,3,1}->-1}, {3,3,3}],
  "r3lam"-> SparseArray[{{2,1,2}->1, {2,2,1}->-1, {3,1,3}->la, {3,3,1}->-la}, {3,3,3}],
  "sl2"  -> SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}],
  "so3"  -> SparseArray[{{3,1,2}->1, {3,2,1}->-1, {2,1,3}->-1, {2,3,1}->1, {1,2,3}->1, {1,3,2}->-1}, {3,3,3}]
];
Do[
  cf = sc[al];
  dd = Table[ddm[i, j], {i, 3}, {j, 3}];
  derPoly = Flatten[Table[
    Sum[dd[[p,i]] cf[[k,p,j]] + dd[[p,j]] cf[[k,i,p]] - cf[[p,i,j]] dd[[k,p]], {p,3}],
    {k,3}, {i,3}, {j,3}]];
  coef = ArrayReshape[Table[Coefficient[derPoly[[r]], dd[[a,b]]], {r, Length[derPoly]}, {a,3}, {b,3}], {Length[derPoly], 9}];
  Print[al, " : dim Der = ", 9 - MatrixRank[coef]],
  {al, {"a3","h1","r3","r3lam","sl2","so3"}}];

ClearAll["Global`*"];
eB = IdentityMatrix[3]; ord = DegreeReverseLexicographic;
A = Array[aa, {3, 3}]; vars = Flatten[A];
av = Select[DeleteDuplicates[Flatten[Table[
     Cross[A . eB[[i]], A . eB[[j]]] - A . Cross[A . eB[[i]], eB[[j]]],
     {i, 3}, {j, 3}]]], # =!= 0 &];
fs = {A[[1, 2]] - A[[2, 1]], A[[1, 3]] - A[[3, 1]], A[[2, 3]] - A[[3, 2]]};
Print["so(3) AVERAGING: do solutions with f != 0 exist over C ?"];
Do[
  c = TimeConstrained[GroebnerBasis[Join[av, {fs[[k]] - 1}], vars,
      MonomialOrder -> ord], 120, "TO"];
  Print["  ", fs[[k]], " - 1 :  inconsistent ({1})? ",
   If[c === "TO", "TIMEOUT", c === {1}]],
  {k, 3}];
Print["{1} for all three  =>  every complex solution is symmetric."];
Print[""];
Print["(recall: the ideal is NOT radical, so 'f not in the ideal' alone"];
Print[" proves nothing -- one has to run this consistency test.)"];

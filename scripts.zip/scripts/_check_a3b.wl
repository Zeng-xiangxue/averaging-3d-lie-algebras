ClearAll["Global`*"];
unit = IdentityMatrix[3];
cf = Table[0, {3}, {3}, {3}];        (* abelian: all structure constants zero *)
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];
T = Array[t,{3,3}];
comp[i_,j_] := lie[cf, T[[All,i]], T[[All,j]]] - T . lie[cf, T[[All,i]], unit[[j]]];
Print["== a3 =="];
Print["   all 27 component equations identically zero? ",
  Simplify[Flatten[Table[comp[i,j], {i,3},{j,3}]]] === ConstantArray[0,27]];
Print["   => every linear map is an averaging operator (9 free parameters)"];
Do[M = RandomReal[{-2,2},{3,3}]; If[Abs[Det[M]] < 0.3, M = M + 1.3 IdentityMatrix[3]];
  Print["   random M (det=", Round[Det[M],0.01], ") preserves the bracket? ",
    Max[Abs[Flatten[Table[lie[cf, M[[All,i]], M[[All,j]]] - M . lie[cf, unit[[i]], unit[[j]]], {i,3},{j,3}]]]] == 0], {2}];
Print[""];
Print["== rational canonical types (parametrisation and parameter count) =="];
samples = {
  {"scalar lambda I (1 param)", 2 unit},
  {"diag(2, companion of (x-1)(x-2)) = diag(2,{{0,-2},{1,3}}) (2 params)", {{2,0,0},{0,0,-2},{0,1,3}}},
  {"companion of x^3-6x^2+11x-6, eigenvalues 1,2,3 (3 params)", {{0,0,6},{1,0,-11},{0,1,6}}},
  {"3x3 Jordan block J3(1) = companion of (x-1)^3", {{0,0,1},{1,0,-3},{0,1,3}}}
};
Do[M = samples[[k,2]];
  Print["   ", samples[[k,1]]];
  Print["      char poly = ", Factor[CharacteristicPolynomial[M, x]],
    "   min poly = ", Factor[MinimalPolynomial[M, x]],
    "   rank = ", MatrixRank[M]], {k, Length[samples]}];

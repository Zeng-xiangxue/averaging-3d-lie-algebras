(* =====================================================================
   _r10_verify.wl  ---  r(1,0): solution system, residuals, 120-pair test
   basis e1,e2,e3 ; [e1,e2] = e2 , [e1,e3] = 0
   T = (a  beta^T ; gamma  M)   with beta = (b1,b2)^T , gamma = (g1,g2)^T
   ===================================================================== *)
ClearAll["Global`*"];
br[x_, y_] := {0, x[[1]] y[[2]] - y[[1]] x[[2]], 0};
e = IdentityMatrix[3];
T = {{a, b1, b2}, {g1, m11, m12}, {g2, m21, m22}};
vars = {a, b1, b2, g1, g2, m11, m12, m21, m22};
raw = Select[DeleteDuplicates[Flatten[Table[
   br[T.e[[i]], T.e[[j]]] - T.br[T.e[[i]], e[[j]]], {i, 3}, {j, 3}]]], # =!= 0 &];
paper = {b1, m11 (m11 - a), m11 g1, m11 b2, m11 m12,
   b2 g1 - a m12, m21 a, m21 g1, m21 b2, m21 m12};
Print["raw equations : ", Length[raw]];
Print["  raw  ==> paper (Thm 3.14 conditions) : ",
   Reduce[Implies[And @@ (raw == 0), And @@ (paper == 0)], vars, Reals] === True];
Print["  paper ==> raw                       : ",
   Reduce[Implies[And @@ (paper == 0), And @@ (raw == 0)], vars, Reals] === True];

resid[TT_] := Max[Abs[Flatten[Table[
   br[TT.e[[i]], TT.e[[j]]] - TT.br[TT.e[[i]], e[[j]]], {i, 3}, {j, 3}]]]];
lab = {"1 0", "2 e21", "3 e31", "4 e21+e31", "5 aId", "6 aId+e31",
   "7 diag(a,0,a)", "8 diag(a,0,a)+e31", "9 mu e33", "10 e21+mu e33",
   "11 e32+mu e33", "12 e23+mu e33", "13 e23+e31+mu e33",
   "14 diag(a,0,mu)", "15 diag(a,a,mu)", "16 e13+g e31+mu e33"};
forms = {
  {{0,0,0},{0,0,0},{0,0,0}},
  {{0,0,0},{1,0,0},{0,0,0}},
  {{0,0,0},{0,0,0},{1,0,0}},
  {{0,0,0},{1,0,0},{1,0,0}},
  {{2,0,0},{0,2,0},{0,0,2}},
  {{2,0,0},{0,2,0},{1,0,2}},
  {{2,0,0},{0,0,0},{0,0,2}},
  {{2,0,0},{0,0,0},{1,0,2}},
  {{0,0,0},{0,0,0},{0,0,3}},
  {{0,0,0},{1,0,0},{0,0,3}},
  {{0,0,0},{0,0,0},{0,1,3}},
  {{0,0,0},{0,0,1},{0,0,3}},
  {{0,0,0},{0,0,1},{1,0,3}},
  {{2,0,0},{0,0,0},{0,0,5}},
  {{2,0,0},{0,2,0},{0,0,5}},
  {{0,0,1},{0,0,0},{2,0,3}}};
Print[""];
Print["residuals (all must be 0):"];
Do[Print["   ", lab[[k]], "   resid = ", resid[forms[[k]]]], {k, Length[forms]}];
Print["   negative control  diag(2,0,3)+e32 :  resid = ",
   resid[{{2,0,0},{0,0,0},{0,1,3}}]];

phi = {{1,0,0},{w1,p,0},{w2,0,s}};
conjQ[T1_, T2_] := Module[{eqs, gb},
  eqs = Numerator /@ Together /@ Flatten[phi.T1.Inverse[phi] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p s}], {p, s, w1, w2, z},
       MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
Print[""];
Print["120 pairs (must all be False = mutually non-conjugate):"];
bad = 0; tot = 0;
Do[If[i < j, tot++; If[conjQ[forms[[i]], forms[[j]]], bad++; Print["   CONJUGATE: ", lab[[i]], " ~ ", lab[[j]]]]],
  {i, Length[forms]}, {j, Length[forms]}];
Print["   pairs tested = ", tot, " ; conjugacies found = ", bad];
Print[""];
Print["conjugacy controls (must be True):"];
Print["   e23+2e31+3e33 ~ e23+e31+3e33   : ", conjQ[{{0,0,0},{0,0,1},{2,0,3}}, {{0,0,0},{0,0,1},{1,0,3}}]];
Print["   e32+e31 ~ e32                 : ", conjQ[{{0,0,0},{0,0,0},{1,1,0}}, {{0,0,0},{0,0,0},{0,1,0}}]];
Print["   diag(2,0,0)+4e21+5e31 ~ 2e11  : ", conjQ[{{2,0,0},{4,0,0},{5,0,0}}, {{2,0,0},{0,0,0},{0,0,0}}]];
Print["   e13+2e31+3e33 ~ e13+7e31+3e33 (must be False): ",
   conjQ[{{0,0,1},{0,0,0},{2,0,3}}, {{0,0,1},{0,0,0},{7,0,3}}]];

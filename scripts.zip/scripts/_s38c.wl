(* ===== r(1,0): completeness of the 16-class list, branch by branch ===== *)
(* every solution of the system is conjugate to one of the canonical forms   *)
ClearAll["Global`*"];
E11 = {{1,0,0},{0,0,0},{0,0,0}}; E22 = {{0,0,0},{0,1,0},{0,0,0}}; E33 = {{0,0,0},{0,0,0},{0,0,1}};
E12 = {{0,1,0},{0,0,0},{0,0,0}}; E13 = {{0,0,1},{0,0,0},{0,0,0}};
E21 = {{0,0,0},{1,0,0},{0,0,0}}; E23 = {{0,0,0},{0,0,1},{0,0,0}};
E31 = {{0,0,0},{0,0,0},{1,0,0}}; E32 = {{0,0,0},{0,0,0},{0,1,0}};
phi[p_, s_, w1_, w2_] := {{1, 0, 0}, {w1, p, 0}, {w2, 0, s}};
conj[T_, p_, s_, w1_, w2_] := Simplify[phi[p,s,w1,w2] . T . Inverse[phi[p,s,w1,w2]]];
ok[T_, p_, s_, w1_, w2_, tgt_] := With[{d = Simplify[conj[T,p,s,w1,w2] - tgt]},
  {Max[Abs[Flatten[d]]] === 0, Simplify[d]}];
chk[name_, T_, p_, s_, w1_, w2_, tgt_] := Module[{d},
  d = Simplify[conj[T,p,s,w1,w2] - tgt];
  Print["  ", name, " : ", Simplify[Flatten[d]] === ConstantArray[0, 9]]];

Print["== branch A1: M11 = a = d != 0, beta = 0, g1 = M12 = M21 = 0 =="];
T1 = d (E11 + E22) + mu E33 + g2 E31;
chk["mu != d  ->  diag(d,d,mu)", T1, p, s, w1, s g2/(mu - d), d(E11+E22) + mu E33];
chk["mu = d, g2 != 0  ->  d*Id + e31", d IdentityMatrix[3] + g2 E31, p, 1/g2, w1, 0, d IdentityMatrix[3] + E31];
chk["mu = d, g2 = 0  ->  d*Id", d IdentityMatrix[3], p, s, w1, 0, d IdentityMatrix[3]];

Print["== branch A2: M11 = 0, beta = 0, M21 = m != 0 (a = g1 = M12 = 0) =="];
chk["-> e32 + mu*e33", m E32 + mu E33 + g2 E31, p, s, p g2/m, 0, E32 + mu E33];
chk["(source normalised) e32+mu e33  ->  e32+mu e33",
  E32 + mu E33, p, s, 0, 0, E32 + mu E33];

Print["== branch A3a: M11 = M21 = 0, beta = 0, M12 = m != 0 (a = 0) =="];
T3 = m E23 + mu E33 + g1 E21 + g2 E31;
chk["Delta = 0  ->  e23 + mu*e33", T3, s/m, s, w1, s g1/m, E23 + mu E33];
chk["Delta != 0  ->  e23 + e31 + mu*e33", T3, 1/(m (g2 - mu g1/m)), 1/(g2 - mu g1/m),
  w1, (g1/m)/(g2 - mu g1/m), E23 + E31 + mu E33];

Print["== branch A3b: M = diag(0,mu), beta = 0, data (a,mu,g1,g2) =="];
T4 = a E11 + mu E33 + g1 E21 + g2 E31;
chk["a != 0, mu != a  ->  diag(a,0,mu)", T4, p, s, -p g1/a, -s g2/(a - mu), a E11 + mu E33];
chk["a != 0, mu = a, g2 = 0  ->  diag(a,0,a)", a E11 + a E33 + g1 E21, p, s, -p g1/a, w2, a E11 + a E33];
chk["a != 0, mu = a, g2 != 0  ->  diag(a,0,a)+e31", a E11 + a E33 + g1 E21 + g2 E31,
  p, 1/g2, -p g1/a, 0, a E11 + a E33 + E31];
chk["a = 0, mu != 0, g1 = 0  ->  mu*e33", mu E33 + g2 E31, p, s, w1, s g2/mu, mu E33];
chk["a = 0, mu != 0, g1 != 0  ->  e21 + mu*e33", mu E33 + g1 E21 + g2 E31,
  1/g1, s, w1, s g2/mu, E21 + mu E33];
chk["(0,0), g1 != 0, g2 = 0  ->  e21", g1 E21, 1/g1, s, w1, 0, E21];
chk["(0,0), g1 = 0, g2 != 0  ->  e31", g2 E31, p, 1/g2, w1, 0, E31];
chk["(0,0), g1 != 0, g2 != 0  ->  e21 + e31", g1 E21 + g2 E31, 1/g1, 1/g2, w1, 0, E21 + E31];

Print["== branch B: beta2 != 0 (M11 = M21 = 0, a*M12 = beta2*g1) =="];
TB = a E11 + b2 E13 + g1 E21 + g2 E31 + m12 E23 + m22 E33;
chk["-> e13 + (b2*g2 - a*m22)*e31 + (a+m22)*e33",
  TB, p, b2, -(p/b2) m12, a, E13 + (b2 g2 - a m22) E31 + (a + m22) E33];

Print[""];
Print["== branch decomposition is exhaustive =="];
sys = {b1 == 0, m11 (m11 - a) == 0, m11 g1 == 0, m11 m12 == 0, m11 m21 == 0,
   b2 m11 == 0, a m12 == b2 g1, m21 a == 0, m21 g1 == 0, m21 b2 == 0, m21 m12 == 0};
branches = (m11 != 0) || (m11 == 0 && b2 != 0) || (m11 == 0 && b2 == 0 && m21 != 0) ||
   (m11 == 0 && b2 == 0 && m21 == 0 && m12 != 0) || (m11 == 0 && b2 == 0 && m21 == 0 && m12 == 0);
Print["  every solution lies in one of the five branches : ",
  Reduce[Implies[And @@ sys, branches], {a, b1, b2, g1, g2, m11, m12, m21, m22}, Reals] === True];

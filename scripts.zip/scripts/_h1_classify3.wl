(* ============================================================
   h1: complete classification of averaging operators up to
   Aut(h1)-conjugation  (condition [T x,T y] = T[T x,y]).

   Solution set (verified in _h1_verify2.wl):
     T = [[X,0],[z^T,lam]]  with
       (i)  lam = 0  and  rank X <= 1            (family A)
       (ii) lam != 0 and  X = 0                  (family B)
       (iii)lam != 0 and  X = lam Id2            (family D)
   The previous turn normalised A u B (7 classes) but not D.
   ============================================================ *)
ClearAll["Global`*"];
sc = SparseArray[{{3,1,2}->1, {3,2,1}->-1}, {3,3,3}];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]],{i,3},{j,3}],{k,3}];
resid[MT_] := Max[Abs[Flatten[Table[lie[sc, MT[[All,i]], MT[[All,j]]] -
    MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3},{j,3}]]]];
aut[M_, w_] := {{M[[1,1]], M[[1,2]], 0}, {M[[2,1]], M[[2,2]], 0}, {w[[1]], w[[2]], Det[M]}};
conj[T_, M_, w_] := Module[{phi = aut[M, w]}, phi . T . Inverse[phi]];
Xb[T_] := T[[1 ;; 2, 1 ;; 2]];
zv[T_] := {T[[3,1]], T[[3,2]]};
near[u_, v_] := Max[Abs[Flatten[u - v]]] < 10^-7;
mkA[X_, z_] := Module[{T = ConstantArray[0., {3,3}]}, T[[1;;2,1;;2]] = X; T[[3,1;;2]] = z; T];
unit1 = {{1/Sqrt[2], 0, 0}, {0, 1, 0}, {0, 0, 1}};  (* not used, placeholder *)

forms = <|
  "1  T=0"              -> {{0,0,0},{0,0,0},{0,0,0}},
  "2  e3 e1^T"          -> {{0,0,0},{0,0,0},{1,0,0}},
  "3  A(N,(1,0))"       -> {{0,1,0},{0,0,0},{1,0,0}},
  "4  A(N,0)"           -> {{0,1,0},{0,0,0},{0,0,0}},
  "5  A(diag(s,0),0)"   -> {{2,0,0},{0,0,0},{0,0,0}},
  "6  A(diag(s,0),(0,1))"-> {{2,0,0},{0,0,0},{0,1,0}},
  "7  B(r e3 e3^T)"     -> {{0,0,0},{0,0,0},{0,0,3}},
  "8  D(lam Id,0)"      -> {{3,0,0},{0,3,0},{0,0,3}},
  "9  D(lam Id,(1,0))"  -> {{3,0,0},{0,3,0},{1,0,3}}
|>;
keys = Keys[forms];

Print["== 1. all nine normal forms are averaging operators =="];
Do[Print["   ", k, "   resid = ", resid[forms[k]]], {k, keys}];

Print[""];
Print["== 2. no two normal forms are Aut-conjugate =="];
Print["   (test: is there M with det M != 0 and w with phi T_i = T_j phi ?",
      "  unit ideal = no) ",""];
phiG = {{m11,m12,0},{m21,m22,0},{w1,w2,m11 m22 - m12 m21}};
noConj[Ti_, Tj_] := Module[{sys, gb},
  sys = Flatten[phiG . Ti - Tj . phiG];
  gb = GroebnerBasis[Join[sys, {(m11 m22 - m12 m21) ss - 1}],
        {m11, m12, m21, m22, w1, w2, ss}, MonomialOrder -> DegreeReverseLexicographic];
  gb = DeleteCases[gb, 0];
  gb === {1}];
Do[
  If[i < j,
    res = AbsoluteTiming[noConj[forms[keys[[i]]], forms[keys[[j]]]]];
    Print["   ", keys[[i]], "  vs  ", keys[[j]], "   inequivalent: ", res[[2]],
          "  (", Round[res[[1]], 0.01], " s)"]],
  {i, 9}, {j, 9}];
Print["   control (same form, should be conjugate): ",
  noConj[forms[keys[[5]]], forms[keys[[5]]]]];

Print[""];
Print["== 3. subtlety: z = 0 is NOT an Aut-invariant; the real invariants are"];
Print["     z1 for X = N, z2 for X = rank1 with tr X != 0, z for X = 0 or lam Id =="];
M = {{1,0},{0,1}}; w = {1,0};
T0 = forms["4  A(N,0)"]; T0p = conj[T0, M, w];
Print["   (N,0)  --phi(w=(1,0))-->  ", T0p, "   i.e. z = ", zv[T0p],
      "  (z1 = 0 stays 0, z2 is not an invariant)"];
M = IdentityMatrix[2]; w = {-1, 0};
Print["   (N,(0,1))  --phi(w=(-1,0))-->  ", conj[{{0,1,0},{0,0,0},{0,1,0}}, M, w],
      "   so (N,(0,1)) ~ (N,0)"];
Print["   and (N,(1,0)) ~ (N,0) ?  ", Not[noConj[forms["3  A(N,(1,0))"], forms["4  A(N,0)"]]],
      "   (test for a conjugacy; True means they ARE conjugate)"];

Print[""];
Print["== 4. A family: constructive normalisation of random members =="];
Print["   (k=1..4: X = 0 ;  k=5..8: X = N ;  k=9..14: X = u v^T generic)"];
Do[
  z = RandomReal[{-2,2},2];
  Which[
   k <= 4, X = {{0.,0.},{0.,0.}},
   k <= 8, X = {{0.,1.},{0.,0.}},
   True,   u = RandomReal[{-2,2},2]; v = RandomReal[{-2,2},2]; X = Outer[Times,u,v]];
  T = mkA[X, z]; s = Tr[X];
  Which[
   Norm[X] < 10^-9,
     If[Norm[z] < 10^-9,
       Tn = T; tgt = forms["1  T=0"],
       Minv = {{z[[1]]/Norm[z]^2, -z[[2]]}, {z[[2]]/Norm[z]^2, z[[1]]}};
       Tn = conj[T, Inverse[Minv], {0,0}]; tgt = forms["2  e3 e1^T"]],
   Abs[s] < 10^-9,
     col = If[Norm[X[[All,1]]] > 10^-9, X[[All,1]], X[[All,2]]];
     vv = Flatten[Transpose[X].col]/Norm[col]^2;
     M1 = Inverse[{{col[[1]], vv[[1]]}, {col[[2]], vv[[2]]}}];
     T1 = conj[T, M1, {0,0}]; z1 = zv[T1];
     If[Abs[z1[[1]]] > 10^-9,
       a = 1/z1[[1]]; Tn = conj[T1, a IdentityMatrix[2], {-a^2 z1[[2]], 0}];
       tgt = forms["3  A(N,(1,0))"],
       Tn = conj[T1, IdentityMatrix[2], {-z1[[2]], 0}];
       tgt = forms["4  A(N,0)"]],
   True,
     col = If[Norm[X[[All,1]]] > 10^-9, X[[All,1]], X[[All,2]]];
     vv = Flatten[Transpose[X].col]/Norm[col]^2;
     M1 = {{vv[[1]], vv[[2]]}, {-col[[2]], col[[1]]}};
     T1 = conj[T, M1, {0,0}]; z1 = zv[T1];
     If[Abs[z1[[2]]] > 10^-9,
       al = 1/z1[[2]];
       Tn = conj[T1, {{al,0},{0,1}}, {-al*z1[[1]]/s, 0}];
       tgt = {{s,0,0},{0,0,0},{0,1,0}},
       Tn = conj[T1, IdentityMatrix[2], {-z1[[1]]/s, 0}];
       tgt = {{s,0,0},{0,0,0},{0,0,0}}]];
  Print["   k=", k, "  s = ", Round[s,0.001], "  reached target? ", near[Tn, tgt],
        "   (resid = ", resid[Tn], ")"],
  {k, 14}];

Print[""];
Print["== 5. B and D families: constructive normalisation =="];
Do[
  {p, q, r} = RandomReal[{-2,2},3];
  If[k == 1, {p,q,r} = {0,0,0}];
  If[k == 2, {p,q,r} = {RandomReal[{-2,2}], RandomReal[{-2,2}], 0}];
  T = {{0,0,0},{0,0,0},{p,q,r}};
  If[Norm[{p,q}] < 10^-9,
    If[Abs[r] < 10^-9, Tn = T; tgt = forms["1  T=0"],
      Tn = T; tgt = {{0,0,0},{0,0,0},{0,0,r}}],
    If[Abs[r] < 10^-9,
      Minv = {{p/Norm[{p,q}]^2, -q},{q/Norm[{p,q}]^2, p}};
      Tn = conj[T, Inverse[Minv], {0,0}]; tgt = forms["2  e3 e1^T"],
      Tn = conj[T, IdentityMatrix[2], {p/r, q/r}];
      tgt = {{0,0,0},{0,0,0},{0,0,r}}]];
  Print["   B: (p,q,r) = ", Round[{p,q,r},0.01], "  reached? ", near[Tn, tgt]],
  {k, 4}];
Do[
  a = RandomReal[{-3,3}]; If[Abs[a] < 0.3, a = 2.0];
  {uu, vv} = RandomReal[{-2,2},2]; If[k <= 2, {uu,vv} = {0,0}];
  T = {{a,0,0},{0,a,0},{uu,vv,a}};
  If[Norm[{uu,vv}] < 10^-9,
    Tn = T; tgt = {{a,0,0},{0,a,0},{0,0,a}},
    z = {uu, vv};
    Minv = {{z[[1]]/Norm[z]^2, -z[[2]]},{z[[2]]/Norm[z]^2, z[[1]]}};
    Tn = conj[T, Inverse[Minv], {0,0}]; tgt = {{a,0,0},{0,a,0},{1,0,a}}];
  Print["   D: a = ", Round[a,0.01], "  (u,v) = ", Round[{uu,vv},0.01],
        "  reached? ", near[Tn, tgt], "   (resid = ", resid[Tn], ")"],
  {k, 4}];

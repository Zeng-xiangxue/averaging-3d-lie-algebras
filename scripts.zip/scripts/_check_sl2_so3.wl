(* ============================================================
   (A) sl(2,R): structure of A = T - T*  (their claimed components)
   (B) so(3): are all solutions symmetric?  candidate classes?
   ============================================================ *)
ClearAll["Global`*"];
unit = IdentityMatrix[3];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3},{j,3}], {k,3}];

(* ---------- (A) sl2 : antisymmetric part ---------- *)
scA = Normal[SparseArray[{{1,1,2}->1, {2,1,3}->-2, {3,2,3}->1}, {3,3,3}]];
scA = scA - Transpose[scA, {1,3,2}];
T = Array[t,{3,3}]; vars = Flatten[T];
adA[u_] := Table[lie[scA, u, unit[[j]]][[i]], {i,3},{j,3}];
KA = Table[Tr[adA[unit[[i]]] . adA[unit[[j]]]], {i,3},{j,3}];
Asym = Simplify[T - Inverse[KA] . Transpose[T] . KA];
Print["== (A) sl2 : A = T - T* =="];
Print["   A = ", MatrixForm[Asym]];
Print["   distinct non-zero components: ", DeleteDuplicates[Select[Flatten[Asym], # =!= 0 &]]];

(* ---------- (B) so(3) ---------- *)
scB = Normal[SparseArray[{{3,1,2}->1, {2,1,3}->-1, {1,2,3}->1}, {3,3,3}]];
scB = scB - Transpose[scB, {1,3,2}];
Print[""];
Print["== (B) so(3) =="];
Print["   brackets: ", lie[scB, unit[[1]], unit[[2]]], ", ",
      lie[scB, unit[[2]], unit[[3]]], ", ", lie[scB, unit[[3]], unit[[1]]]];
adB[u_] := Table[lie[scB, u, unit[[j]]][[i]], {i,3},{j,3}];
KB = Table[Tr[adB[unit[[i]]] . adB[unit[[j]]]], {i,3},{j,3}];
Print["   Killing form K = ", KB, "  eigenvalues ", Eigenvalues[KB],
      "  definite? ", (Sign[Eigenvalues[KB]] === {-1,-1,-1} || Sign[Eigenvalues[KB]] === {1,1,1})];
TB = Array[q,{3,3}]; varsB = Flatten[TB];
compB[i_,j_] := lie[scB, TB[[All,i]], TB[[All,j]]] - TB . lie[scB, TB[[All,i]], unit[[j]]];
eqsB = Select[DeleteDuplicates[Flatten[Table[compB[i,j], {i,3},{j,3}]]], # =!= 0 &];
residB[MT_] := Max[Abs[Flatten[Table[lie[scB, MT[[All,i]], MT[[All,j]]] -
    MT . lie[scB, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];
Print["   #eq = ", Length[eqsB]];
(* all solutions symmetric? *)
Ab = TB - Transpose[TB];
Do[
  gb = TimeConstrained[GroebnerBasis[Join[eqsB, {Flatten[Ab][[k]] zz - 1}],
        Append[varsB, zz], MonomialOrder -> DegreeReverseLexicographic], 200, "TO"];
  Print["   antisym component ", k, " forced 0 ? ", If[gb === "TO", "TIMEOUT",
     DeleteCases[gb, 0] === {1}]],
  {k, 9}];
(* diagonal solutions *)
eqD = Select[DeleteDuplicates[Flatten[Table[compB[i,j], {i,3},{j,3}]] /.
     {q[1,2]->0, q[1,3]->0, q[2,1]->0, q[2,3]->0, q[3,1]->0, q[3,2]->0}]], # =!= 0 &];
Print["   diagonal case: eqs = ", Simplify[eqD]];
Print["   diagonal solutions: ", Simplify[Solve[eqD == 0, {q[1,1], q[2,2], q[3,3]}, Reals]]];
(* candidate classes *)
candsB = {
  {"0", ConstantArray[0,{3,3}]},
  {"Id", unit},
  {"e1 e1^T", {{1,0,0},{0,0,0},{0,0,0}}},
  {"generic u u^T, u=(1,2,3)/|u|", Outer[Times, {1,2,3}, {1,2,3}]/14},
  {"diag(1,1,0) (rank 2, expect NOT)", {{1,0,0},{0,1,0},{0,0,0}}},
  {"non-symmetric E12", {{0,1,0},{0,0,0},{0,0,0}}}
};
Print[""];
Do[Print["   ", candsB[[k,1]], "   resid = ", residB[candsB[[k,2]]],
     "   symmetric? ", candsB[[k,2]] === Transpose[candsB[[k,2]]],
     "   rank = ", MatrixRank[candsB[[k,2]]]], {k, Length[candsB]}];

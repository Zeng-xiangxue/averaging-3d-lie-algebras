(* Verify the SO(2,1) route premise (fixed Killing form: B(i,j)=Sum_{k,p} c[k,i,p] c[p,j,k]) *)
ClearAll["Global`*"];

scSl2 = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
scSo3 = SparseArray[{{3,1,2}->1, {3,2,1}->-1, {2,1,3}->-1, {2,3,1}->1, {1,2,3}->1, {1,3,2}->-1}, {3,3,3}];

lie[cf_, u_, v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
killing[cf_] := Table[Sum[cf[[m,i,p]] cf[[p,n,m]], {m,3}, {p,3}], {i,3}, {n,3}];

Print["== Killing form matrices =="];
ks = killing[scSl2]; ko = killing[scSo3];
Print["sl(2,R): ", MatrixForm[ks]];
Print["  eigenvalues: ", Eigenvalues[ks], "  det = ", Det[ks]];
Print["so(3)   : ", MatrixForm[ko]];
Print["  eigenvalues: ", Eigenvalues[ko], "  det = ", Det[ko]];

Print["== Ad preserves Killing form: B(ad_x y, z)+B(y, ad_x z)=0 =="];
Do[
  x = RandomReal[{-1,1}, 3]; y = RandomReal[{-1,1}, 3]; z = RandomReal[{-1,1}, 3];
  res = (lie[scSl2,x,y] . ks . z) + (y . ks . lie[scSl2,x,z]);
  Print["sl2 residual: ", res], {3}];
Do[
  x = RandomReal[{-1,1}, 3]; y = RandomReal[{-1,1}, 3]; z = RandomReal[{-1,1}, 3];
  res = (lie[scSo3,x,y] . ko . z) + (y . ko . lie[scSo3,x,z]);
  Print["so3 residual: ", res], {3}];

Print["== ad(e_i) skew w.r.t. Killing: ad(e_i)^T.K + K.ad(e_i) = 0 =="];
adMat[cf_, u_] := Table[Sum[cf[[k,i,j]] u[[j]], {j,3}], {k,3}, {i,3}];
Do[
  {a1,a2,a3} = {adMat[scSl2,{1,0,0}], adMat[scSl2,{0,1,0}], adMat[scSl2,{0,0,1}]};
  Print["sl2: ||ad(e1)^T.K+K.ad(e1)|| etc = ",
    {Norm[Transpose[a1].ks + ks.a1], Norm[Transpose[a2].ks + ks.a2], Norm[Transpose[a3].ks + ks.a3]}],
  {1}];
Do[
  {a1,a2,a3} = {adMat[scSo3,{1,0,0}], adMat[scSo3,{0,1,0}], adMat[scSo3,{0,0,1}]};
  Print["so3: ||ad(e_i)^T.K + K.ad(e_i)|| = ",
    {Norm[Transpose[a1].ko + ko.a1], Norm[Transpose[a2].ko + ko.a2], Norm[Transpose[a3].ko + ko.a3]}],
  {1}];

#!/usr/bin/env wolframscript
(* ==================================================================
   _se3_Z_lambdaI_branches.wl -- verify the 3 global-Solve branches of
   Region Z A = lam*I, in GENERAL lam:
     branch 1: B=0, C = skew (ad_u),  D=0          (Region Y member)
     branch 2: B=0, C = c I,          D = lam I    (Region Z: scalar+nilpotent)
     branch 3: B = beta I, C=0, D=0                (Case 2 member)
   plus negatives on J-deformations already run separately.
   ASCII-only source on purpose.
   ================================================================== *)

ClearAll["Global`*"];
br[x_, y_] := Join[Cross[x[[1 ;; 3]], y[[1 ;; 3]]],
   Cross[x[[1 ;; 3]], y[[4 ;; 6]]] + Cross[x[[4 ;; 6]], y[[1 ;; 3]]]];
e6 = IdentityMatrix[6];
avgDef[R_] := Flatten[Table[
    br[R . e6[[i]], R . e6[[j]]] - R . br[R . e6[[i]], e6[[j]]], {i, 6}, {j, 6}]];
ok[R_] := AllTrue[Flatten[avgDef[R]], (Simplify[#] === 0) &];
Z3 = ConstantArray[0, {3, 3}];
adU[u_] := {{0, -u[[3]], u[[2]]}, {u[[3]], 0, -u[[1]]}, {-u[[2]], u[[1]], 0}};

Print["=== branch 1: B=0, C=ad_u (skew), D=0, A=lam I  (Region Y) ==="];
Print["  lam=3, u=(1,-2,4) : ",
  ok[ArrayFlatten[{{3 IdentityMatrix[3], Z3}, {adU[{1, -2, 4}], Z3}}]]];
Print["  lam=7, u=(0,1,0)  : ",
  ok[ArrayFlatten[{{7 IdentityMatrix[3], Z3}, {adU[{0, 1, 0}], Z3}}]]];

Print["=== branch 2: B=0, C=c I, D=lam I  (Region Z scalar+nilpotent) ==="];
Print["  lam=3, c=5  : ",
  ok[ArrayFlatten[{{3 IdentityMatrix[3], Z3}, {5 IdentityMatrix[3], 3 IdentityMatrix[3]}}]]];
Print["  lam=2, c=-4 : ",
  ok[ArrayFlatten[{{2 IdentityMatrix[3], Z3}, {-4 IdentityMatrix[3], 2 IdentityMatrix[3]}}]]];

Print["=== branch 3: B=beta I, C=0, D=0  (Case 2) ==="];
Print["  lam=3, beta=2 : ",
  ok[ArrayFlatten[{{3 IdentityMatrix[3], 2 IdentityMatrix[3]}, {Z3, Z3}}]]];
Print["  lam=5, beta=-1: ",
  ok[ArrayFlatten[{{5 IdentityMatrix[3], -1 IdentityMatrix[3]}, {Z3, Z3}}]]];

Print["=== negatives (re-check from Solve branches): ==="];
CJ[p_, q_] := {{0, 0, 0}, {0, p, q}, {0, -q, p}};
Print["  lam=3, C=CJ(2,5), D=3I : ",
  ok[ArrayFlatten[{{3 IdentityMatrix[3], Z3}, {CJ[2, 5], 3 IdentityMatrix[3]}}]]];
Print["  lam=3, C=CJ(1,0), D=0, B=0 : ",
  ok[ArrayFlatten[{{3 IdentityMatrix[3], Z3}, {CJ[1, 0], Z3}}]]];
Print["  lam=3, C=ad_u, D=3I (mixed) : ",
  ok[ArrayFlatten[{{3 IdentityMatrix[3], Z3}, {adU[{1, 0, 0}], 3 IdentityMatrix[3]}}]]];
Print["  lam=3, B=2I, C=cI, D=3I (B back in) : ",
  ok[ArrayFlatten[{{3 IdentityMatrix[3], 2 IdentityMatrix[3]}, {3 IdentityMatrix[3], 3 IdentityMatrix[3]}}]]];
Print[""];
Print["Done."];

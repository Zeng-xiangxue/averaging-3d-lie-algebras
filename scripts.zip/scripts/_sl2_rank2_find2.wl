(* find explicit rank-2 solutions: numeric minimization, proper NumericQ guard *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
resid[MT_] := Max[Abs[Flatten[Table[
  lie[sc, MT[[All,i]], MT[[All,j]]] - MT . lie[sc, MT[[All,i]], unit[[j]]], {i,3}, {j,3}]]]];

(* minimize over 12 params: u,z,w1,w2 with u x z != 0 *)
f[vv_List] := Module[{uu, zz, w1, w2, TT},
  {uu, zz, w1, w2} = Partition[vv, 3];
  TT = KroneckerProduct[uu, w1] + KroneckerProduct[zz, w2];
  Total[Flatten[Table[
    lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3},{j,3}]]^2]];

best = 10^9; bestvec = {};
Do[
  v0 = RandomReal[{-1,1}, {12}];
  res = FindMinimum[f[vv], {vv, v0}, Method -> {"Newton", "StepControl" -> "LineSearch"}, MaxIterations -> 300];
  If[res[[1]] < best, best = res[[1]]; bestvec = vv /. res[[2]]],
  {40}];
Print["best objective = ", best];
If[best < 10^-12,
  {u2b, z2b, w12b, w22b} = Partition[bestvec, 3];
  Print["u = ", u2b, "  z = ", z2b];
  Print["w1 = ", w12b, "  w2 = ", w22b];
  Print["u x z = ", Cross[u2b, z2b]];
  Tb = KroneckerProduct[u2b, w12b] + KroneckerProduct[z2b, w22b];
  Print["T = ", MatrixForm[Round[Tb, 10^-6]]];
  Print["resid = ", resid[Tb], "  rank = ", MatrixRank[Tb]];
  Print["rank-2? ", MatrixRank[Tb] == 2];
  ,
  Print["no rank-2 solution found numerically (best ", best, ")"]];

(* minimal check: is minor t11 t22 - t12 t21 really in the ideal? *)
ClearAll["Global`*"];
sc = SparseArray[{{1,1,2}->1, {1,2,1}->-1, {2,1,3}->-2, {2,3,1}->2, {3,2,3}->1, {3,3,2}->-1}, {3,3,3}];
unit = Table[UnitVector[3,i], {i,3}];
lie[cf_,u_,v_] := Table[Sum[u[[i]] v[[j]] cf[[k,i,j]], {i,3}, {j,3}], {k,3}];
TT = Table[t[i,j], {i,3}, {j,3}];
vars = Flatten[TT];
eqs = DeleteCases[Flatten[Table[
  lie[sc, TT[[All,i]], TT[[All,j]]] - TT . lie[sc, TT[[All,i]], unit[[j]]], {i,3}, {j,3}]], 0];
Print["#eqs = ", Length[eqs]];
gb = GroebnerBasis[eqs, vars, MonomialOrder -> DegreeReverseLexicographic];
Print["GB size = ", Length[gb]];

m12 = t[1,1] t[2,2] - t[1,2] t[2,1];
Print["PolynomialReduce of m12 = ", PolynomialReduce[m12, gb, vars][[2]]];
Print["m12 at T=3Id: ", (m12 /. {t[1,1]->3, t[1,2]->0, t[2,1]->0, t[2,2]->3, t[1,3]->0, t[2,3]->0, t[3,1]->0, t[3,2]->0, t[3,3]->3})];

(* does 3 Id satisfy all eqs? *)
res3 = (eqs /. {t[1,1]->3, t[1,2]->0, t[2,1]->0, t[2,2]->3, t[1,3]->0, t[2,3]->0, t[3,1]->0, t[3,2]->0, t[3,3]->3});
Print["max |eqs(3Id)| = ", Max[Abs[res3]]];

(* sanity: is gb correct? check one eq reduces to 0 *)
Print["eq1 reduces to 0? ", PolynomialReduce[eqs[[1]], gb, vars][[2]] == 0];

(* alternative: check membership via Reduce over the ideal quotient *)
Print["m12 in ideal (by GB of eqs + m12*y - 1 elimination)? ",
  Length[GroebnerBasis[Join[eqs, {m12 y - 1}], vars, {y}, MonomialOrder -> DegreeReverseLexicographic]] > 0];

(* check a genuinely-in-ideal polynomial for comparison *)
Print["eq1 itself in ideal? ", PolynomialReduce[eqs[[1]], gb, vars][[2]] == 0];

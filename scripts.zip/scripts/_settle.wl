(* settle:  r(J) completeness (new candidates vs the paper's classes) and the r(c) modulus *)
ClearAll["Global`*"];
e = IdentityMatrix[3];
AJ = {{1,1},{0,1}};
brJ[x_,y_] := Join[{0}, x[[1]] AJ . y[[2;;3]] - y[[1]] AJ . x[[2;;3]]];
phiJ = {{1,0,0},{w1,p,q},{w2,0,p}};
conjJ[T1_,T2_] := Module[{eqs,gb},
  eqs = Numerator /@ Together /@ Flatten[phiJ . T1 . Inverse[phiJ] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p}], {p,q,w1,w2,z}, MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
TJ[lam_] := {{0,0,0},{0,0,0},{0,lam,-lam}};              (* new branch member, trace = -lam *)
print1 = Table[{lam}, {lam, {1}}];
paperB[c_] := {{0,0,0},{0,c,0},{0,-c,0}};                 (* c(e2-e3)e2^T , trace = c *)
paperA[c_] := {{0,0,0},{0,0,c},{0,0,0}};                  (* c e2e3^T , trace = 0 *)
Print["r(J): T(lam=1) ~ paperB(c=-1) ? ", conjJ[TJ[1], paperB[-1]]];
Print["r(J): T(lam=4) ~ paperB(c=-4) ? ", conjJ[TJ[4], paperB[-4]]];
Print["r(J): T(lam=1) ~ paperA(c=1)  ? ", conjJ[TJ[1], paperA[1]]];

A1 = {{1,-1},{1,1}};
brC[x_,y_] := Join[{0}, x[[1]] A1 . y[[2;;3]] - y[[1]] A1 . x[[2;;3]]];
phiC = {{1,0,0},{w1,p,-p tC},{w2,p tC,p}};
conjC[T1_,T2_] := Module[{eqs,gb},
  eqs = Numerator /@ Together /@ Flatten[phiC . T1 . Inverse[phiC] - T2];
  gb = GroebnerBasis[Join[eqs, {1 - z p}], {p,tC,w1,w2,z}, MonomialOrder -> DegreeReverseLexicographic];
  gb =!= {1}];
TC[lam_, u1_, u2_] := Module[{u = {u1,u2}, v},
  v = {u2, -u1} + (A1 . u)*0;   (* placeholder, replaced below *)
  {{0,0,0},{0,0,0},{0,0,0}}];
(* explicit r(c) candidates:  u = e2  -> v = (-1,1) ;  u = e3 -> v = (1,1) *)
Tc1[lam_] := lam{{0,0,0},{0,-1,1},{0,0,0}};   (* M = [[-1,1],[0,0]] , trace = -lam *)
Tc2[lam_] := lam{{0,0,0},{0,0,1},{0,0,1}};    (* M = [[0,1],[0,1]] hmm check *)
Print["r(c): residual Tc1(1) = ", Max[Abs[Flatten[Table[brC[Tc1[1].e[[i]],Tc1[1].e[[j]]] - Tc1[1].brC[Tc1[1].e[[i]],e[[j]]],{i,3},{j,3}]]]]];
Print["r(c): residual Tc2(1) = ", Max[Abs[Flatten[Table[brC[Tc2[1].e[[i]],Tc2[1].e[[j]]] - Tc2[1].brC[Tc2[1].e[[i]],e[[j]]],{i,3},{j,3}]]]]];
Print["r(c): Tc1(1) ~ Tc2(1) ? ", conjC[Tc1[1], Tc2[1]]];
Print["r(c): Tc1(1) ~ Tc1(-1) ? ", conjC[Tc1[1], Tc1[-1]]];
Print["r(c): Tc1(1) ~ Tc2(-1) ? ", conjC[Tc1[1], Tc2[-1]]];
